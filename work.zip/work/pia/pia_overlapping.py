
import sys
import os
parent_directory_path = os.path.dirname(os.getcwd())
sys.path.append(parent_directory_path)
# sys.path.append(parent_directory_path+'\\util')
# sys.path.insert(0, parent_directory_path+'\\util\\python3\\gateway_util')
# print(sys.path)

import csv
import time
import threading
from threading import Lock
import multiprocessing
from functools import partial
from concurrent.futures import ThreadPoolExecutor

from util.python3.gateway_util import Gateway_Util
from util.python3.gateway_util import Subnet_Match

lock = Lock()

fina_output = []
processed_row = set()
count = 0

def add_to_output(parent_subnet, parent_lab, subnet_subnet, child_lab, remark):
    #with lock:
    if remark not in processed_row and parent_lab != child_lab:
        print("hitted----------------")
        processed_row.add(remark)
        fina_output.append([parent_subnet, parent_lab, subnet_subnet, child_lab, remark])

def get_pia_subnets():
    input_data = []    
    csv_file = open('input/Valid_Lab_Ids_Subnet.csv','r')
    csv_data = csv.reader(csv_file)
    for line in csv_data:
        subnet = line[0].strip()
        lab_id = line[1].strip()

        if ("Subnet" != subnet and "," not in lab_id):
            # print(subnet + " - " + lab_id)
            input_data.append([subnet, lab_id]) 
            # break          
    print(len(input_data))
    return input_data

# def find_overlaping_fubnet_for_pia(single_subnet_data, subnet_data_list):
def find_overlaping_fubnet_for_pia(subnet_data_list, single_subnet_data):
    # print(threading.current_thread().getName())
    # print(single_subnet_data)
    # time.sleep(10)
    global count
    #for i in input_pia_data:
    # print(single_subnet_data)
    
    subnet1 = single_subnet_data[0]
    for j in subnet_data_list:
        subnet2 = j[0]
        if (subnet1 != subnet2):                
            subnet1_lab = single_subnet_data[1]                
            subnet2_lab = j[1]
                        
            result = Gateway_Util.compare_subnet(subnet1, subnet2)
            if (Subnet_Match.SOURCEISPARTOFDESTINATION == result):
                remark = subnet2 + " of " + subnet2_lab + " is overlaping " + subnet1 + " of " + subnet1_lab
                # add_to_output(subnet2, subnet2_lab, subnet1, subnet1_lab, remark)
                #return [subnet2, subnet2_lab, subnet1, subnet1_lab, remark]
                # print(remark)
            elif (Subnet_Match.DESTINATIONISPARTOFSOURCE == result):
                remark = subnet1 + " of " + subnet1_lab + " is overlaping " + subnet2 + " of " + subnet2_lab
                # add_to_output(subnet1, subnet1_lab, subnet2, subnet2_lab, remark)
                # return [subnet1, subnet1_lab, subnet2, subnet2_lab, remark]
                # print(remark)
            
    count += 1
    print(count)
    # break
    # return None
    

def fn(a_data, a):
    print(a, "start")
    #for i in a_data:
    # print(a, a_data)
    # with lock:
        #fina_output.append([a, a_data])
    # print(fina_output)
    #with lock:

def start():
    input_pia_data = get_pia_subnets()
    print(os. cpu_count())
    
    #with ThreadPoolExecutor(max_workers = 30) as executor:
     #   for i in input_pia_data:
      #      executor.submit(find_overlaping_fubnet_for_pia, i, input_pia_data)
            # break        
    
    
    pool = multiprocessing.Pool()
    func = partial(find_overlaping_fubnet_for_pia, input_pia_data)
    q = pool.map_async(func, input_pia_data).get()
    pool.close()
    pool.join()
    
    #for i in fina_output:
     #   print(i)
    #print(len(fina_output))

if __name__ == "__main__":
    start()

    # find_overlaping_for_fubnet()
    # print(fina_output)
    # print(len(fina_output))
