#
# configuration for python 2
#

import paramiko
import time
import re
import socket
import traceback
from concurrent.futures import ThreadPoolExecutor
import subprocess
import csv
import os
from ipaddress import IPv4Address
from typing import Union
from enum import Enum
import pandas as pd
from pandas import DataFrame
from deprecated import deprecated


class Gateway_Util_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(Gateway_Util_Exception, self).__init__(self.message)

@deprecated(reason="Use Subnet_Match enum class from util.Network_Util")
class Subnet_Match(Enum):
    """ @deprecated     Use Subnet_Match enum class from util.Network_Util
    """
    
    NOTMATCH = -1
    SAME = 0
    SOURCEISPARTOFDESTINATION = 1
    DESTINATIONISPARTOFSOURCE = 2

class Gateway_Util:
    
    @staticmethod
    def get_paramiko_client(host, username, password, gw_conn_status_dict = None, lock = None):
        try:
            vm = paramiko.SSHClient()
            vm.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # vm.load_system_host_keys()
            vm.connect(hostname = host, port = 22, username = 'morashee.web', password = '%Tgb0okm9ijn', allow_agent = False, look_for_keys = False)
            Gateway_Util.__add_increment("gw_connected_count", gw_conn_status_dict, lock)
            #gw_conn_status["gw_connected_count"] += 1
            return vm
        except paramiko.AuthenticationException:
            Gateway_Util.__add_increment("gw_auth_failed_count", gw_conn_status_dict, lock)
            # gw_conn_status["gw_auth_failed_count"] += 1
            raise Gateway_Util_Exception("Authentication failed!")
        except paramiko.ssh_exception.NoValidConnectionsError:
            Gateway_Util.__add_increment("gw_not_connected_count", gw_conn_status_dict, lock)
            # gw_conn_status["gw_not_connected_count"] += 1
            raise Gateway_Util_Exception("Device is not connected")
        except OSError:
            Gateway_Util.__add_increment("gw_unreachable_count", gw_conn_status_dict, lock)
            # gw_conn_status["gw_unreachable_count"] += 1
            raise Gateway_Util_Exception("Network is unreachable")
        except:        
            ex = str(traceback.format_exc())
            if "Connection timed out" in ex:
                Gateway_Util.__add_increment("gw_conn_time_out_count", gw_conn_status_dict, lock)
                # gw_conn_status["gw_conn_time_out_count"] += 1
                raise Gateway_Util_Exception("Connection timed out")
            else:
                Gateway_Util.__add_increment("gw_unknown_error_count", gw_conn_status_dict, lock)
                # gw_conn_status["gw_unknown_error_count"] += 1
                raise Gateway_Util_Exception("Unknown error: \n" + ex)

    @staticmethod 
    def is_not_none(obj):
        return obj != None
    
    @staticmethod
    def __add_increment(key, gw_conn_status_dict, lock):
        if (Gateway_Util.is_not_none(gw_conn_status_dict)):            
            if (Gateway_Util.is_not_none(lock)):
                with lock:
                    gw_conn_status_dict[key] += 1
            else:
                gw_conn_status_dict[key] += 1
            
    @staticmethod
    def get_interactive_session(ssh):
        return ssh.invoke_shell()
            
    @staticmethod
    def exec_command(chan, cmd):
        chan.send(cmd+'\n')
        while not chan.recv_ready():
            time.sleep(3)
        time.sleep(3)
        
        isBigResponse = False
        out = chan.recv(9999)
        respose = out.decode("ascii")
        
        if '--More--' in respose:
            isBigResponse = True
            respose = respose.replace("--More--", "").replace("\x08", "").strip()
        
        while isBigResponse:        
            chan.send(" " + '\r')
            while not chan.recv_ready():
                time.sleep(3)
            time.sleep(2)
            out = chan.recv(9999)
            temp = out.decode("ascii")        
            respose = respose + "\n" + temp.replace("--More--", "").replace("\x08", "").strip()
            
            if '--More--' not in temp:
                break

        return str(respose)
    
    @staticmethod
    def write_log(text, log_file):
        if (log_file != None):
            log_file.write(text)
    
    @staticmethod
    def get_lab_from_desc(desc: str) -> Union[str, None]:
        more_lab_match_list = []

        pattern = re.compile(r'LRT[\s:#_-]*\d{4,7}\d*', re.IGNORECASE)
        more_lab_match_list_1 = re.findall(pattern, desc)
        # print(more_lab_match_list_1)
        for i in more_lab_match_list_1: 
            more_lab_match_list.append(i)
            
        pattern = re.compile(r'lab[\s:#_-]*id[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
        more_lab_match_list_1 = re.findall(pattern, desc)
        # print(more_lab_match_list_1)
        for i in more_lab_match_list_1: 
            more_lab_match_list.append(i)
        
        pattern = re.compile(r'lab[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
        more_lab_match_list_1 = re.findall(pattern, desc)
        # print(more_lab_match_list_1)
        for i in more_lab_match_list_1: 
            more_lab_match_list.append(i)

        pattern = re.compile(r'labs[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
        more_lab_match_list_1 = re.findall(pattern, desc)
        # print(more_lab_match_list_1)
        for i in more_lab_match_list_1: 
            more_lab_match_list.append(i)
        

        ###
        # need to add
        #  (labs id numbers) condition

        # print(more_lab_match_list)

        # number sequence without identifiers. eg: ["to SJ-15-TNQ-STE_50368_dole", "ANCD|CID:1357/12345|#|BW:0Mb/0Mb"]
        # in te output list, using [] identifier to save separate sheet in excel
        if (len(more_lab_match_list) == 0):
            pattern = re.compile(r'\d{4,5}', re.IGNORECASE)
            number_sequence = re.findall(pattern, desc)
            if (len(number_sequence)):
                return "[" + ", ".join(number_sequence) + "]"
            else:
                return None        
        """
        if (len(more_lab_match_list) == 1):
            pattern = re.compile(r'LRT[0-9]+', re.IGNORECASE)
            lrt = pattern.search(desc)
            if (lrt):
                return "valid: " + str(lrt.group())
        """
        if (len(more_lab_match_list) != 0):        
            output_labid_set = set()
            for i in more_lab_match_list:

                pattern = re.compile(r'LRT[0-9]+', re.IGNORECASE)
                lrt = pattern.search(i)
                if (lrt):
                    output_labid_set.add(str(lrt.group()))
                else:
                    pattern = re.compile(r'\d+', re.IGNORECASE)
                    lab_id = pattern.search(i)
                    if (lab_id):
                        output_labid_set.add(str(lab_id.group()))
            return ", ".join(output_labid_set)
        return None
    
    @staticmethod
    def get_valid_lab_id(lab_id: str) -> str:
        if len(lab_id) == 4:
            val_lab_id = "LRT000"+lab_id
            return val_lab_id
        elif len(lab_id) == 5:
            val_lab_id = "LRT00"+lab_id
            return val_lab_id
        elif lab_id == 'LRT0000000' or 'LRT0000' in lab_id or '0' == lab_id:
            val_lab_id = "incorrect lab id"
            return val_lab_id
        elif 'LRT' in lab_id and len(lab_id) != 10:
            id = str(int(lab_id.split("LRT")[1]))
            val_lab_id = Gateway_Util.get_valid_lab_id(id)
            return val_lab_id
        else:
            return lab_id
        
    @staticmethod
    def get_lrt_formatted_id(lab_id , hostname = None, interface = None, ip = None, description = None):
        # lrt_formatted_id_with_details -> to keep the evidence for new LRT id.
        # it will have lab_id, new LRT formatted lab_id, device name, interface name, interface ip, description
        lrt_formatted_id_with_details = []
        
        new_lab_id = Gateway_Util.get_valid_lab_id(lab_id, lrt_formatted_id_with_details, hostname, interface, ip, description, True)
        return [new_lab_id, lrt_formatted_id_with_details]

    @staticmethod
    @deprecated(reason="Use nslookup() from util.Network_Util")
    def nslookup(gw, gw_with_ip, failed_nslookup_gw_status):
        """ @deprecated     Use nslookup() from util.Network_Util
        """
        
        p = subprocess.Popen('nslookup ' + gw, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        isIpAddressLine = False
        ip_addresses = []
        for line in p.stdout.readlines():
            line = line.decode()

            if ("can't find" in line):
                print("{:<30}    {}".format(gw, "Can not find IP Address by nslookup"))
                failed_nslookup_gw_status.append(["", gw, "Can not find IP Address by nslookup"])
                gw_nslookup_error = gw_nslookup_error + 1
                return

            if (isIpAddressLine and 'Name' not in line and line.strip() != ''):
                ip_addresses.append(line.replace("Address:", "").replace("Addresses:", "").strip())
                # gws_ip.append[gw, line.replace("Address:", "").replace("Addresses:", "").strip()]
                # break

            if ("Name" in line and gw in line and "can't find" not in line):
                isIpAddressLine = True
                
        print("{:<30}    {}".format(gw, ip_addresses))
        # currently tacking IPv4 address
        got_ipv4 = False
        for ip in ip_addresses:        
            try:            
                socket.inet_aton(ip)
                gw_with_ip.append([gw, str(ip)]) # ['host_name',IPv4]
                got_ipv4 = True
            except socket.error:
                if (len(ip_addresses) == 1):
                    print("not IPv4: {}, {}".format(gw, ip))
                    try:
                        socket.inet_pton(socket.AF_INET6, ip)
                        gw_with_ip.append([gw, ip]) # ['host_name', 'ipv6' ,IPv6]
                    except socket.error as e:
                        print("Ip error: {}".format(str(e)))

        if (got_ipv4 == False):
            print("no ipv4 found. used IPv6  ==> {:<30}    {}".format(gw, ip_addresses))

    @staticmethod
    @deprecated(reason="Use get_ip_address_by_nslookup() from util.Network_Util")
    def get_ip_address_by_nslookup(gws: Union[list, set]):  
        """ @deprecated     Use get_ip_address_by_nslookup() from util.Network_Util
        """

        avoid_gw_list = "rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1-ironport, ful01-fw1, sjc5-cibb-fw1, sjc5-cibb-fw1-ironport, sjc5-cibb-fw2-ironport, sjc5-cibb-fw2, rtp1-mda2-cibb-fw2-ironport, rtp1-mda2-cibb-fw2, rtp1-mda2-cibb-fw2-latisys"
        
        print("Befter total: {}".format(len(gws)))
        print("avoid_gw_list is applied")
        print("After total: {}".format(len(gws) - len(avoid_gw_list)))

        gws_ip = []
        failed_nslookup_gw_status = []
        print("{:<30}    {}".format('Gateway', 'Ip'))
        with ThreadPoolExecutor(max_workers=30) as executor:    
            for gw in gws:
                gw = gw.strip() 
                if (gw not in avoid_gw_list):
                    executor.submit(Gateway_Util.nslookup, gw, gws_ip, failed_nslookup_gw_status)
                
        print("\ntotal gws_ip by nslookup = {}".format(str(len(gws_ip))))
        for i in gws_ip:
            print(i)
        
        print("Failed nslookup: {}".format(len(failed_nslookup_gw_status)))
        for i in failed_nslookup_gw_status:
            print(i)

        return [gws_ip, failed_nslookup_gw_status]
    
    @staticmethod
    def is_valid_lrt_id(lab_id: str):
        #print(lab_id)

        if (lab_id == None or lab_id == '' or type(lab_id) != str):
            return False
        
        if (len(lab_id) == 10
            and (lab_id.startswith("LRT00") or lab_id.startswith("LRT000"))):
            number_part = lab_id.split("00")[1]

            if (number_part.isdigit()):
                return True
        
        return False
    
    @staticmethod
    def close_resource(*objs):
        for obj in objs:
            if (obj != None):
                try:
                    obj.close()
                except:
                    pass
    
    @staticmethod
    @deprecated(reason="Use save_data_to_new_csv() from util.Util")
    def save_data_to_new_csv(filename: str, columns: list, data_list: list):
        """ @deprecated     Use save_data_to_new_csv() from util.Util
        """
        csv_file = None
        if (not filename.endswith(".csv")):
            filename = filename + ".csv"
        try:
            csv_file = open(filename,'w')
            writer = csv.writer(csv_file)
            print("CSV : Writing report to "+filename+"... | count: {}".format(str(len(data_list))))
            writer.writerow(columns)
            for i in data_list:
                    writer.writerow(i)

            Gateway_Util.close_resource(csv_file)
        except Exception as e:
            raise Exception(e)
            # print(e)

    @staticmethod
    @deprecated(reason="Use send_mail_from_server_cmd() from util.Util")
    def send_mail_from_server_cmd(sender, receivers, subject, *filenames):
        """ @deprecated     Use send_mail_from_server_cmd() from util.Util
        """

        filename = " -a ".join(filenames)
        try:
            cmd = 'echo "" |  mail -a %s -s "%s" -r %s %s'%(filename, subject, sender, " ".join(receivers))
            # print(cmd)
            os.system(cmd)
            print("Mail sent")
        except:
            e = str(traceback.format_exc())
            print ("Error: unable to send email\n" + e)        

    @staticmethod
    def get_gw_name_by_ip(ip):
        ip = ip.strip()
        p = subprocess.Popen('nslookup ' + ip, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        gw_name = ""

        for line in p.stdout.readlines():
            line = line.decode().strip()
            if ("can't" in line):
                return line.strip()
            if ("name = " in line):
                gw_name = line.split("name = ")[1].replace(".cisco.com.", "").strip()

        return gw_name
    
    @staticmethod
    @deprecated(reason="Use get_wild_card_mask(cidr) from util.Network_Util")
    def get_wild_card_mask(subnet):
        """ @deprecated     Use get_wild_card_mask(cidr) from util.Network_Util
        """
        subnet = subnet.strip()
        if (subnet == '' or ' ' in subnet):
            raise Gateway_Util_Exception("Subnet is not in a valid format.\nValue: " + subnet)

        mask_bit = ''
        if ("/" in subnet):
            mask_bit = subnet.split("/")[1]
        else:
            raise Gateway_Util_Exception("get_wild_card_mask: Invalid format:\nvalue: " + subnet)
        
        return str(IPv4Address(int(IPv4Address._make_netmask(mask_bit)[0])^(2**32-1)))
    
    @staticmethod
    @deprecated(reason="Use compare_subnet(cidr_a, cidr_b) from util.Network_Util")
    def compare_subnet(subnet_a, subnet_b):
        """ @deprecated     Use compare_subnet(cidr_a, cidr_b) from util.Network_Util
        """

        from ipaddress import IPv4Network
        if (subnet_a == subnet_b):
            return Subnet_Match.SAME
        elif (IPv4Network(subnet_a).overlaps(IPv4Network(subnet_b))):
            if (IPv4Network(subnet_a).supernet_of(IPv4Network(subnet_b))):
                return Subnet_Match.DESTINATIONISPARTOFSOURCE
            return Subnet_Match.SOURCEISPARTOFDESTINATION
        return Subnet_Match.NOTMATCH
    
    @staticmethod
    @deprecated(reason="Use create_excel_sheet() from util.Util")
    def create_excel_sheet(writer: DataFrame, sheet_name:str, columns: list, row_datas: list):
        """ @deprecated     Use create_excel_sheet() from util.Util
        """

        print("Excel : Writing report to "+sheet_name+" sheet... | count: {}".format(str(len(row_datas))))
        
        if (len(row_datas) == 0):
            row_datas.append(["" for i in range(len(columns))])

        df = pd.DataFrame(row_datas)
        df.columns = columns        
        df.to_excel(writer, sheet_name = sheet_name, index=False)

if __name__ == "__main__":
    #gw = ["mtv5-mda1-cibb-gw1", "sfo12-cibb-gw2", "sjc18-lab-gw2", "sjc22-lab-gw2", "sjc22-lab-gw1", "sjc18-lab-gw1", "tyoidc5-cp-pxtr1-gw2", "clg5-lab-gw1", "clg5-lab-gw2", "sjc12-cp-mgre1-gw1", "cjs04-lab-gw1", "wnp02-lab-gw1", "mxc-14-lab-gw1", "bnt01-lab-gw1", "lma1-lab-gw1", "bla-lab-gw1", "sjocr02-lab-gw1", "mxc10-lab-gw2", "mxc10-lab-gw1", "snt03-lab-gw1", "alln01-mda2-cp-pxtr1-gw2", "alln01-mda1-cibb-gw3", "rcdn9-cd1-cp-mgre1-gw1", "alln01-mda2-dmzaas-gw2", "alln01-mda1-cp-pxtr1-gw1", "alln01-mda2-cibb-gw4", "ast04-lab-gw1", "alln01-lab-gw1", "alln01-mda1-dmzaas-gw1", "rcdn9-cd2-cp-mgre1-gw2", "rcdn5-lab-sipt-sw1", "bgt2-lab-gw1", "rcdn5-lab-gw1", "ast09-lab-gw2", "ast09-lab-gw1", "glj3-lab-gw1", "bua2-lab-gw1", "spl1-lab-gw1", "ast04-cibb-gw2", "rcdn9-sdfc-dmzvaas-gw2", "rcdn9-sdfa-dmzvaas-gw1", "rcdn5-lab-gw2", "ast04-cibb-gw1", "rcdn6-lab-gw2", "rcdn9-sdfa-dmzvlab-gw1", "rcdn6-lab-gw1", "rcdn5-cibb-gw1", "rcdn9-cd2-lab-gw2", "rcdn9-cd1-lab-gw1", "rcdn5-dmzlab-gw2", "rcdn9-cd2-dmzaas-gw2", "rcdn9-cd1-dmzaas-gw1", "lion3-pl-lab-gw1", "ntn01-lab-gw1", "ntn01-lab-gw2", "mtl02-lab-gw1", "hal01-lab-gw1", "ntn01-cp-pxtr1-gw1", "bos02-lab-gw1", "nyc1-lab-gw1", "nyc1-lab-gw2", "awn01-lab-gw1", "ntn01-cp-pxtr1-gw2", "ott02-lab-gw1", "ott01-lab-gw1", "bxb23-lab-gw1", "cai02-lab-gw1", "bxb23-lab-gw2", "cas02-lab-gw1", "ryd4-lab-gw1", "waw02-lab-gw1", "man3-lab-gw1", "lys01-lab-gw1", "vnaa-lab-gw1", "got-lab-gw1", "dgm3-lab-gw2", "prg5-lab-gw1", "muc07-lab-gw1", "dgm2-lab-gw2", "vbn02-lab-gw1", "krk07-lab-gw2", "bts05-lab-gw1", "lys01-cibb-gw1", "ist2-lab-gw1", "sof7-lab-gw2", "cae02-lab-gw1", "zgr02-lab-gw1", "brc2-lab-gw2", "ams5-lab-gw1", "prg5-lab-gw2", "stk03-lab-gw2", "vbn02-lab-gw2", "bonn01-lab-gw1", "ath01-lab-gw1", "dblir3-lab-gw1", "cae02-lab-gw2", "lys01-lab-gw2", "brc2-lab-gw1", "mhm03-lab-gw1", "ibm3-bg-lab-gw1", "los03-lab-gw1", "ibm3-bg-lab-gw2", "dgm2-lab-gw3", "mdr1-lab-gw1", "dgm2-lab-gw1", "dlf1-lab-gw1", "dgm-lab-gw1", "krk07-lab-gw1", "lys01-cibb-gw2", "est1-jo-lab-gw1", "est1-jo-lab-gw2", "stk03-lab-gw1", "dgm3-lab-gw1", "vmct04-lab-gw1", "ala03-lab-gw1", "krk02-lab-gw1", "aer01-mda1-cp-pxtr1-gw1", "sof7-lab-gw1", "amm02-lab-gw1", "krk04-lab-gw1", "lon11-cibb-gw2", "doh03-lab-gw1", "sykes1-co-lab-gw1", "els01-lab-gw1", "wlsn01-lab-gw1", "loncaf-cp-pxtr1-gw1", "lju02-lab-gw1", "vmct05-lab-gw2", "loncaf-cp-pxtr1-gw2", "lon11-cibb-gw1", "tun03-lab-gw1", "cph06-lab-gw1", "rol01-lab-gw1", "stk06-lab-gw1", "beg02-lab-gw1", "aer01-mda1-lab-gw1", "aer01-mda2-cp-pxtr1-gw2", "stk06-lab-gw2", "aer01-mda2-lab-gw2", "lon06-lab-gw1", "musc01-lab-gw1", "sof2-lab-gw1", "vmct05-lab-gw1", "rom2-lab-gw1", "gpk03-lab-gw1", "els01-cibb-gw2", "aer01-mda2-cp-mgre1-gw2", "fkf3-lab-gw1", "gpk03-cibb-gw1", "fkf3-lab-gw2", "gpk03-cibb-gw2", "aer01-mda1-cp-mgre1-gw1", "gpk03-lab-gw2", "lon07-lab-gw1", "dbi03-lab-gw1", "bcr2-lab-gw1", "kjk04-lab-gw1", "nue01-lab-gw1", "nbo03-lab-gw1", "bud01-lab-gw1", "stg02-lab-gw1", "kwi01-lab-gw1", "gwy03-lab-gw1", "ips02-lab-gw1", "rtp1-mda2-cibbfo-sw1", "rtp1-mda2-cibbfo-sw2", "sjc20-cz-sdlab-gw1", "hrn6-lab-gw1", "hkg1-lab-gw2", "rtp1-mda2-cibb-fw1", "sjc21-cz-sdlab-gw2", "sjc20-cz-sdlab-gw2", "rtp1-mda2-cibb-fw1", "tpe02-lab-gw1", "sjc21-cz-sdlab-gw1", "hkg1-lab-gw1", "hrn6-lab-gw2", "atl-lab-gw1", "rtp1-mda2-cibb-wan-gw2", "rtp1-mda2-cibb-wan-gw1", "rtp10-cd-cp-mgre1-gw1", "lwr01-lab-gw1", "rtp7-cibb-gw1", "rtp10-cd-cp-pxtr1-gw1", "bjn6-lab-gw1", "lwr01-lab-gw2", "rtp1-mda2-cibb-fw1-ironport", "knv-lab-gw1", "bjn6-lab-gw2", "knv3-cibb-gw2", "knv3-cibb-gw1", "stld1-mda1-cp-mgre1-gw1", "stld1-mda2-cp-mgre1-gw2", "csb04-lab-gw2", "csb04-lab-gw1", "blndc01-lab-gw2", "blndc01-lab-gw1", "rtp5-dmzvlab-gw1", "ann01-lab-gw1", "shnidc-cp-pxtr1-gw2", "mrd01-lab-gw2", "mrd01-lab-gw1", "mim1-lab-gw1", "shnidc-cp-pxtr1-gw1", "esp02-lab-gw1", "prg7-lab-gw2", "prg7-lab-gw1", "alp03-lab-gw2", "rtp10-cd-dmzvlab-gw1", "sngidc-cp-pxtr1-gw2", "rtp1-mda1-cp-mgre1-gw1", "alp03-lab-gw1", "cgn03-lab-gw2", "wdf02-lab-gw1", "cgn03-lab-gw1", "rtp10-cd-dmzaas-gw1", "chn09-lab-gw2", "chn09-lab-gw1", "chg12-lab-gw2", "chg12-cibb-gw1", "chg12-cibb-gw2", "chg12-lab-gw1", "tul04-lab-gw2", "tul04-lab-gw1", "sjc05-cp-mgre1-gw1", "hcl7-in-lab-gw1", "hcl7-in-lab-gw2", "sngidc-cp-pxtr1-gw1", "hbg-lab-gw1", "rtp5-cibb-gw1", "trn6-lab-gw1", "trn6-lab-gw2", "rtp7-lab-gw1", "ful01-lab-gw2", "ful01-lab-gw1", "wshdc02-lab-gw1", "rtp3-lab-gw1", "rtp10-00-lab-gw2", "rtp9-lab-gw1", "rtp4-00-lab-gw2", "rtp2-lab-gw1", "sla01-lab-gw2", "rtp1-lab-gw1", "rtp12-00-lab-gw2", "rtp1-lab-gw2", "rtp12-00-lab-gw1", "rtp6-lab-gw2", "sla01-lab-gw1", "rtp6-lab-gw1", "rtp9-lab-gw2", "rtp11-lab-gw1", "sykes2-cr-lab-gw1", "req02-lab-gw1", "sol2-lab-gw1", "sea1-lab-gw1", "rtp5-lab-gw1", "rtp11-lab-gw2", "rtp1-mda1-cp-pxtr1-gw1", "rtp7-lab-gw2", "rtp8-lab-gw2", "embsys2-in-lab-gw2", "embsys2-in-lab-gw1", "sngidc-dmzvlab-gw1", "sngidc-dmzvlab-gw2", "pen3-lab-gw1", "pen3-lab-gw2", "jkt05-lab-gw2", "jkt05-lab-gw1", "rtp1-dmzvaas-gw1", "rtp7-dmzvaas-gw1", "ful01-fw1", "rtp5-dmzlab-gw1", "rtp8-lab-gw1", "req01-lab-gw1", "rtp1-dmzlab-gw1", "rtp11-dmzlab-gw1", "csv-lab-gw1", "atl11-lab-gw2", "atl11-lab-gw1", "ors03-lab-gw2", "cwy01-lab-gw1", "ors03-lab-gw1", "cwy01-lab-gw2", "gai03-lab-gw2", "bel01-lab-gw2", "bel01-lab-gw1", "aar02-lab-gw1", "bln2-lab-gw2", "gai03-lab-gw1", "bln2-lab-gw1", "tyoidc5-cp-pxtr1-gw1", "twl03-lab-gw1", "mil01-lab-gw1", "mil01-lab-gw2", "schp01-lab-gw1", "bgl16-00-lab-gw1", "argrp4-in-lab-gw1", "wpr2-in-lab-gw1", "bgl16-00-lab-gw2", "argrp4-in-lab-gw2", "bgl17-cp-mgre1-gw1", "argrp1-in-lab-gw1", "mtc2-in-lab-gw1", "bgl13-lab-gw2", "bgl13-cp-pxtr1-gw1", "bgl13-cibb-gw1", "bgl17-cp-pxtr1-gw1", "bgl13-lab-gw1", "bgl17-cibb-gw1", "pnq05-lab-gw2", "pnq05-lab-gw1", "hcl14-in-lab-gw1", "hcl14-in-lab-gw2", "bgl18-00-lab-gw1", "cmb03-lab-gw1", "infy9-in-lab-gw1", "bgl13-cp-mgre1-gw1", "bgl14-00-lab-gw1", "bgl18-00-lab-gw2", "bgl14-00-lab-gw2", "chn08-lab-gw1", "ggn01-lab-gw1", "ggn01-lab-gw2", "bgl26-lab-gw1", "shn15-lab-gw1", "argrp5-in-lab-gw1", "bgl17-00-lab-gw1", "bgl17-00-lab-gw2", "wpr8-in-lab-gw1", "hcl19-in-lab-gw2", "hcl19-in-lab-gw1", "bgl11-00-lab-gw2", "bgl11-00-lab-gw1", "bgl12-00-lab-gw1", "mmb12-lab-gw1", "mmb12-lab-gw2", "bgl12-00-lab-gw2", "kul02-lab-gw1", "bgl15-00-lab-gw1", "bgl15-00-lab-gw2", "hcl17-in-lab-gw1", "hcl17-in-lab-gw2", "bng02-lab-gw1", "hgh06-ext-lab-gw2", "hgh06-ext-lab-gw1", "sngdc01-mda2-cibb-gw2", "sngdc01-mda1-cibb-gw1", "akl02-lab-gw1", "mel03-lab-gw1", "tky7-lab-gw1", "hgh05-lab-gw1", "shn4-cibb-gw1", "shn15-lab-gw2", "shn6-lab-gw1", "shn7-lab-gw2", "tky7-lab-gw2", "ngo1-lab-gw1", "sng15-lab-gw1", "shn7-lab-gw1", "shn4-lab-gw2", "shn4-cibb-gw2", "shn4-lab-gw1", "sng15-lab-gw2", "prt3-lab-gw1", "nsd5-lab-gw2", "nsd5-lab-gw1", "cbr04-lab-gw1", "foxc1-cn-lab-gw1", "gng03-lab-gw1", "hfe02-lab-gw1", "hfe02-lab-gw2", "tky7-cibb-gw2", "tky7-cibb-gw1", "stld1-lab-gw2", "stld1-lab-gw1", "szn04-lab-gw1", "szn05-lab-gw1", "wln2-lab-gw1", "hni05-lab-gw1", "dlc02-lab-gw1", "dlc02-lab-gw2", "fka1-lab-gw1", "osk04-lab-gw1", "brb05-lab-gw1", "sngdc01-mda2-dmzaas-gw2", "sngdc01-mda1-dmzaas-gw1", "mnl02-lab-gw1", "shn17-lab-gw1", "shn17-lab-gw2", "svta01-lab-gw1", "yer03-lab-gw1", "sjc23-lab-gw2", "sjc21-lab-gw1", "sjc20-cibb5-gw1", "sjc20-lab-gw1", "sjcp-lab-gw2", "sjc23-lab-gw1", "sjc24-lab-gw1", "sjc21-lab-gw2", "sjc24-lab-gw2", "sjc20-lab-gw2", "sjcp-lab-gw1", "bvw01-lab-gw1", "sea1-lab-gw2", "vnc2-lab-gw1", "sjc5-cibbfo-sw2", "sjc5-cibbfo-sw1", "sjc5-cibb-wan-gw1", "sjc5-cibb-fw1", "wlt06-lab-gw2", "sjc12-dmzvaas-gw1", "sjc05-dmzvaas-gw1", "blv-lab-gw1", "wlt06-lab-gw1", "sjc5-cibb-fw1-ironport", "sjc12-cibb4-gw1", "sjc5-cibb-wan-gw2", "sjc12-lab-gw1", "sjc12-cp-pxtr1-gw1", "sfo12-cibb-gw1", "sjc5-cibb4-gw1", "sjc05-cp-pxtr1-gw1", "sjc02-lab-gw1", "sjc14-lab-gw1", "sjc16-lab-gw1", "sjc11-lab-gw1", "sjc08-lab-gw1", "sjc03-lab-gw1", "sjc01-lab-gw1", "sjc5-cibb4-gw2", "sjc15-lab-gw2", "sjc09-lab-gw1", "sjc07-lab-gw1", "sjc17-lab-gw1", "sjc13-lab-gw1", "sjc06-lab-gw2", "sjc04-lab-gw1", "sjc15-lab-gw1", "sjc19-lab-gw1", "sjc10-lab-gw1", "sjc04-lab-gw2", "sjc16-lab-gw2", "sjc14-lab-gw2", "sjc03-lab-gw2", "sjc13-lab-gw2", "sjc05-lab-gw2", "sjc06-lab-gw1", "sjc02-lab-gw2", "sjc01-lab-gw2", "sjc05-lab-gw1", "sjc09-lab-gw2", "sjc12-cibb4-gw2", "sjc10-lab-gw2", "sjc19-lab-gw2", "sjc08-lab-gw2", "sjc12-lab-gw2", "sjc07-lab-gw2", "sjc17-lab-gw2", "csb03-lab-gw1", "syc02-lab-gw1", "cosm02-lab-gw1", "sprg01-lab-gw2", "irv8-lab-gw1", "csb03-lab-gw2", "lux1-lab-gw1", "rtp5-lab-gw2", "rtp4-00-lab-gw1", "bgl17-dmzvlab-gw1", "bgl13-dmzaas-gw1", "bgl17-dmzaas-gw1", "bgl25-lab-gw1", "rcdn6-cibb-gw1", "sprg01-lab-gw1", "sjc23-cibb5-gw1", "par03-lab-gw2", "par03-lab-gw1", "bdlk11-cibb-gw1", "bdlk09-00-lab-gw1", "bdlk10-31-lab-gw1", "bdlk09-12-lab-gw1", "bdlk09-cibb-gw1", "bdlk10-00-lab-gw1", "bdlk09-00-lab-gw2", "bdlk11-00-lab-gw2", "bdlk11-00-lab-gw1", "rtp10-00-lab-gw1", "rtp5-dmzaas-gw1", "lon06-cibb-gw1", "els01-cibb-gw1", "mtv5-mda2-cibb-gw2", "sjc05-dmzvlab-gw1", "sjc5-cibb-fw2-ironport", "sjc5-cibb-fw2", "rtp1-mda2-cibb-fw2", "rtp1-mda2-cibb-fw2-ironport", "rtp1-mda2-cibb-fw2-latisys"]
    # Gateway_Util.send_mail_from_server_cmd("noreply@cisco.com", ["shoraj@cisco.com"], "Lab High Rish script finished", "master.log")

    # print(Gateway_Util.get_wild_card_mask("1.1.1.1/26"))
    print(Gateway_Util.compare_subnet("10.126.0.0/24", "10.126.0.0/26"))
    
    #l = Gateway_Util.get_lab_from_desc("dskndjvn dndjn lab id LRT0012345 kjsbvkjs njvkj")
    #print(l)
    #a = Gateway_Util.get_lrt_formatted_id(l,"sjc-lab-gw1", "int1", "int ip", "dskndjvn dndjn 1234 kjsbvkjs njvkj")
    #print(a)
    #gw_with_ip =  ["mtv5-mda1-cibb-gw1", "sfo12-cibb-gw2", "sjc18-lab-gw2", "sjc22-lab-gw2", "sjc22-lab-gw1", "sjc18-lab-gw1", "tyoidc5-cp-pxtr1-gw2", "clg5-lab-gw1", "clg5-lab-gw2", "sjc12-cp-mgre1-gw1", "cjs04-lab-gw1", "wnp02-lab-gw1", "mxc-14-lab-gw1", "bnt01-lab-gw1", "lma1-lab-gw1", "bla-lab-gw1", "sjocr02-lab-gw1", "mxc10-lab-gw2", "mxc10-lab-gw1", "snt03-lab-gw1", "alln01-mda2-cp-pxtr1-gw2", "alln01-mda1-cibb-gw3", "rcdn9-cd1-cp-mgre1-gw1", "alln01-mda2-dmzaas-gw2", "alln01-mda1-cp-pxtr1-gw1", "alln01-mda2-cibb-gw4", "ast04-lab-gw1", "alln01-lab-gw1", "alln01-mda1-dmzaas-gw1", "rcdn9-cd2-cp-mgre1-gw2", "rcdn5-lab-sipt-sw1", "bgt2-lab-gw1", "rcdn5-lab-gw1", "ast09-lab-gw2", "ast09-lab-gw1", "glj3-lab-gw1", "bua2-lab-gw1", "spl1-lab-gw1", "ast04-cibb-gw2", "rcdn9-sdfc-dmzvaas-gw2", "rcdn9-sdfa-dmzvaas-gw1", "rcdn5-lab-gw2", "ast04-cibb-gw1", "rcdn6-lab-gw2", "rcdn9-sdfa-dmzvlab-gw1", "rcdn6-lab-gw1", "rcdn5-cibb-gw1", "rcdn9-cd2-lab-gw2", "rcdn9-cd1-lab-gw1", "rcdn5-dmzlab-gw2", "rcdn9-cd2-dmzaas-gw2", "rcdn9-cd1-dmzaas-gw1", "lion3-pl-lab-gw1", "ntn01-lab-gw1", "ntn01-lab-gw2", "mtl02-lab-gw1", "hal01-lab-gw1", "ntn01-cp-pxtr1-gw1", "bos02-lab-gw1", "nyc1-lab-gw1", "nyc1-lab-gw2", "awn01-lab-gw1", "ntn01-cp-pxtr1-gw2", "ott02-lab-gw1", "ott01-lab-gw1", "bxb23-lab-gw1", "cai02-lab-gw1", "bxb23-lab-gw2", "cas02-lab-gw1", "ryd4-lab-gw1", "waw02-lab-gw1", "man3-lab-gw1", "lys01-lab-gw1", "vnaa-lab-gw1", "got-lab-gw1", "dgm3-lab-gw2", "prg5-lab-gw1", "muc07-lab-gw1", "dgm2-lab-gw2", "vbn02-lab-gw1", "krk07-lab-gw2", "bts05-lab-gw1", "lys01-cibb-gw1", "ist2-lab-gw1", "sof7-lab-gw2", "cae02-lab-gw1", "zgr02-lab-gw1", "brc2-lab-gw2", "ams5-lab-gw1", "prg5-lab-gw2", "stk03-lab-gw2", "vbn02-lab-gw2", "bonn01-lab-gw1", "ath01-lab-gw1", "dblir3-lab-gw1", "cae02-lab-gw2", "lys01-lab-gw2", "brc2-lab-gw1", "mhm03-lab-gw1", "ibm3-bg-lab-gw1", "los03-lab-gw1", "ibm3-bg-lab-gw2", "dgm2-lab-gw3", "mdr1-lab-gw1", "dgm2-lab-gw1", "dlf1-lab-gw1", "dgm-lab-gw1", "krk07-lab-gw1", "lys01-cibb-gw2", "est1-jo-lab-gw1", "est1-jo-lab-gw2", "stk03-lab-gw1", "dgm3-lab-gw1", "vmct04-lab-gw1", "ala03-lab-gw1", "krk02-lab-gw1", "aer01-mda1-cp-pxtr1-gw1", "sof7-lab-gw1", "amm02-lab-gw1", "krk04-lab-gw1", "lon11-cibb-gw2", "doh03-lab-gw1", "sykes1-co-lab-gw1", "els01-lab-gw1", "wlsn01-lab-gw1", "loncaf-cp-pxtr1-gw1", "lju02-lab-gw1", "vmct05-lab-gw2", "loncaf-cp-pxtr1-gw2", "lon11-cibb-gw1", "tun03-lab-gw1", "cph06-lab-gw1", "rol01-lab-gw1", "stk06-lab-gw1", "beg02-lab-gw1", "aer01-mda1-lab-gw1", "aer01-mda2-cp-pxtr1-gw2", "stk06-lab-gw2", "aer01-mda2-lab-gw2", "lon06-lab-gw1", "musc01-lab-gw1", "sof2-lab-gw1", "vmct05-lab-gw1", "rom2-lab-gw1", "gpk03-lab-gw1", "els01-cibb-gw2", "aer01-mda2-cp-mgre1-gw2", "fkf3-lab-gw1", "gpk03-cibb-gw1", "fkf3-lab-gw2", "gpk03-cibb-gw2", "aer01-mda1-cp-mgre1-gw1", "gpk03-lab-gw2", "lon07-lab-gw1", "dbi03-lab-gw1", "bcr2-lab-gw1", "kjk04-lab-gw1", "nue01-lab-gw1", "nbo03-lab-gw1", "bud01-lab-gw1", "stg02-lab-gw1", "kwi01-lab-gw1", "gwy03-lab-gw1", "ips02-lab-gw1", "rtp1-mda2-cibbfo-sw1", "rtp1-mda2-cibbfo-sw2", "sjc20-cz-sdlab-gw1", "hrn6-lab-gw1", "hkg1-lab-gw2", "rtp1-mda2-cibb-fw1", "sjc21-cz-sdlab-gw2", "sjc20-cz-sdlab-gw2", "rtp1-mda2-cibb-fw1", "tpe02-lab-gw1", "sjc21-cz-sdlab-gw1", "hkg1-lab-gw1", "hrn6-lab-gw2", "atl-lab-gw1", "rtp1-mda2-cibb-wan-gw2", "rtp1-mda2-cibb-wan-gw1", "rtp10-cd-cp-mgre1-gw1", "lwr01-lab-gw1", "rtp7-cibb-gw1", "rtp10-cd-cp-pxtr1-gw1", "bjn6-lab-gw1", "lwr01-lab-gw2", "rtp1-mda2-cibb-fw1-ironport", "knv-lab-gw1", "bjn6-lab-gw2", "knv3-cibb-gw2", "knv3-cibb-gw1", "stld1-mda1-cp-mgre1-gw1", "stld1-mda2-cp-mgre1-gw2", "csb04-lab-gw2", "csb04-lab-gw1", "blndc01-lab-gw2", "blndc01-lab-gw1", "rtp5-dmzvlab-gw1", "ann01-lab-gw1", "shnidc-cp-pxtr1-gw2", "mrd01-lab-gw2", "mrd01-lab-gw1", "mim1-lab-gw1", "shnidc-cp-pxtr1-gw1", "esp02-lab-gw1", "prg7-lab-gw2", "prg7-lab-gw1", "alp03-lab-gw2", "rtp10-cd-dmzvlab-gw1", "sngidc-cp-pxtr1-gw2", "rtp1-mda1-cp-mgre1-gw1", "alp03-lab-gw1", "cgn03-lab-gw2", "wdf02-lab-gw1", "cgn03-lab-gw1", "rtp10-cd-dmzaas-gw1", "chn09-lab-gw2", "chn09-lab-gw1", "chg12-lab-gw2", "chg12-cibb-gw1", "chg12-cibb-gw2", "chg12-lab-gw1", "tul04-lab-gw2", "tul04-lab-gw1", "sjc05-cp-mgre1-gw1", "hcl7-in-lab-gw1", "hcl7-in-lab-gw2", "sngidc-cp-pxtr1-gw1", "hbg-lab-gw1", "rtp5-cibb-gw1", "trn6-lab-gw1", "trn6-lab-gw2", "rtp7-lab-gw1", "ful01-lab-gw2", "ful01-lab-gw1", "wshdc02-lab-gw1", "rtp3-lab-gw1", "rtp10-00-lab-gw2", "rtp9-lab-gw1", "rtp4-00-lab-gw2", "rtp2-lab-gw1", "sla01-lab-gw2", "rtp1-lab-gw1", "rtp12-00-lab-gw2", "rtp1-lab-gw2", "rtp12-00-lab-gw1", "rtp6-lab-gw2", "sla01-lab-gw1", "rtp6-lab-gw1", "rtp9-lab-gw2", "rtp11-lab-gw1", "sykes2-cr-lab-gw1", "req02-lab-gw1", "sol2-lab-gw1", "sea1-lab-gw1", "rtp5-lab-gw1", "rtp11-lab-gw2", "rtp1-mda1-cp-pxtr1-gw1", "rtp7-lab-gw2", "rtp8-lab-gw2", "embsys2-in-lab-gw2", "embsys2-in-lab-gw1", "sngidc-dmzvlab-gw1", "sngidc-dmzvlab-gw2", "pen3-lab-gw1", "pen3-lab-gw2", "jkt05-lab-gw2", "jkt05-lab-gw1", "rtp1-dmzvaas-gw1", "rtp7-dmzvaas-gw1", "ful01-fw1", "rtp5-dmzlab-gw1", "rtp8-lab-gw1", "req01-lab-gw1", "rtp1-dmzlab-gw1", "rtp11-dmzlab-gw1", "csv-lab-gw1", "atl11-lab-gw2", "atl11-lab-gw1", "ors03-lab-gw2", "cwy01-lab-gw1", "ors03-lab-gw1", "cwy01-lab-gw2", "gai03-lab-gw2", "bel01-lab-gw2", "bel01-lab-gw1", "aar02-lab-gw1", "bln2-lab-gw2", "gai03-lab-gw1", "bln2-lab-gw1", "tyoidc5-cp-pxtr1-gw1", "twl03-lab-gw1", "mil01-lab-gw1", "mil01-lab-gw2", "schp01-lab-gw1", "bgl16-00-lab-gw1", "argrp4-in-lab-gw1", "wpr2-in-lab-gw1", "bgl16-00-lab-gw2", "argrp4-in-lab-gw2", "bgl17-cp-mgre1-gw1", "argrp1-in-lab-gw1", "mtc2-in-lab-gw1", "bgl13-lab-gw2", "bgl13-cp-pxtr1-gw1", "bgl13-cibb-gw1", "bgl17-cp-pxtr1-gw1", "bgl13-lab-gw1", "bgl17-cibb-gw1", "pnq05-lab-gw2", "pnq05-lab-gw1", "hcl14-in-lab-gw1", "hcl14-in-lab-gw2", "bgl18-00-lab-gw1", "cmb03-lab-gw1", "infy9-in-lab-gw1", "bgl13-cp-mgre1-gw1", "bgl14-00-lab-gw1", "bgl18-00-lab-gw2", "bgl14-00-lab-gw2", "chn08-lab-gw1", "ggn01-lab-gw1", "ggn01-lab-gw2", "bgl26-lab-gw1", "shn15-lab-gw1", "argrp5-in-lab-gw1", "bgl17-00-lab-gw1", "bgl17-00-lab-gw2", "wpr8-in-lab-gw1", "hcl19-in-lab-gw2", "hcl19-in-lab-gw1", "bgl11-00-lab-gw2", "bgl11-00-lab-gw1", "bgl12-00-lab-gw1", "mmb12-lab-gw1", "mmb12-lab-gw2", "bgl12-00-lab-gw2", "kul02-lab-gw1", "bgl15-00-lab-gw1", "bgl15-00-lab-gw2", "hcl17-in-lab-gw1", "hcl17-in-lab-gw2", "bng02-lab-gw1", "hgh06-ext-lab-gw2", "hgh06-ext-lab-gw1", "sngdc01-mda2-cibb-gw2", "sngdc01-mda1-cibb-gw1", "akl02-lab-gw1", "mel03-lab-gw1", "tky7-lab-gw1", "hgh05-lab-gw1", "shn4-cibb-gw1", "shn15-lab-gw2", "shn6-lab-gw1", "shn7-lab-gw2", "tky7-lab-gw2", "ngo1-lab-gw1", "sng15-lab-gw1", "shn7-lab-gw1", "shn4-lab-gw2", "shn4-cibb-gw2", "shn4-lab-gw1", "sng15-lab-gw2", "prt3-lab-gw1", "nsd5-lab-gw2", "nsd5-lab-gw1", "cbr04-lab-gw1", "foxc1-cn-lab-gw1", "gng03-lab-gw1", "hfe02-lab-gw1", "hfe02-lab-gw2", "tky7-cibb-gw2", "tky7-cibb-gw1", "stld1-lab-gw2", "stld1-lab-gw1", "szn04-lab-gw1", "szn05-lab-gw1", "wln2-lab-gw1", "hni05-lab-gw1", "dlc02-lab-gw1", "dlc02-lab-gw2", "fka1-lab-gw1", "osk04-lab-gw1", "brb05-lab-gw1", "sngdc01-mda2-dmzaas-gw2", "sngdc01-mda1-dmzaas-gw1", "mnl02-lab-gw1", "shn17-lab-gw1", "shn17-lab-gw2", "svta01-lab-gw1", "yer03-lab-gw1", "sjc23-lab-gw2", "sjc21-lab-gw1", "sjc20-cibb5-gw1", "sjc20-lab-gw1", "sjcp-lab-gw2", "sjc23-lab-gw1", "sjc24-lab-gw1", "sjc21-lab-gw2", "sjc24-lab-gw2", "sjc20-lab-gw2", "sjcp-lab-gw1", "bvw01-lab-gw1", "sea1-lab-gw2", "vnc2-lab-gw1", "sjc5-cibbfo-sw2", "sjc5-cibbfo-sw1", "sjc5-cibb-wan-gw1", "sjc5-cibb-fw1", "wlt06-lab-gw2", "sjc12-dmzvaas-gw1", "sjc05-dmzvaas-gw1", "blv-lab-gw1", "wlt06-lab-gw1", "sjc5-cibb-fw1-ironport", "sjc12-cibb4-gw1", "sjc5-cibb-wan-gw2", "sjc12-lab-gw1", "sjc12-cp-pxtr1-gw1", "sfo12-cibb-gw1", "sjc5-cibb4-gw1", "sjc05-cp-pxtr1-gw1", "sjc02-lab-gw1", "sjc14-lab-gw1", "sjc16-lab-gw1", "sjc11-lab-gw1", "sjc08-lab-gw1", "sjc03-lab-gw1", "sjc01-lab-gw1", "sjc5-cibb4-gw2", "sjc15-lab-gw2", "sjc09-lab-gw1", "sjc07-lab-gw1", "sjc17-lab-gw1", "sjc13-lab-gw1", "sjc06-lab-gw2", "sjc04-lab-gw1", "sjc15-lab-gw1", "sjc19-lab-gw1", "sjc10-lab-gw1", "sjc04-lab-gw2", "sjc16-lab-gw2", "sjc14-lab-gw2", "sjc03-lab-gw2", "sjc13-lab-gw2", "sjc05-lab-gw2", "sjc06-lab-gw1", "sjc02-lab-gw2", "sjc01-lab-gw2", "sjc05-lab-gw1", "sjc09-lab-gw2", "sjc12-cibb4-gw2", "sjc10-lab-gw2", "sjc19-lab-gw2", "sjc08-lab-gw2", "sjc12-lab-gw2", "sjc07-lab-gw2", "sjc17-lab-gw2", "csb03-lab-gw1", "syc02-lab-gw1", "cosm02-lab-gw1", "sprg01-lab-gw2", "irv8-lab-gw1", "csb03-lab-gw2", "lux1-lab-gw1", "rtp5-lab-gw2", "rtp4-00-lab-gw1", "bgl17-dmzvlab-gw1", "bgl13-dmzaas-gw1", "bgl17-dmzaas-gw1", "bgl25-lab-gw1", "rcdn6-cibb-gw1", "sprg01-lab-gw1", "sjc23-cibb5-gw1", "par03-lab-gw2", "par03-lab-gw1", "bdlk11-cibb-gw1", "bdlk09-00-lab-gw1", "bdlk10-31-lab-gw1", "bdlk09-12-lab-gw1", "bdlk09-cibb-gw1", "bdlk10-00-lab-gw1", "bdlk09-00-lab-gw2", "bdlk11-00-lab-gw2", "bdlk11-00-lab-gw1", "rtp10-00-lab-gw1", "rtp5-dmzaas-gw1", "lon06-cibb-gw1", "els01-cibb-gw1", "mtv5-mda2-cibb-gw2", "sjc05-dmzvlab-gw1", "sjc5-cibb-fw2-ironport", "sjc5-cibb-fw2", "rtp1-mda2-cibb-fw2", "rtp1-mda2-cibb-fw2-ironport", "rtp1-mda2-cibb-fw2-latisys"]
    #print len(gw_with_ip)
    # gw_with_ip =  [["mtv5-mda1-cibb-gw1", None], ["sfo12-cibb-gw2"], ["sjc18-lab-gw2"], ["sjc22-lab-gw2"], ["sjc22-lab-gw1"], ["sjc18-lab-gw1"], ["tyoidc5-cp-pxtr1-gw2"], ["clg5-lab-gw1"], ["clg5-lab-gw2"], ["sjc12-cp-mgre1-gw1"], ["cjs04-lab-gw1"], ["wnp02-lab-gw1"], ["mxc-14-lab-gw1"], ["bnt01-lab-gw1"], ["lma1-lab-gw1"], ["bla-lab-gw1"], ["sjocr02-lab-gw1"], ["mxc10-lab-gw2"], ["mxc10-lab-gw1"], ["snt03-lab-gw1"], ["alln01-mda2-cp-pxtr1-gw2"], ["alln01-mda1-cibb-gw3"], ["rcdn9-cd1-cp-mgre1-gw1"], ["alln01-mda2-dmzaas-gw2"], ["alln01-mda1-cp-pxtr1-gw1"], ["alln01-mda2-cibb-gw4"], ["ast04-lab-gw1"], ["alln01-lab-gw1"], ["alln01-mda1-dmzaas-gw1"], ["rcdn9-cd2-cp-mgre1-gw2"], ["rcdn5-lab-sipt-sw1"], ["bgt2-lab-gw1"], ["rcdn5-lab-gw1"], ["ast09-lab-gw2"], ["ast09-lab-gw1"], ["glj3-lab-gw1"], ["bua2-lab-gw1"], ["spl1-lab-gw1"], ["ast04-cibb-gw2"], ["rcdn9-sdfc-dmzvaas-gw2"], ["rcdn9-sdfa-dmzvaas-gw1"], ["rcdn5-lab-gw2"], ["ast04-cibb-gw1"], ["rcdn6-lab-gw2"], ["rcdn9-sdfa-dmzvlab-gw1"], ["rcdn6-lab-gw1"], ["rcdn5-cibb-gw1"], ["rcdn9-cd2-lab-gw2"], ["rcdn9-cd1-lab-gw1"], ["rcdn5-dmzlab-gw2"], ["rcdn9-cd2-dmzaas-gw2"], ["rcdn9-cd1-dmzaas-gw1"], ["lion3-pl-lab-gw1"], ["ntn01-lab-gw1"], ["ntn01-lab-gw2"], ["mtl02-lab-gw1"], ["hal01-lab-gw1"], ["ntn01-cp-pxtr1-gw1"], ["bos02-lab-gw1"], ["nyc1-lab-gw1"], ["nyc1-lab-gw2"], ["awn01-lab-gw1"], ["ntn01-cp-pxtr1-gw2"], ["ott02-lab-gw1"], ["ott01-lab-gw1"], ["bxb23-lab-gw1"], ["cai02-lab-gw1"], ["bxb23-lab-gw2"], ["cas02-lab-gw1"], ["ryd4-lab-gw1"], ["waw02-lab-gw1"], ["man3-lab-gw1"], ["lys01-lab-gw1"], ["vnaa-lab-gw1"], ["got-lab-gw1"], ["dgm3-lab-gw2"], ["prg5-lab-gw1"], ["muc07-lab-gw1"], ["dgm2-lab-gw2"], ["vbn02-lab-gw1"], ["krk07-lab-gw2"], ["bts05-lab-gw1"], ["lys01-cibb-gw1"], ["ist2-lab-gw1"], ["sof7-lab-gw2"], ["cae02-lab-gw1"], ["zgr02-lab-gw1"], ["brc2-lab-gw2"], ["ams5-lab-gw1"], ["prg5-lab-gw2"], ["stk03-lab-gw2"], ["vbn02-lab-gw2"], ["bonn01-lab-gw1"], ["ath01-lab-gw1"], ["dblir3-lab-gw1"], ["cae02-lab-gw2"], ["lys01-lab-gw2"], ["brc2-lab-gw1"], ["mhm03-lab-gw1"], ["ibm3-bg-lab-gw1"], ["los03-lab-gw1"], ["ibm3-bg-lab-gw2"], ["dgm2-lab-gw3"], ["mdr1-lab-gw1"], ["dgm2-lab-gw1"], ["dlf1-lab-gw1"], ["dgm-lab-gw1"], ["krk07-lab-gw1"], ["lys01-cibb-gw2"], ["est1-jo-lab-gw1"], ["est1-jo-lab-gw2"], ["stk03-lab-gw1"], ["dgm3-lab-gw1"], ["vmct04-lab-gw1"], ["ala03-lab-gw1"], ["krk02-lab-gw1"], ["aer01-mda1-cp-pxtr1-gw1"], ["sof7-lab-gw1"], ["amm02-lab-gw1"], ["krk04-lab-gw1"], ["lon11-cibb-gw2"], ["doh03-lab-gw1"], ["sykes1-co-lab-gw1"], ["els01-lab-gw1"], ["wlsn01-lab-gw1"], ["loncaf-cp-pxtr1-gw1"], ["lju02-lab-gw1"], ["vmct05-lab-gw2"], ["loncaf-cp-pxtr1-gw2"], ["lon11-cibb-gw1"], ["tun03-lab-gw1"], ["cph06-lab-gw1"], ["rol01-lab-gw1"], ["stk06-lab-gw1"], ["beg02-lab-gw1"], ["aer01-mda1-lab-gw1"], ["aer01-mda2-cp-pxtr1-gw2"], ["stk06-lab-gw2"], ["aer01-mda2-lab-gw2"], ["lon06-lab-gw1"], ["musc01-lab-gw1"], ["sof2-lab-gw1"], ["vmct05-lab-gw1"], ["rom2-lab-gw1"], ["gpk03-lab-gw1"], ["els01-cibb-gw2"], ["aer01-mda2-cp-mgre1-gw2"], ["fkf3-lab-gw1"], ["gpk03-cibb-gw1"], ["fkf3-lab-gw2"], ["gpk03-cibb-gw2"], ["aer01-mda1-cp-mgre1-gw1"], ["gpk03-lab-gw2"], ["lon07-lab-gw1"], ["dbi03-lab-gw1"], ["bcr2-lab-gw1"], ["kjk04-lab-gw1"], ["nue01-lab-gw1"], ["nbo03-lab-gw1"], ["bud01-lab-gw1"], ["stg02-lab-gw1"], ["kwi01-lab-gw1"], ["gwy03-lab-gw1"], ["ips02-lab-gw1"], ["rtp1-mda2-cibbfo-sw1"], ["rtp1-mda2-cibbfo-sw2"], ["sjc20-cz-sdlab-gw1"], ["hrn6-lab-gw1"], ["hkg1-lab-gw2"], ["rtp1-mda2-cibb-fw1"], ["sjc21-cz-sdlab-gw2"], ["sjc20-cz-sdlab-gw2"], ["rtp1-mda2-cibb-fw1"], ["tpe02-lab-gw1"], ["sjc21-cz-sdlab-gw1"], ["hkg1-lab-gw1"], ["hrn6-lab-gw2"], ["atl-lab-gw1"], ["rtp1-mda2-cibb-wan-gw2"], ["rtp1-mda2-cibb-wan-gw1"], ["rtp10-cd-cp-mgre1-gw1"], ["lwr01-lab-gw1"], ["rtp7-cibb-gw1"], ["rtp10-cd-cp-pxtr1-gw1"], ["bjn6-lab-gw1"], ["lwr01-lab-gw2"], ["rtp1-mda2-cibb-fw1-ironport"], ["knv-lab-gw1"], ["bjn6-lab-gw2"], ["knv3-cibb-gw2"], ["knv3-cibb-gw1"], ["stld1-mda1-cp-mgre1-gw1"], ["stld1-mda2-cp-mgre1-gw2"], ["csb04-lab-gw2"], ["csb04-lab-gw1"], ["blndc01-lab-gw2"], ["blndc01-lab-gw1"], ["rtp5-dmzvlab-gw1"], ["ann01-lab-gw1"], ["shnidc-cp-pxtr1-gw2"], ["mrd01-lab-gw2"], ["mrd01-lab-gw1"], ["mim1-lab-gw1"], ["shnidc-cp-pxtr1-gw1"], ["esp02-lab-gw1"], ["prg7-lab-gw2"], ["prg7-lab-gw1"], ["alp03-lab-gw2"], ["rtp10-cd-dmzvlab-gw1"], ["sngidc-cp-pxtr1-gw2"], ["rtp1-mda1-cp-mgre1-gw1"], ["alp03-lab-gw1"], ["cgn03-lab-gw2"], ["wdf02-lab-gw1"], ["cgn03-lab-gw1"], ["rtp10-cd-dmzaas-gw1"], ["chn09-lab-gw2"], ["chn09-lab-gw1"], ["chg12-lab-gw2"], ["chg12-cibb-gw1"], ["chg12-cibb-gw2"], ["chg12-lab-gw1"], ["tul04-lab-gw2"], ["tul04-lab-gw1"], ["sjc05-cp-mgre1-gw1"], ["hcl7-in-lab-gw1"], ["hcl7-in-lab-gw2"], ["sngidc-cp-pxtr1-gw1"], ["hbg-lab-gw1"], ["rtp5-cibb-gw1"], ["trn6-lab-gw1"], ["trn6-lab-gw2"], ["rtp7-lab-gw1"], ["ful01-lab-gw2"], ["ful01-lab-gw1"], ["wshdc02-lab-gw1"], ["rtp3-lab-gw1"], ["rtp10-00-lab-gw2"], ["rtp9-lab-gw1"], ["rtp4-00-lab-gw2"], ["rtp2-lab-gw1"], ["sla01-lab-gw2"], ["rtp1-lab-gw1"], ["rtp12-00-lab-gw2"], ["rtp1-lab-gw2"], ["rtp12-00-lab-gw1"], ["rtp6-lab-gw2"], ["sla01-lab-gw1"], ["rtp6-lab-gw1"], ["rtp9-lab-gw2"], ["rtp11-lab-gw1"], ["sykes2-cr-lab-gw1"], ["req02-lab-gw1"], ["sol2-lab-gw1"], ["sea1-lab-gw1"], ["rtp5-lab-gw1"], ["rtp11-lab-gw2"], ["rtp1-mda1-cp-pxtr1-gw1"], ["rtp7-lab-gw2"], ["rtp8-lab-gw2"], ["embsys2-in-lab-gw2"], ["embsys2-in-lab-gw1"], ["sngidc-dmzvlab-gw1"], ["sngidc-dmzvlab-gw2"], ["pen3-lab-gw1"], ["pen3-lab-gw2"], ["jkt05-lab-gw2"], ["jkt05-lab-gw1"], ["rtp1-dmzvaas-gw1"], ["rtp7-dmzvaas-gw1"], ["ful01-fw1"], ["rtp5-dmzlab-gw1"], ["rtp8-lab-gw1"], ["req01-lab-gw1"], ["rtp1-dmzlab-gw1"], ["rtp11-dmzlab-gw1"], ["csv-lab-gw1"], ["atl11-lab-gw2"], ["atl11-lab-gw1"], ["ors03-lab-gw2"], ["cwy01-lab-gw1"], ["ors03-lab-gw1"], ["cwy01-lab-gw2"], ["gai03-lab-gw2"], ["bel01-lab-gw2"], ["bel01-lab-gw1"], ["aar02-lab-gw1"], ["bln2-lab-gw2"], ["gai03-lab-gw1"], ["bln2-lab-gw1"], ["tyoidc5-cp-pxtr1-gw1"], ["twl03-lab-gw1"], ["mil01-lab-gw1"], ["mil01-lab-gw2"], ["schp01-lab-gw1"], ["bgl16-00-lab-gw1"], ["argrp4-in-lab-gw1"], ["wpr2-in-lab-gw1"], ["bgl16-00-lab-gw2"], ["argrp4-in-lab-gw2"], ["bgl17-cp-mgre1-gw1"], ["argrp1-in-lab-gw1"], ["mtc2-in-lab-gw1"], ["bgl13-lab-gw2"], ["bgl13-cp-pxtr1-gw1"], ["bgl13-cibb-gw1"], ["bgl17-cp-pxtr1-gw1"], ["bgl13-lab-gw1"], ["bgl17-cibb-gw1"], ["pnq05-lab-gw2"], ["pnq05-lab-gw1"], ["hcl14-in-lab-gw1"], ["hcl14-in-lab-gw2"], ["bgl18-00-lab-gw1"], ["cmb03-lab-gw1"], ["infy9-in-lab-gw1"], ["bgl13-cp-mgre1-gw1"], ["bgl14-00-lab-gw1"], ["bgl18-00-lab-gw2"], ["bgl14-00-lab-gw2"], ["chn08-lab-gw1"], ["ggn01-lab-gw1"], ["ggn01-lab-gw2"], ["bgl26-lab-gw1"], ["shn15-lab-gw1"], ["argrp5-in-lab-gw1"], ["bgl17-00-lab-gw1"], ["bgl17-00-lab-gw2"], ["wpr8-in-lab-gw1"], ["hcl19-in-lab-gw2"], ["hcl19-in-lab-gw1"], ["bgl11-00-lab-gw2"], ["bgl11-00-lab-gw1"], ["bgl12-00-lab-gw1"], ["mmb12-lab-gw1"], ["mmb12-lab-gw2"], ["bgl12-00-lab-gw2"], ["kul02-lab-gw1"], ["bgl15-00-lab-gw1"], ["bgl15-00-lab-gw2"], ["hcl17-in-lab-gw1"], ["hcl17-in-lab-gw2"], ["bng02-lab-gw1"], ["hgh06-ext-lab-gw2"], ["hgh06-ext-lab-gw1"], ["sngdc01-mda2-cibb-gw2"], ["sngdc01-mda1-cibb-gw1"], ["akl02-lab-gw1"], ["mel03-lab-gw1"], ["tky7-lab-gw1"], ["hgh05-lab-gw1"], ["shn4-cibb-gw1"], ["shn15-lab-gw2"], ["shn6-lab-gw1"], ["shn7-lab-gw2"], ["tky7-lab-gw2"], ["ngo1-lab-gw1"], ["sng15-lab-gw1"], ["shn7-lab-gw1"], ["shn4-lab-gw2"], ["shn4-cibb-gw2"], ["shn4-lab-gw1"], ["sng15-lab-gw2"], ["prt3-lab-gw1"], ["nsd5-lab-gw2"], ["nsd5-lab-gw1"], ["cbr04-lab-gw1"], ["foxc1-cn-lab-gw1"], ["gng03-lab-gw1"], ["hfe02-lab-gw1"], ["hfe02-lab-gw2"], ["tky7-cibb-gw2"], ["tky7-cibb-gw1"], ["stld1-lab-gw2"], ["stld1-lab-gw1"], ["szn04-lab-gw1"], ["szn05-lab-gw1"], ["wln2-lab-gw1"], ["hni05-lab-gw1"], ["dlc02-lab-gw1"], ["dlc02-lab-gw2"], ["fka1-lab-gw1"], ["osk04-lab-gw1"], ["brb05-lab-gw1"], ["sngdc01-mda2-dmzaas-gw2"], ["sngdc01-mda1-dmzaas-gw1"], ["mnl02-lab-gw1"], ["shn17-lab-gw1"], ["shn17-lab-gw2"], ["svta01-lab-gw1"], ["yer03-lab-gw1"], ["sjc23-lab-gw2"], ["sjc21-lab-gw1"], ["sjc20-cibb5-gw1"], ["sjc20-lab-gw1"], ["sjcp-lab-gw2"], ["sjc23-lab-gw1"], ["sjc24-lab-gw1"], ["sjc21-lab-gw2"], ["sjc24-lab-gw2"], ["sjc20-lab-gw2"], ["sjcp-lab-gw1"], ["bvw01-lab-gw1"], ["sea1-lab-gw2"], ["vnc2-lab-gw1"], ["sjc5-cibbfo-sw2"], ["sjc5-cibbfo-sw1"], ["sjc5-cibb-wan-gw1"], ["sjc5-cibb-fw1"], ["wlt06-lab-gw2"], ["sjc12-dmzvaas-gw1"], ["sjc05-dmzvaas-gw1"], ["blv-lab-gw1"], ["wlt06-lab-gw1"], ["sjc5-cibb-fw1-ironport"], ["sjc12-cibb4-gw1"], ["sjc5-cibb-wan-gw2"], ["sjc12-lab-gw1"], ["sjc12-cp-pxtr1-gw1"], ["sfo12-cibb-gw1"], ["sjc5-cibb4-gw1"], ["sjc05-cp-pxtr1-gw1"], ["sjc02-lab-gw1"], ["sjc14-lab-gw1"], ["sjc16-lab-gw1"], ["sjc11-lab-gw1"], ["sjc08-lab-gw1"], ["sjc03-lab-gw1"], ["sjc01-lab-gw1"], ["sjc5-cibb4-gw2"], ["sjc15-lab-gw2"], ["sjc09-lab-gw1"], ["sjc07-lab-gw1"], ["sjc17-lab-gw1"], ["sjc13-lab-gw1"], ["sjc06-lab-gw2"], ["sjc04-lab-gw1"], ["sjc15-lab-gw1"], ["sjc19-lab-gw1"], ["sjc10-lab-gw1"], ["sjc04-lab-gw2"], ["sjc16-lab-gw2"], ["sjc14-lab-gw2"], ["sjc03-lab-gw2"], ["sjc13-lab-gw2"], ["sjc05-lab-gw2"], ["sjc06-lab-gw1"], ["sjc02-lab-gw2"], ["sjc01-lab-gw2"], ["sjc05-lab-gw1"], ["sjc09-lab-gw2"], ["sjc12-cibb4-gw2"], ["sjc10-lab-gw2"], ["sjc19-lab-gw2"], ["sjc08-lab-gw2"], ["sjc12-lab-gw2"], ["sjc07-lab-gw2"], ["sjc17-lab-gw2"], ["csb03-lab-gw1"], ["syc02-lab-gw1"], ["cosm02-lab-gw1"], ["sprg01-lab-gw2"], ["irv8-lab-gw1"], ["csb03-lab-gw2"], ["lux1-lab-gw1"], ["rtp5-lab-gw2"], ["rtp4-00-lab-gw1"], ["bgl17-dmzvlab-gw1"], ["bgl13-dmzaas-gw1"], ["bgl17-dmzaas-gw1"], ["bgl25-lab-gw1"], ["rcdn6-cibb-gw1"], ["sprg01-lab-gw1"], ["sjc23-cibb5-gw1"], ["par03-lab-gw2"], ["par03-lab-gw1"], ["bdlk11-cibb-gw1"], ["bdlk09-00-lab-gw1"], ["bdlk10-31-lab-gw1"], ["bdlk09-12-lab-gw1"], ["bdlk09-cibb-gw1"], ["bdlk10-00-lab-gw1"], ["bdlk09-00-lab-gw2"], ["bdlk11-00-lab-gw2"], ["bdlk11-00-lab-gw1"], ["rtp10-00-lab-gw1"], ["rtp5-dmzaas-gw1"], ["lon06-cibb-gw1"], ["els01-cibb-gw1"], ["mtv5-mda2-cibb-gw2"], ["sjc05-dmzvlab-gw1"], ["sjc5-cibb-fw2-ironport"], ["sjc5-cibb-fw2"], ["rtp1-mda2-cibb-fw2"], ["rtp1-mda2-cibb-fw2-ironport"], ["rtp1-mda2-cibb-fw2-latisys"]]
    #Gateway_Util.get_ip_address_by_nslookup(gw_with_ip)

    # a = Gateway_Util.get_out_acl("ip access-group abcd in")
    # print(a)

    # c = ["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Forwarding Info", 
    #                          "OutACL", "Raw ACL Line", "UDP Risk Port", "TCP Risk Port", "Any Any"]
    # d = [c,c,c,c,c,c,c,c,c,c,c,c]
    # Gateway_Util.save_data_to_new_csv("Lab_High_Rish_Report", c, d)

    #print(Gateway_Util.is_valid_lrt_id("LRT0012345"))

    # gw = ["mtv5-mda1-cibb-gw1", "sfo12-cibb-gw2", "sjc18-lab-gw2", "sjc22-lab-gw2", "sjc22-lab-gw1", "sjc18-lab-gw1", "tyoidc5-cp-pxtr1-gw2", "clg5-lab-gw1", "clg5-lab-gw2", "sjc12-cp-mgre1-gw1", "cjs04-lab-gw1", "wnp02-lab-gw1", "mxc-14-lab-gw1", "bnt01-lab-gw1", "lma1-lab-gw1", "bla-lab-gw1", "sjocr02-lab-gw1", "mxc10-lab-gw2", "mxc10-lab-gw1", "snt03-lab-gw1", "alln01-mda2-cp-pxtr1-gw2", "alln01-mda1-cibb-gw3", "rcdn9-cd1-cp-mgre1-gw1", "alln01-mda2-dmzaas-gw2", "alln01-mda1-cp-pxtr1-gw1", "alln01-mda2-cibb-gw4", "ast04-lab-gw1", "alln01-lab-gw1", "alln01-mda1-dmzaas-gw1", "rcdn9-cd2-cp-mgre1-gw2", "rcdn5-lab-sipt-sw1", "bgt2-lab-gw1", "rcdn5-lab-gw1", "ast09-lab-gw2", "ast09-lab-gw1", "glj3-lab-gw1", "bua2-lab-gw1", "spl1-lab-gw1", "ast04-cibb-gw2", "rcdn9-sdfc-dmzvaas-gw2", "rcdn9-sdfa-dmzvaas-gw1", "rcdn5-lab-gw2", "ast04-cibb-gw1", "rcdn6-lab-gw2", "rcdn9-sdfa-dmzvlab-gw1", "rcdn6-lab-gw1", "rcdn5-cibb-gw1", "rcdn9-cd2-lab-gw2", "rcdn9-cd1-lab-gw1", "rcdn5-dmzlab-gw2", "rcdn9-cd2-dmzaas-gw2", "rcdn9-cd1-dmzaas-gw1", "lion3-pl-lab-gw1", "ntn01-lab-gw1", "ntn01-lab-gw2", "mtl02-lab-gw1", "hal01-lab-gw1", "ntn01-cp-pxtr1-gw1", "bos02-lab-gw1", "nyc1-lab-gw1", "nyc1-lab-gw2", "awn01-lab-gw1", "ntn01-cp-pxtr1-gw2", "ott02-lab-gw1", "ott01-lab-gw1", "bxb23-lab-gw1", "cai02-lab-gw1", "bxb23-lab-gw2", "cas02-lab-gw1", "ryd4-lab-gw1", "waw02-lab-gw1", "man3-lab-gw1", "lys01-lab-gw1", "vnaa-lab-gw1", "got-lab-gw1", "dgm3-lab-gw2", "prg5-lab-gw1", "muc07-lab-gw1", "dgm2-lab-gw2", "vbn02-lab-gw1", "krk07-lab-gw2", "bts05-lab-gw1", "lys01-cibb-gw1", "ist2-lab-gw1", "sof7-lab-gw2", "cae02-lab-gw1", "zgr02-lab-gw1", "brc2-lab-gw2", "ams5-lab-gw1", "prg5-lab-gw2", "stk03-lab-gw2", "vbn02-lab-gw2", "bonn01-lab-gw1", "ath01-lab-gw1", "dblir3-lab-gw1", "cae02-lab-gw2", "lys01-lab-gw2", "brc2-lab-gw1", "mhm03-lab-gw1", "ibm3-bg-lab-gw1", "los03-lab-gw1", "ibm3-bg-lab-gw2", "dgm2-lab-gw3", "mdr1-lab-gw1", "dgm2-lab-gw1", "dlf1-lab-gw1", "dgm-lab-gw1", "krk07-lab-gw1", "lys01-cibb-gw2", "est1-jo-lab-gw1", "est1-jo-lab-gw2", "stk03-lab-gw1", "dgm3-lab-gw1", "vmct04-lab-gw1", "ala03-lab-gw1", "krk02-lab-gw1", "aer01-mda1-cp-pxtr1-gw1", "sof7-lab-gw1", "amm02-lab-gw1", "krk04-lab-gw1", "lon11-cibb-gw2", "doh03-lab-gw1", "sykes1-co-lab-gw1", "els01-lab-gw1", "wlsn01-lab-gw1", "loncaf-cp-pxtr1-gw1", "lju02-lab-gw1", "vmct05-lab-gw2", "loncaf-cp-pxtr1-gw2", "lon11-cibb-gw1", "tun03-lab-gw1", "cph06-lab-gw1", "rol01-lab-gw1", "stk06-lab-gw1", "beg02-lab-gw1", "aer01-mda1-lab-gw1", "aer01-mda2-cp-pxtr1-gw2", "stk06-lab-gw2", "aer01-mda2-lab-gw2", "lon06-lab-gw1", "musc01-lab-gw1", "sof2-lab-gw1", "vmct05-lab-gw1", "rom2-lab-gw1", "gpk03-lab-gw1", "els01-cibb-gw2", "aer01-mda2-cp-mgre1-gw2", "fkf3-lab-gw1", "gpk03-cibb-gw1", "fkf3-lab-gw2", "gpk03-cibb-gw2", "aer01-mda1-cp-mgre1-gw1", "gpk03-lab-gw2", "lon07-lab-gw1", "dbi03-lab-gw1", "bcr2-lab-gw1", "kjk04-lab-gw1", "nue01-lab-gw1", "nbo03-lab-gw1", "bud01-lab-gw1", "stg02-lab-gw1", "kwi01-lab-gw1", "gwy03-lab-gw1", "ips02-lab-gw1", "rtp1-mda2-cibbfo-sw1", "rtp1-mda2-cibbfo-sw2", "sjc20-cz-sdlab-gw1", "hrn6-lab-gw1", "hkg1-lab-gw2", "rtp1-mda2-cibb-fw1", "sjc21-cz-sdlab-gw2", "sjc20-cz-sdlab-gw2", "rtp1-mda2-cibb-fw1", "tpe02-lab-gw1", "sjc21-cz-sdlab-gw1", "hkg1-lab-gw1", "hrn6-lab-gw2", "atl-lab-gw1", "rtp1-mda2-cibb-wan-gw2", "rtp1-mda2-cibb-wan-gw1", "rtp10-cd-cp-mgre1-gw1", "lwr01-lab-gw1", "rtp7-cibb-gw1", "rtp10-cd-cp-pxtr1-gw1", "bjn6-lab-gw1", "lwr01-lab-gw2", "rtp1-mda2-cibb-fw1-ironport", "knv-lab-gw1", "bjn6-lab-gw2", "knv3-cibb-gw2", "knv3-cibb-gw1", "stld1-mda1-cp-mgre1-gw1", "stld1-mda2-cp-mgre1-gw2", "csb04-lab-gw2", "csb04-lab-gw1", "blndc01-lab-gw2", "blndc01-lab-gw1", "rtp5-dmzvlab-gw1", "ann01-lab-gw1", "shnidc-cp-pxtr1-gw2", "mrd01-lab-gw2", "mrd01-lab-gw1", "mim1-lab-gw1", "shnidc-cp-pxtr1-gw1", "esp02-lab-gw1", "prg7-lab-gw2", "prg7-lab-gw1", "alp03-lab-gw2", "rtp10-cd-dmzvlab-gw1", "sngidc-cp-pxtr1-gw2", "rtp1-mda1-cp-mgre1-gw1", "alp03-lab-gw1", "cgn03-lab-gw2", "wdf02-lab-gw1", "cgn03-lab-gw1", "rtp10-cd-dmzaas-gw1", "chn09-lab-gw2", "chn09-lab-gw1", "chg12-lab-gw2", "chg12-cibb-gw1", "chg12-cibb-gw2", "chg12-lab-gw1", "tul04-lab-gw2", "tul04-lab-gw1", "sjc05-cp-mgre1-gw1", "hcl7-in-lab-gw1", "hcl7-in-lab-gw2", "sngidc-cp-pxtr1-gw1", "hbg-lab-gw1", "rtp5-cibb-gw1", "trn6-lab-gw1", "trn6-lab-gw2", "rtp7-lab-gw1", "ful01-lab-gw2", "ful01-lab-gw1", "wshdc02-lab-gw1", "rtp3-lab-gw1", "rtp10-00-lab-gw2", "rtp9-lab-gw1", "rtp4-00-lab-gw2", "rtp2-lab-gw1", "sla01-lab-gw2", "rtp1-lab-gw1", "rtp12-00-lab-gw2", "rtp1-lab-gw2", "rtp12-00-lab-gw1", "rtp6-lab-gw2", "sla01-lab-gw1", "rtp6-lab-gw1", "rtp9-lab-gw2", "rtp11-lab-gw1", "sykes2-cr-lab-gw1", "req02-lab-gw1", "sol2-lab-gw1", "sea1-lab-gw1", "rtp5-lab-gw1", "rtp11-lab-gw2", "rtp1-mda1-cp-pxtr1-gw1", "rtp7-lab-gw2", "rtp8-lab-gw2", "embsys2-in-lab-gw2", "embsys2-in-lab-gw1", "sngidc-dmzvlab-gw1", "sngidc-dmzvlab-gw2", "pen3-lab-gw1", "pen3-lab-gw2", "jkt05-lab-gw2", "jkt05-lab-gw1", "rtp1-dmzvaas-gw1", "rtp7-dmzvaas-gw1", "ful01-fw1", "rtp5-dmzlab-gw1", "rtp8-lab-gw1", "req01-lab-gw1", "rtp1-dmzlab-gw1", "rtp11-dmzlab-gw1", "csv-lab-gw1", "atl11-lab-gw2", "atl11-lab-gw1", "ors03-lab-gw2", "cwy01-lab-gw1", "ors03-lab-gw1", "cwy01-lab-gw2", "gai03-lab-gw2", "bel01-lab-gw2", "bel01-lab-gw1", "aar02-lab-gw1", "bln2-lab-gw2", "gai03-lab-gw1", "bln2-lab-gw1", "tyoidc5-cp-pxtr1-gw1", "twl03-lab-gw1", "mil01-lab-gw1", "mil01-lab-gw2", "schp01-lab-gw1", "bgl16-00-lab-gw1", "argrp4-in-lab-gw1", "wpr2-in-lab-gw1", "bgl16-00-lab-gw2", "argrp4-in-lab-gw2", "bgl17-cp-mgre1-gw1", "argrp1-in-lab-gw1", "mtc2-in-lab-gw1", "bgl13-lab-gw2", "bgl13-cp-pxtr1-gw1", "bgl13-cibb-gw1", "bgl17-cp-pxtr1-gw1", "bgl13-lab-gw1", "bgl17-cibb-gw1", "pnq05-lab-gw2", "pnq05-lab-gw1", "hcl14-in-lab-gw1", "hcl14-in-lab-gw2", "bgl18-00-lab-gw1", "cmb03-lab-gw1", "infy9-in-lab-gw1", "bgl13-cp-mgre1-gw1", "bgl14-00-lab-gw1", "bgl18-00-lab-gw2", "bgl14-00-lab-gw2", "chn08-lab-gw1", "ggn01-lab-gw1", "ggn01-lab-gw2", "bgl26-lab-gw1", "shn15-lab-gw1", "argrp5-in-lab-gw1", "bgl17-00-lab-gw1", "bgl17-00-lab-gw2", "wpr8-in-lab-gw1", "hcl19-in-lab-gw2", "hcl19-in-lab-gw1", "bgl11-00-lab-gw2", "bgl11-00-lab-gw1", "bgl12-00-lab-gw1", "mmb12-lab-gw1", "mmb12-lab-gw2", "bgl12-00-lab-gw2", "kul02-lab-gw1", "bgl15-00-lab-gw1", "bgl15-00-lab-gw2", "hcl17-in-lab-gw1", "hcl17-in-lab-gw2", "bng02-lab-gw1", "hgh06-ext-lab-gw2", "hgh06-ext-lab-gw1", "sngdc01-mda2-cibb-gw2", "sngdc01-mda1-cibb-gw1", "akl02-lab-gw1", "mel03-lab-gw1", "tky7-lab-gw1", "hgh05-lab-gw1", "shn4-cibb-gw1", "shn15-lab-gw2", "shn6-lab-gw1", "shn7-lab-gw2", "tky7-lab-gw2", "ngo1-lab-gw1", "sng15-lab-gw1", "shn7-lab-gw1", "shn4-lab-gw2", "shn4-cibb-gw2", "shn4-lab-gw1", "sng15-lab-gw2", "prt3-lab-gw1", "nsd5-lab-gw2", "nsd5-lab-gw1", "cbr04-lab-gw1", "foxc1-cn-lab-gw1", "gng03-lab-gw1", "hfe02-lab-gw1", "hfe02-lab-gw2", "tky7-cibb-gw2", "tky7-cibb-gw1", "stld1-lab-gw2", "stld1-lab-gw1", "szn04-lab-gw1", "szn05-lab-gw1", "wln2-lab-gw1", "hni05-lab-gw1", "dlc02-lab-gw1", "dlc02-lab-gw2", "fka1-lab-gw1", "osk04-lab-gw1", "brb05-lab-gw1", "sngdc01-mda2-dmzaas-gw2", "sngdc01-mda1-dmzaas-gw1", "mnl02-lab-gw1", "shn17-lab-gw1", "shn17-lab-gw2", "svta01-lab-gw1", "yer03-lab-gw1", "sjc23-lab-gw2", "sjc21-lab-gw1", "sjc20-cibb5-gw1", "sjc20-lab-gw1", "sjcp-lab-gw2", "sjc23-lab-gw1", "sjc24-lab-gw1", "sjc21-lab-gw2", "sjc24-lab-gw2", "sjc20-lab-gw2", "sjcp-lab-gw1", "bvw01-lab-gw1", "sea1-lab-gw2", "vnc2-lab-gw1", "sjc5-cibbfo-sw2", "sjc5-cibbfo-sw1", "sjc5-cibb-wan-gw1", "sjc5-cibb-fw1", "wlt06-lab-gw2", "sjc12-dmzvaas-gw1", "sjc05-dmzvaas-gw1", "blv-lab-gw1", "wlt06-lab-gw1", "sjc5-cibb-fw1-ironport", "sjc12-cibb4-gw1", "sjc5-cibb-wan-gw2", "sjc12-lab-gw1", "sjc12-cp-pxtr1-gw1", "sfo12-cibb-gw1", "sjc5-cibb4-gw1", "sjc05-cp-pxtr1-gw1", "sjc02-lab-gw1", "sjc14-lab-gw1", "sjc16-lab-gw1", "sjc11-lab-gw1", "sjc08-lab-gw1", "sjc03-lab-gw1", "sjc01-lab-gw1", "sjc5-cibb4-gw2", "sjc15-lab-gw2", "sjc09-lab-gw1", "sjc07-lab-gw1", "sjc17-lab-gw1", "sjc13-lab-gw1", "sjc06-lab-gw2", "sjc04-lab-gw1", "sjc15-lab-gw1", "sjc19-lab-gw1", "sjc10-lab-gw1", "sjc04-lab-gw2", "sjc16-lab-gw2", "sjc14-lab-gw2", "sjc03-lab-gw2", "sjc13-lab-gw2", "sjc05-lab-gw2", "sjc06-lab-gw1", "sjc02-lab-gw2", "sjc01-lab-gw2", "sjc05-lab-gw1", "sjc09-lab-gw2", "sjc12-cibb4-gw2", "sjc10-lab-gw2", "sjc19-lab-gw2", "sjc08-lab-gw2", "sjc12-lab-gw2", "sjc07-lab-gw2", "sjc17-lab-gw2", "csb03-lab-gw1", "syc02-lab-gw1", "cosm02-lab-gw1", "sprg01-lab-gw2", "irv8-lab-gw1", "csb03-lab-gw2", "lux1-lab-gw1", "rtp5-lab-gw2", "rtp4-00-lab-gw1", "bgl17-dmzvlab-gw1", "bgl13-dmzaas-gw1", "bgl17-dmzaas-gw1", "bgl25-lab-gw1", "rcdn6-cibb-gw1", "sprg01-lab-gw1", "sjc23-cibb5-gw1", "par03-lab-gw2", "par03-lab-gw1", "bdlk11-cibb-gw1", "bdlk09-00-lab-gw1", "bdlk10-31-lab-gw1", "bdlk09-12-lab-gw1", "bdlk09-cibb-gw1", "bdlk10-00-lab-gw1", "bdlk09-00-lab-gw2", "bdlk11-00-lab-gw2", "bdlk11-00-lab-gw1", "rtp10-00-lab-gw1", "rtp5-dmzaas-gw1", "lon06-cibb-gw1", "els01-cibb-gw1", "mtv5-mda2-cibb-gw2", "sjc05-dmzvlab-gw1", "sjc5-cibb-fw2-ironport", "sjc5-cibb-fw2", "rtp1-mda2-cibb-fw2", "rtp1-mda2-cibb-fw2-ironport", "rtp1-mda2-cibb-fw2-latisys"]
    # Gateway_Util.get_ip_address_by_nslookup(gw)
    print("done")
    