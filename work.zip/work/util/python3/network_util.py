import ipaddress
from ipaddress import IPv4Address
from ipaddress import IPv4Network
from enum import Enum
import socket
from concurrent.futures import ThreadPoolExecutor
import subprocess
from typing import Union
import traceback

class NetWork_Util_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(NetWork_Util_Exception, self).__init__(self.message)

class Subnet_Match(Enum):
    NOTMATCH = -1
    SAME = 0
    SOURCEISPARTOFDESTINATION = 1
    DESTINATIONISPARTOFSOURCE = 2

class IP_Address_Type(Enum):
    HOST = 1
    CIDR = 2

class NetWork_Util:

    string_ipv4cidr = str
    string_ipv4host = str 
    string_ipv4host_or_ipv4cidr = str    

    @staticmethod
    def ip_to_integer(string_ip: str):
        try:
            if type(ipaddress.ip_address(string_ip)) is ipaddress.IPv4Address:
                return int(ipaddress.IPv4Address(string_ip))
        except:
            e = str(traceback.format_exc())
            raise NetWork_Util_Exception("NetWork_Util: Couldn't conver IP addredd to integer.\n"
                                         +"Value: {}\n".format(string_ip)
                                         +str(e))

    @staticmethod
    def get_ip_range(cidr: string_ipv4cidr):
        try:
            cidr = cidr.strip()
            NetWork_Util.__ip_address_format_validation(cidr, IP_Address_Type.CIDR)

            net = ipaddress.ip_network(cidr)
            return net[0], net[-1]
        except:
            e = str(traceback.format_exc())
            raise NetWork_Util_Exception("NetWork_Util: Couldn't get IP addredd range.\n"
                                         +"Value: {}\n".format(cidr)
                                         +str(e))
    
    @staticmethod
    def get_cidr(ip_address: str):
        """input = cidr\n
        input = host with subnet mask or wildcard mask
        """

        try:
            if ("/" not in ip_address):
                ip_address = ip_address.replace(" ", "/")
            return str(ipaddress.IPv4Network(ip_address))
        except:
            e = str(traceback.format_exc())
            raise NetWork_Util_Exception("NetWork_Util: Couldn't get CIDR.\n"
                                         +"Value: {}\n".format(ip_address)
                                         +str(e))
    
    @staticmethod
    def get_wild_card_mask(cidr: string_ipv4cidr):
        cidr = cidr.strip()
        NetWork_Util.__ip_address_format_validation(cidr, IP_Address_Type.CIDR)

        mask_bit = cidr.split("/")[1]
        
        try:
            return str(IPv4Address(int(IPv4Address._make_netmask(mask_bit)[0])^(2**32-1)))
        except Exception as e:
            raise NetWork_Util_Exception("NetWork_Util: Cloudn't get the wildcard value:\n"
                                         +"Value: {}".format(cidr)
                                         +str(e))
    
    @staticmethod
    def __ip_address_format_validation(ip_address: string_ipv4host_or_ipv4cidr, 
                                                            address_type: IP_Address_Type):
        """Basic check with [empty, space, /] 
        \n(regex need to be added)
        """
        if (address_type == address_type.HOST):
            if (ip_address == "" or " " in ip_address or "/" in ip_address):
                raise NetWork_Util_Exception("Host IP is not in a valid format.\nValue: " + ip_address)
        if (address_type == address_type.CIDR):
            if (ip_address == '' or ' ' in ip_address or "/" not in ip_address):
                raise NetWork_Util_Exception("CIDR is not in a valid format.\nValue: " + ip_address)

    @staticmethod  # "171.76.81.0/26,171.76.81.10/32,171.76.81.0/24,171.76.82.10/32"
    def getparentsubnets(subnet_string):
        subnets = subnet_string.split(",")
        retsubnets = []
        othersubnet = []

        for subnet in subnets:
            caninsert = True
            subnet = subnet.strip()

            for subnet1 in retsubnets:
                if NetWork_Util.is_subnet_of(subnet1, subnet):
                    retsubnets.remove(subnet1)
                elif NetWork_Util.is_subnet_of(subnet, subnet1):
                    caninsert = False

            if caninsert and not subnet.endswith("/30") and not subnet.endswith("/32") and subnet not in retsubnets:
                retsubnets.append(subnet)
            else:
                othersubnet.append(subnet)

        return ','.join(retsubnets), ','.join(othersubnet)

    # Function to check if one subnet is a subnet of another
    @staticmethod
    def is_subnet_of(subnet1, subnet2):
        ip1, prefix1 = subnet1.split("/")
        ip2, prefix2 = subnet2.split("/")
        if prefix1.isdigit() and prefix2.isdigit():
            prefix1 = int(prefix1)
            prefix2 = int(prefix2)
            if prefix1 <= prefix2:
                return ip2.startswith(ip1) and prefix2 - prefix1 >= 0
        return False

    @staticmethod
    def compare_subnet(cidr_a: string_ipv4cidr, cidr_b: string_ipv4cidr):
        NetWork_Util.__ip_address_format_validation(cidr_a, IP_Address_Type.CIDR)
        NetWork_Util.__ip_address_format_validation(cidr_b, IP_Address_Type.CIDR)

        if (cidr_a == cidr_b):
            return Subnet_Match.SAME
        elif (IPv4Network(cidr_a).overlaps(IPv4Network(cidr_b))):
            if (IPv4Network(cidr_a).supernet_of(IPv4Network(cidr_b))):
                return Subnet_Match.DESTINATIONISPARTOFSOURCE
            return Subnet_Match.SOURCEISPARTOFDESTINATION
        return Subnet_Match.NOTMATCH
    
    @staticmethod
    def nslookup(gw, gw_with_ip, failed_nslookup_gw_status):

        p = subprocess.Popen('nslookup ' + gw, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        isIpAddressLine = False
        ip_addresses = []
        for line in p.stdout.readlines():
            line = line.decode()

            if ("can't find" in line):
                print("{:<30}    {}".format(gw, "Can not find IP Address by nslookup"))
                failed_nslookup_gw_status.append([gw, "", "Can not find IP Address by nslookup"])
                gw_nslookup_error = gw_nslookup_error + 1
                return

            if (isIpAddressLine and 'Name' not in line and line.strip() != ''):
                ip_addresses.append(line.replace("Address:", "").replace("Addresses:", "").strip())
                # gws_ip.append[gw, line.replace("Address:", "").replace("Addresses:", "").strip()]
                # break

            if ("Name" in line and gw in line and "can't find" not in line):
                isIpAddressLine = True
                
        print("{:<30}    {}".format(gw, ip_addresses))
        # currently tacking IPv4 address
        got_ipv4 = False
        for ip in ip_addresses:        
            try:            
                socket.inet_aton(ip)
                gw_with_ip.append([gw, str(ip)]) # ['host_name',IPv4]
                got_ipv4 = True
            except socket.error:
                if (len(ip_addresses) == 1):
                    print("not IPv4: {}, {}".format(gw, ip))
                    try:
                        socket.inet_pton(socket.AF_INET6, ip)
                        gw_with_ip.append([gw, ip]) # ['host_name', 'ipv6' ,IPv6]
                    except socket.error as e:
                        print("Ip error: {}".format(str(e)))

        if (got_ipv4 == False):
            print("no ipv4 found. used IPv6  ==> {:<30}    {}".format(gw, ip_addresses))

    @staticmethod
    def get_ip_address_by_nslookup(gws: Union[list, set]):    
        avoid_gw_list = "rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1-ironport, ful01-fw1, sjc5-cibb-fw1, sjc5-cibb-fw1-ironport, sjc5-cibb-fw2-ironport, sjc5-cibb-fw2, rtp1-mda2-cibb-fw2-ironport, rtp1-mda2-cibb-fw2, rtp1-mda2-cibb-fw2-latisys"
        
        # print("Befter total: {}".format(len(gws)))
        print("Filter : avoid_gw_list is applied")  # this line is printed.
        # print("After total: {}".format(len(gws) - len(avoid_gw_list)))

        gws_ip = []
        failed_nslookup_gw_status = []
        print("{:<30}    {}".format('Gateway', 'Ip'))
        with ThreadPoolExecutor(max_workers=30) as executor:
            for gw in gws:
                gw = gw.strip() 
                if (gw not in avoid_gw_list):
                    executor.submit(NetWork_Util.nslookup, gw, gws_ip, failed_nslookup_gw_status)
                
        print("\ntotal gws_ip by nslookup = {}\n".format(str(len(gws_ip))))
        for i in gws_ip:
            print(i)
        
        print("\nFailed nslookup: {}\n".format(len(failed_nslookup_gw_status)))
        for i in failed_nslookup_gw_status:
            print(i)

        return [gws_ip, failed_nslookup_gw_status]

if __name__ == "__main__":
    NetWork_Util.getparentsubnets('171.76.81.0/26,171.76.81.10/32,171.76.81.0/24,171.76.82.10/32')
    # cidr = "10.104.192.0/20"
    # start_ip, end_ip = NetWork_Util.get_ip_range(cidr)
    # print(start_ip, end_ip )
    #
    # print(NetWork_Util.ip_to_integer(start_ip))
    # print(NetWork_Util.ip_to_integer(end_ip))