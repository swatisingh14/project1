#   Python 3.6
#
#   script doesn't take ss-lab ACLs
#   Input = Lab gateways

import sys
import os
import platform
from cryptography.fernet import Fernet
parent_directory_path = os.path.dirname(os.getcwd())
sys.path.append(parent_directory_path)
util_package = ""
vrf_package = ""
if (platform.system() != 'Windows'):
    util_package = parent_directory_path + "/util/python3"
    vrf_package = parent_directory_path + "/vrf-offramp"
else:
    util_package = parent_directory_path + "\\util\\python3"
    vrf_package = parent_directory_path + "\\vrf-offramp"

sys.path.append(util_package)
sys.path.append(vrf_package)

# from pydoc import cli
import paramiko,time
import cx_Oracle
import csv,re, socket
import subprocess
from datetime import date
import pandas as pd
import re
import traceback
import csv
from concurrent.futures import ThreadPoolExecutor
import smtplib
# from email.message import EmailMessage
import getpass
# import rsa
import platform
import datetime
import threading
from pytz import timezone 
from datetime import datetime
from deprecated import deprecated

from util.python3.gateway_util import Gateway_Util
from util.python3.gateway_util import Gateway_Util_Exception
from util.python3.network_util import NetWork_Util
from util.python3.network_util import NetWork_Util_Exception
from util.python3.util import Util
from util.python3.util import Util_Exception
from util.python3.database_util import DB
from util.python3.database_util import DB_TABLE
from util.python3.database_util import Row_Tag
from util.python3.database_util import Script_Type
from util.python3.database_util import Script_State
from util.python3.database_util import Anomaly_Type
from util.python3.database_util import DB_Exception
from util.python3.database_util import Delete_Data_criteria_list

import pia_inacl_anomaly_with_gw
from vrf_offramp import vrf_offramp_with_pxtr
import data_creation

# os.environ["ORACLE_HOME"]="/usr/cisco/packages/oracle/oracle-11.2.0.3"
# os.environ["LD_LIBRARY_PATH"]="$ORACLE_HOME/lib:$LD_LIBRARY_PATH"

today = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')

job_id: list = []
"""Job ID is in index number 0.
"""

cursor = None
connection = None

_username = 'morashee.web'

gw_dc_map = dict()

pinged = []
not_pinged = []

gw_finished_count = 0
host_not_matched_list = []

is_reach_max_execution = False
current_exec_count = 0
gw_done_count = 0
gw_error_count = 0
gw_unreachable_count = 0
gw_conn_time_out_count = 0
gw_not_connected_count = 0
gw_unknown_error_count = 0
gw_auth_failed_count = 0
gw_invoke_shell_error_count = 0
gw_nslookup_error = 0

host_name_matched_count = 0
lab_id_from_mapping_count = 0
lab_id_from_mapping_matched_count = 0

# writer = pd.ExcelWriter("C:/Joshva/python/output/Lab_GWs_output.xlsx", engine = 'xlsxwriter')
datas = []
datas_with_no_labid = []
datas_with_inproper_desc = []
# datas_with_more_labid = []
failed_host = []
# incorrect_lab_id_set = set()
incorrect_lab_id_with_details = []
# host_with_ip_status = []
host_with_ip_status = []
subnet_with_lab_dict = {}
subnet_with_lab_list = []

labid_gw_subnet_merge = {}
inAcl_outAcl_labId_gw_merge = {}

gw_int_desc_labid_map = {}

# for without nexthup
without_nexthop = []

same_subnet_multi_lab_list = []

# Anomaly
dmz_acl_template = []

# store all response to debug
all_gw_response = {}

is_excel_file_created = False
is_final_file_created = False
is_no_status_for_gw = False

def mail(sub, content, error=False):
    global gw_done_count, gw_error_count, is_excel_file_created
    """
    try:
        msg = EmailMessage()
        msg['Subject'] = sub
        msg['From'] = 'PIA <noreply@cisco.com>'
        msg['To'] = 'aagnel@cisco.com'
        # msg['To'] = 'famushta@cisco.com'
        # msg['BCC'] = 'shoraj@cisco.com'

        if (platform.system() == 'Windows'):
            writer = pd.ExcelWriter("C:/Users/shoraj/Desktop/temp_pia/Lab_GWs_output.xlsx", mode="w", engine = 'xlsxwriter')
        else:
            writer = pd.ExcelWriter("/apps/users/morashee/PIA/Lab-GWs-output.xlsx",  mode="w", engine = 'xlsxwriter')        

        msg.add_header('Content-Type','text/html')
        msg.set_payload(content)

        if (is_excel_file_created):
            today = date.today()
            # dd/mm/YY
            today = str(today.strftime("%d-%m-%Y"))
            
            file_name = ''
            if (platform.system() == 'Windows'):
                file_name = "C:/Users/shoraj/Desktop/temp_pia/Lab_GWs_output.xlsx"
            else:
                file_name = "/apps/users/morashee/PIA/Lab-GWs-output.xlsx"
            
            f = open(file_name , "rb")    
            file_data = f.read()
            msg.add_attachment(file_data, maintype="application", subtype="xlsx", filename="Lab-GWs-output-"+today+".xlsx")
        
        if (platform.system() == 'Linux'):
            f = open("/isp/scripts/python/PIA/work/master.log" , "rb")    
            file_data = f.read()
            msg.add_attachment(file_data, maintype="application", subtype="txt", filename="master.log")

        s = smtplib.SMTP('outbound.cisco.com')
        s.send_message(msg)
        s.quit()
        print "Mail sent"
    except:
        ex = traceback.format_exc()
        print "Mail Error:\n" + ex
        pass
    """

    print(content.replace("<br>", "\n").replace("&nbsp", " "))

class PIA_Exception(Exception):

    def __init__(self, message):
        self.message = message
        super(PIA_Exception, self).__init__(self.message)

def error_msg_format(error):
    return error.replace("\n", "<br>").replace("  ", "&nbsp")

def close_resource(obj):
    try:
        obj.close()
    except:
        pass

def error_process(host, status):
    create_data(host, None, [status, host], True)

def get_paramiko_client(host):
    global gw_unreachable_count, gw_conn_time_out_count, gw_not_connected_count, gw_unknown_error_count, gw_auth_failed_count, _username
    try:
        vm = paramiko.SSHClient()
        vm.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # vm.load_system_host_keys()
        vm.connect(hostname=host, port=22, username=_username, password=decrypt_password(_username), allow_agent=False, look_for_keys=False)
        return vm

    except paramiko.AuthenticationException:
        gw_auth_failed_count = gw_auth_failed_count + 1
        raise PIA_Exception("Authentication failed!")
    except paramiko.ssh_exception.NoValidConnectionsError:
        gw_not_connected_count = gw_not_connected_count + 1
        raise PIA_Exception("Device is not connected")
    except OSError:
        gw_unreachable_count = gw_unreachable_count + 1
        raise PIA_Exception("Network is unreachable")
    except:        
        ex = str(traceback.format_exc())
        if "Connection timed out" in ex:
            gw_conn_time_out_count = gw_conn_time_out_count + 1
            raise PIA_Exception("Connection timed out")
        else:
            gw_unknown_error_count = gw_unknown_error_count + 1
            raise PIA_Exception("Unknown error: \n" + ex)

def init_db():
    try:
        global cursor, connection
        connection = cx_Oracle.connect('ESMSCSTG', 'Cisco_123', '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=dbs-nprd2-vm-013.cisco.com)(PORT=1535))(CONNECT_DATA=(SERVICE_NAME=ESMDBSTG.CISCO.COM)(Server=Dedicated)))')
        # dsn = cx_Oracle.makedsn("dbs-nprd2-vm-013.cisco.com", 1535, service_name="ESMDBSTG.cisco.com")
        # connection = cx_Oracle.connect(user="ESMSCSTG", password='Cisco_123', dsn=dsn,encoding="UTF-8")
        connection.autocommit = True
        cursor = connection.cursor()
        print("DB :  Connected")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("DB couldn't be connected \n" + str(e))

def get_script_today_status():
    global current_exec_count
    try:
        # cursor.execute("select a.current_count, c.max_count from T_PIA_AUDIT a, T_PIA_AUDIT_CONFIG c where trunc(a.AUDIT_DATE)=trunc(CURRENT_DATE)")
        # rows = cursor.fetchall()
        rows = []
        # print("script status=> ", rows)

        if (len(rows) > 0):
            current_count = rows[0][0]
            max_count = rows[0][1]
            if (current_count < max_count):

                if (current_count + 1 == max_count):
                    is_reach_max_execution = True

                current_exec_count = rows[0][0]
                # returing current executed count
                return rows[0][0]
            else:
                # Excecution reached maximum
                return -1
        else:
            try:
                print("DB : clean process")
                # cursor.execute("insert into T_PIA_AUDIT (audit_date, current_count) values(CURRENT_DATE, 1)")
                # cursor.execute("truncate table T_PIA_HOST_INFO")
                cursor.execute("truncate table T_PIA_HOST_REPORT")
                cursor.execute("truncate table T_PIA_INCORRECT_LAB_ID")
                cursor.execute("truncate table T_PIA_SUBNET_WITH_LAB")

                # cursor.execute("update T_PIA_HOST_INFO set status= Null, count=0")
                print("DB : Table truncate : All done")
                # start very first execution
                return 0
            except:
                e = traceback.format_exc()
                raise PIA_Exception("\n<b style='font-size:20px;color:red;'>An error occurred when doing insert new data to AUDIT / Truncate tables</b>\n\n" + str(e))

    except:
        e = traceback.format_exc()
        raise PIA_Exception("Script's today status couldn't be fetched\n\n" + str(e))

def update_script_today_status():
    try:        
        cursor.execute("update T_PIA_AUDIT set current_count=current_count+1 where trunc(audit_date)=trunc(CURRENT_DATE)")
        print("DB : updated audit's today entry")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Script's today status couldn't be updated \n" + str(e))

def fetch_and_update_gw_source():
    try:
        cursor.execute("insert into T_PIA_HOST_INFO (host_name, IP_ADDRESS, COUNT) select distinct NETGEAR_NAME, NETGEAR_IP_ADDR, 0 from T_ESP_NETGEAR_ADAPTER where NETGEAR_OPER_STATUS = 'Operational' and NETGEAR_NAME not like '%-pxtr%';")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("GW details couldn't be fetched or inserted from T_ESP_NETGEAR_ADAPTER to T_PIA_HOST_INFO \n" + str(e))

def get_input_gw(count):
    # fetch_and_update_gw_source()
    try:        
        gw = []
        if (count == 0):
            cursor.execute("select HOST_NAME, IP_ADDRESS from T_PIA_HOST_INFO")
        else:
            cursor.execute("select HOST_NAME, IP_ADDRESS from T_PIA_HOST_INFO where STATUS IS NOT NULL")
        
        rows = cursor.fetchall()
        for row in rows:
            # HOST_NAME: row[0], IP_ADDRESS: row[1]
            gw.append([row[0], row[1]])
        return gw
    except:
        e = traceback.format_exc()
        raise PIA_Exception("GW details couldn't be fetched \n" + str(e))

def insert_report(rows):
    try:
        cursor.executemany("insert into T_PIA_HOST_REPORT (lab_id, host_name, host_ip, interface, interface_ip, description, forwarding_lab, lab_route_subnet, next_hop) values(:1, :2, :3, :4, :5, :6, :7, :8, :9)",
                            rows)
        print("DB: inserted valide lab report")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("GW details couldn't be inserted" + str(e))

"""
def get_failed_host_and_status():
    try:
        gw = []
        cursor.execute("select host_name, status from T_PIA_HOST_INFO where status is not null")
        rows = cursor.fetchall()
        for row in rows:
            datas.append([row[0], row[1]])
        return gw
    except:
        e = traceback.format_exc()
        raise PIA_Exception("GW failed details couldn't be fetched \n" + str(e) + "\n")
"""

def insert_incorrect_lab_id(rows):
    try:
        cursor.executemany("insert into T_PIA_INCORRECT_LAB_ID (lab_id, valid_lab_id, device, interface, interface_ip) values(:1, :2, :3, :4, :5)", rows)
        print("DB : inserted invalid lab ids")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Incorrect Lab Id details couldn't be Inserted \n" + str(e))

def insert_subnet_with_labid(rows):
    try:
        cursor.executemany("insert into T_PIA_SUBNET_WITH_LAB (subnet, lab_id_list) values(:1, :2)", rows)
        print("DB : inserted subnet with lab id list")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Subnet with Lab Id details couldn't be Inserted \n" + str(e))

def insert_gw_process_status(rows):
    try:
        cursor.executemany("update T_PIA_HOST_INFO set IP_ADDRESS=:1, status=:2, last_updated_on=CURRENT_DATE, count=count+1 where host_name= :3", rows)
        print("DB: Gateway and process status is inserted")
    except:
        e = traceback.format_exc()
        raise PIA_Exception("DB: Gateway process status details couldn't be Inserted \n" + str(e))

def get_dc(gateway_name: str) -> str:
    if (gateway_name == None or gateway_name.strip() == ''):
        raise PIA_Exception("Get DC Error: Gateway name is not valid\nValue: " + gateway_name)
    
    gateway_name = gateway_name.strip()
    if (gateway_name not in gw_dc_map):
        return ""
    
    return gw_dc_map[gateway_name]

def create_data(hostname, gw_ip, data, error = False):
    valid_output_count = 0

    for k, v in data.items():
        new_row = [get_dc(hostname), ifNullThenEmpty("labid", v), hostname, gw_ip, k, ifNullThenEmpty("ip", v), 
                    ifNullThenEmpty("description", v), ifNullThenEmpty("forwarding_lab", v),
                     ifNullThenEmpty("inAcl", v),  ifNullThenEmpty("outAcl", v), 
                    ifNullThenEmpty("subnet", v), ifNullThenEmpty("nexthop", v)]

        # print('printing v--------------------------------\n',v)  # newly added

        if ("labid" in v
                    and ',' not in v["labid"]
                    and '[' not in v["labid"]
                    and "incorrect lab id" not in v["labid"]
                    and "ip" in v
                    and "description" in v
                    # and "forwarding_lab" in v
                    # and "subnet" in v
                    ):
            datas.append(new_row)
            # print('printing datas-----------------\n',datas)  # newly added

            if ("nexthop" not in v):
                without_nexthop.append(new_row)

            valid_output_count = valid_output_count + 1

        elif ("labid" in v 
              and ("," in v["labid"] or "[" in v["labid"] or "incorrect lab id" in v["labid"])):
            datas_with_inproper_desc.append(new_row)
            # print('printing datas_with_inproper_desc--------------------------\n', datas_with_inproper_desc)  # newly added
        else:
            datas_with_no_labid.append(new_row)
            # print('printing datas_with_no_labid----------------------------\n', datas_with_no_labid)  # newly added


    return valid_output_count
    
def ifNullThenEmpty(key, data_dict):
    return data_dict[key] if key in data_dict else ""


@deprecated(reason="")
def create_csv_file_v1():    
    global is_excel_file_created
    try:                      
        
        file1 = open('output/Valid_Lab_Id_Report.csv','w')
        valid_report_writer = csv.writer(file1)
        print("CSV : Writing valid lab id report... | count: " + str(len(datas)))
        valid_report_writer.writerow(["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"])
        for i in datas:
                valid_report_writer.writerow(i)

        file2 = open('output/Invalid_Details.csv','w')
        invalid_report_writer = csv.writer(file2)
        print("CSV : Writing invalid details... | count: " + str(len(datas_with_no_labid)))
        invalid_report_writer.writerow(["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"])
        for i in datas_with_no_labid:
                invalid_report_writer.writerow(i)

        file3 = open('output/LRT_Fromatted_Lab_Id.csv','w')
        incorrect_lab_id_writer = csv.writer(file3)
        print("CSV : Writing LRT fromated lab Id... | count: " + str(len(incorrect_lab_id_with_details)))
        incorrect_lab_id_writer.writerow(["Lab ID", "Valid Lab ID", "Device", "Interface", "Interface IP", "Description", "Forwarding Lab", "InACL", "OutACL"])
        for i in incorrect_lab_id_with_details:
            incorrect_lab_id_writer.writerow(i)

        file4 = open('output/Gateway_Process_Status.csv','w')
        failed_host_writer = csv.writer(file4)
        print("CSV : Writing Gateway_Process_Status... | count: " + str(len(host_with_ip_status)))
        failed_host_writer.writerow(["Host Name", "IP Address", "Status"])
        for i in host_with_ip_status:
            failed_host_writer.writerow(i)
        
        # same_subnet_multi_lab
        same_subnet_multi_lab_dict = {}

        for k_subnet, v_lab_list in subnet_with_lab_dict.items():
            lab_ids = ", ".join(v_lab_list)
            subnet_with_lab_list.append([k_subnet, lab_ids])

            if ("," in lab_ids):
                if (lab_ids not in same_subnet_multi_lab_dict):
                    same_subnet_multi_lab_dict[lab_ids] = []
                same_subnet_multi_lab_dict[lab_ids].append(k_subnet)


        file5 = open('output/Valid_Lab_Ids_Subnet.csv','w')
        subnet_writer = csv.writer(file5)
        print("CSV : Writing Valid lab Ids and Subnet merge... | count: " + str(len(subnet_with_lab_list)))
        subnet_writer.writerow(["Subnet", "Lab Id"])
        for i in subnet_with_lab_list:
            subnet_writer.writerow(i)
        
        for lab_Id, subnets in same_subnet_multi_lab_dict.items():
            same_subnet_multi_lab_list.append(["", lab_Id, ", ".join(subnets)])
        columns = ["DC", "Lab ID", "Subnets"]
        Util.save_data_to_new_csv('output/Subnet_With_Mutiple_Lab_Anomaly', columns, same_subnet_multi_lab_list)

        # datas_with_inproper_desc_or_more_labid_or_partial_labid
        file6 = open("output/GatewayInt_Inproper_Desc.csv", "w")
        gw_int_inproper_desc_writer = csv.writer(file6)
        print("CSV : Writing GatewayInt inproper descrption... | count: " + str(len(datas_with_inproper_desc)))
        gw_int_inproper_desc_writer.writerow(["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description"])
        for i in datas_with_inproper_desc:
            gw_int_inproper_desc_writer.writerow(i)

        # labid_gw_subnet_merge
        labid_gw_subnet_merge_list = []
        for k, v in labid_gw_subnet_merge.items():
            for inner_k, inner_v in v.items():
                if ('labSubnets' == inner_k):
                    continue
                labid_gw_subnet_merge_list.append([k, inner_k, ", ".join(inner_v["subnet"]),
                                                                ", ".join(inner_v["uplink"]),
                                                                ', '.join(v["labSubnets"].difference(inner_v["subnet"]))])
        file7 = open('output/Valid_Lab_Subnet_Exl_Uplink.csv','w')
        subnet_writer = csv.writer(file7)
        print("CSV : Writing [labid, gw, subnet, uplink, missing] merge... | count: " + str(len(labid_gw_subnet_merge_list)))
        subnet_writer.writerow(["Lab Id", "Gateway", "Subnet", "Uplink", "Missing"])
        for i in labid_gw_subnet_merge_list:
            subnet_writer.writerow(i)

        # inACL & outACL
        # print inAcl_outAcl_labId_gw_merge
        valid_acl = []
        invalid_acl = []
        file8 = open('output/Valid_Lab_In_Out_ACL.csv','w')        
        file9 = open('output/Valid_Lab_Invalid_In_Out_ACL.csv','w')
        acl_writer = csv.writer(file8)
        invalid_acl_writer = csv.writer(file9)
        acl_writer.writerow(["Lab Id", "In ACL", "Out ACL"])
        invalid_acl_writer.writerow(["Lab Id", "In ACL", "Out ACL", "Gateway"])
        for k, v in inAcl_outAcl_labId_gw_merge.items():
            df = pd.DataFrame(v, columns=['inACl', 'outACL', 'gw'])
            duplicate = df.drop_duplicates(['inACl', 'outACL'])
            if (len(duplicate) == 1):
                valid_acl.append([k, v[0][0], v[0][1]])
                acl_writer.writerow([k, v[0][0], v[0][1]])
            else:
                for i in v:
                    invalid_acl.append([k, i[0], i[1], i[2]])
                    invalid_acl_writer.writerow([k, i[0], i[1], i[2]])
        print("CSV : Writing output/Valid_Lab_In_Out_ACL... | count: " + str(len(valid_acl)))
        print("CSV : Writing output/Valid_Lab_Invalid_In_Out_ACL... | count: " + str(len(invalid_acl)))

        file1.close()
        file2.close()
        file3.close()
        file4.close()
        file5.close()
        file6.close()
        file7.close()
        file8.close()
        file9.close()
                
        print("CSV : files created")
        is_excel_file_created = True
        
    except Util_Exception as e:
        raise e
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Excel : File couldn't be created \n" + str(e))

@deprecated(reason="") 
def create_csv_file_v2():    
    global is_excel_file_created
    try:                      
        columns = ["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.save_data_to_new_csv('output/temp/Valid_Lab_Id_Report.csv', columns, datas)

        columns = ["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.save_data_to_new_csv('output/temp/Invalid_Details.csv', columns, datas_with_no_labid)

        columns = ["Lab ID", "Valid Lab ID", "Device", "Interface", "Interface IP", "Description", "Forwarding Lab", "InACL", "OutACL"]
        Util.save_data_to_new_csv('output/temp/LRT_Fromatted_Lab_Id.csv', columns, incorrect_lab_id_with_details)

        columns = ["Host Name", "IP Address", "Status"]
        Util.save_data_to_new_csv('output/temp/Gateway_Process_Status.csv', columns, host_with_ip_status)
        
        # same_subnet_multi_lab
        same_subnet_multi_lab_dict = {}
        for k_subnet, v_lab_list in subnet_with_lab_dict.items():
            lab_ids = ", ".join(v_lab_list)
            subnet_with_lab_list.append([k_subnet, lab_ids])

            if ("," in lab_ids):
                if (lab_ids not in same_subnet_multi_lab_dict):
                    same_subnet_multi_lab_dict[lab_ids] = []
                same_subnet_multi_lab_dict[lab_ids].append(k_subnet)


        columns = ["Subnet", "Lab Id"]
        Util.save_data_to_new_csv('output/temp/Valid_Lab_Ids_Subnet.csv', columns, subnet_with_lab_list)
        
        for lab_Id, subnets in same_subnet_multi_lab_dict.items():
            same_subnet_multi_lab_list.append(["", lab_Id, ", ".join(subnets)])
        columns = ["DC", "Lab ID", "Subnets"]
        Util.save_data_to_new_csv('output/temp/Subnet_With_Mutiple_Lab_Anomaly', columns, same_subnet_multi_lab_list)

        columns = ["Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description"]
        Util.save_data_to_new_csv('output/temp/GatewayInt_Inproper_Desc.csv', columns, datas_with_inproper_desc)

        # labid_gw_subnet_merge
        labid_gw_subnet_merge_list = []
        for k, v in labid_gw_subnet_merge.items():
            for inner_k, inner_v in v.items():
                if ('labSubnets' == inner_k):
                    continue
                labid_gw_subnet_merge_list.append([k, inner_k, ", ".join(inner_v["subnet"]), 
                                                                ", ".join(inner_v["uplink"]), 
                                                                ', '.join(v["labSubnets"].difference(inner_v["subnet"]))])
        columns = ["Lab Id", "Gateway", "Subnet", "Uplink", "Missing"]
        Util.save_data_to_new_csv('output/temp/Valid_Lab_Subnet_Exl_Uplink.csv', columns, labid_gw_subnet_merge_list)

        valid_acl = []
        invalid_acl = []
        for k, v in inAcl_outAcl_labId_gw_merge.items():
            df = pd.DataFrame(v, columns=['inACl', 'outACL', 'gw'])
            duplicate = df.drop_duplicates(['inACl', 'outACL'])
            if (len(duplicate) == 1):
                valid_acl.append([k, v[0][0], v[0][1]])
            else:
                for i in v:
                    invalid_acl.append([k, i[0], i[1], i[2]])

        columns = ["Lab Id", "In ACL", "Out ACL"]
        Util.save_data_to_new_csv('output/temp/Valid_Lab_In_Out_ACL', columns, valid_acl)
        columns = ["Lab Id", "In ACL", "Out ACL"]
        Util.save_data_to_new_csv('output/temp/Valid_Lab_Invalid_In_Out_ACL', columns, invalid_acl)        

        print("CSV : file created")
        is_excel_file_created = True
        
    except Util_Exception as e:
        raise e
    except:
        e = traceback.format_exc()
        raise PIA_Exception("CSV : File couldn't be created \n" + str(e))


def create_excel_with_sheet():    
    global is_excel_file_created, dmz_acl_template
    try:
        today_date = today.split(" ")[0].strip()
        writer = pd.ExcelWriter("output/PIA_Output.xlsx",  mode="w", engine = 'xlsxwriter')

        #  this one is the valid one.
        columns = ["DC", "Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", 
                   "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.create_excel_sheet(writer, "Valid_Lab_Id_Report", columns, datas)
        # This file is input for PIA DMZ InACL
        Util.save_data_to_new_csv('output/Valid_Lab_Id_Report.csv', columns, datas)

        #  this one is the invalid detail one.
        columns = ["DC", "Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", 
                   "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.create_excel_sheet(writer, "Invalid_Details", columns, datas_with_no_labid)

        #  this one is the improper description one.
        columns = ["DC", "Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", 
                   "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.create_excel_sheet(writer, "GatewayInt_Inproper_Desc", columns, datas_with_inproper_desc)

        columns = ["DC", "Lab ID", "Device", "Device IP Address", "Interface", "Interface Ip", "Description", 
                   "Forwarding Lab", "InACL", "OutACL", "Lab Route Subnet", "Next Hop"]
        Util.create_excel_sheet(writer, "Next Hop Config missing", columns, without_nexthop)

        columns = ["Lab ID", "Valid Lab ID", "Device", "Interface", "Interface IP", "Description"]
        Util.create_excel_sheet(writer, "LRT_Fromatted_Lab_Id", columns, incorrect_lab_id_with_details)


        # same_subnet_multi_lab
        same_subnet_multi_lab_dict = {}
        # subnet_with_lab_dict[subnet] = dict(lab_ids=set(), dc=set())
        for k_subnet, v_lab_list in subnet_with_lab_dict.items():
            lab_ids = ", ".join(v_lab_list["lab_ids"])
            dc_list = ", ".join(v_lab_list["dc"])
            start_ip_range = v_lab_list["start_ip_range"]
            end_ip_range = v_lab_list["end_ip_range"]
            subnet_with_lab_list.append([k_subnet, lab_ids, dc_list, start_ip_range, end_ip_range])

            if ("," in lab_ids):
                if (lab_ids not in same_subnet_multi_lab_dict):
                    same_subnet_multi_lab_dict[lab_ids] = dict(subnet=[], dc=set())
                same_subnet_multi_lab_dict[lab_ids]["subnet"].append(k_subnet)
                same_subnet_multi_lab_dict[lab_ids]["dc"].update(v_lab_list["dc"])

        columns = ["Subnet", "Lab Id", "DC", "Start IP Range", "End IP Range"]
        Util.create_excel_sheet(writer, "Valid_Lab_Ids_Subnet", columns, subnet_with_lab_list)
        # This file is a input for PIA Overlapping
        Util.save_data_to_new_csv('output/Valid_Lab_Ids_Subnet.csv', columns, subnet_with_lab_list)

        # for lab_Id, subnets in same_subnet_multi_lab_dict.items():
        for lab_Id, values in same_subnet_multi_lab_dict.items():
            # same_subnet_multi_lab_list.append(["", lab_Id, ", ".join(subnets)])
            same_subnet_multi_lab_list.append([", ".join(values["dc"]), lab_Id, ", ".join(values["subnet"])])

        columns = ["DC", "Lab ID", "Subnets"]
        Util.create_excel_sheet(writer, "Subnet_With_Mutiple_Lab_Anomaly", columns, same_subnet_multi_lab_list)

        # labid_gw_subnet_merge
        labid_gw_subnet_merge_list = []
        for k, v in labid_gw_subnet_merge.items():
            for inner_k, inner_v in v.items():
                if ('labSubnets' == inner_k):
                    continue
                labid_gw_subnet_merge_list.append(
                    [k, inner_k, ", ".join(inner_v["subnet"]), ", ".join(inner_v["uplink"]), 
                                    ', '.join(v["labSubnets"].difference(inner_v["subnet"]))])
        
        columns = ["Lab Id", "Gateway", "Subnet", "Uplink", "Missing"]
        Util.create_excel_sheet(writer, "Valid_Lab_Subnet_Exl_Uplink", columns, labid_gw_subnet_merge_list)

        # inACL & outACL
        # print inAcl_outAcl_labId_gw_merge
        valid_acl = []
        invalid_acl = []
        for k, v in inAcl_outAcl_labId_gw_merge.items():
            df = pd.DataFrame(v, columns=['inACl', 'outACL', 'gw', 'dc'])
            duplicate = df.drop_duplicates(['inACl', 'outACL'])
            if (len(duplicate) == 1):
                # valid_acl.append([k, v[0][0], v[0][1]])
                in_acl_val = v[0][0]
                out_acl_val = v[0][1]
                dc = v[0][3]
                gw = v[0][2]

                if (in_acl_val != '' and out_acl_val != ''):
                    valid_acl.append([dc, k, in_acl_val, out_acl_val])
                    # acl_writer.writerow([k, in_acl_val, out_acl_val])
                else:
                    invalid_acl.append([dc, k, in_acl_val, out_acl_val, gw])
                    # invalid_acl_writer.writerow([k, in_acl_val, out_acl_val, v[0][2]])
            else:
                for i in v:
                    invalid_acl.append([i[3], k, i[0], i[1], i[2]])


        columns = ["DC", "Lab Id", "In ACL", "Out ACL"]
        Util.create_excel_sheet(writer, "Valid_Lab_In_Out_ACL", columns, valid_acl)

        dmz_acl_template = invalid_acl.copy()
        columns = ["DC", "Lab Id", "In ACL", "Out ACL", "Gateway"]
        Util.create_excel_sheet(writer, "Valid_Lab_Invalid_In_Out_ACL", columns, invalid_acl)

        columns = ["Host Name", "IP Address", "Status"]
        Util.create_excel_sheet(writer, "Gateway_Process_Status", columns, host_with_ip_status)
        
        writer.close()

        print("Excel : file created")
        is_excel_file_created = True
        
    except Util_Exception as e:
        raise e
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Excel : File couldn't be created \n" + str(e))


def create_final_excel():
    try:
        report_file_names = ["Valid_Lab_Id_Report.csv", 
                            "Invalid_Details.csv", 
                            "LRT_Fromatted_Lab_Id.csv", 
                            "Failed_Gateway.csv", 
                            "Valid_Lab_Ids_Subnet.csv", 
                            "GatewayInt_Inproper_Desc.csv", 
                            "Valid_Lab_Subnet_Exl_Uplink.csv", 
                            "Valid_Lab_In_Out_ACL.csv", 
                            "Valid_Lab_Invalid_In_Out-ACL.csv"]
        final_excel_writer = pd.ExcelWriter('final_report.xlsx')
        for csvfilename in report_file_names:
            df = pd.read_csv(csvfilename)
            df.to_excel(final_excel_writer, sheet_name=csvfilename.replace(".csv", ""), index=False)
        final_excel_writer.save()
        is_final_file_created = True
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Excel:Final : Finale excel couldn't be created \n" + str(e))

def get_SSHResp(chan,cmd):
    chan.send(cmd+'\n')
    while not chan.recv_ready():
        time.sleep(3)
    time.sleep(3)
    
    isBigResponse = False
    out = chan.recv(9999)
    respose = out.decode("ascii")
    
    if '--More--' in respose:
        isBigResponse = True
        respose = respose.replace("--More--", "").replace("\x08", "").strip()
    
    while isBigResponse:        
        chan.send(" " + '\r')
        while not chan.recv_ready():
            time.sleep(3)
        time.sleep(2)
        out = chan.recv(9999)
        temp = out.decode("ascii")        
        respose = respose + "\n" + temp.replace("--More--", "").replace("\x08", "").strip()
        
        if '--More--' not in temp:
            break

    return str(respose)

def cmd1(chan, hostname, log_file):
    log_file.write("CMD1:   show ip int brief | in up \nResponse:\n")
    data = {}
    cmd = 'show ip int brief | in up'

    # check the actual data line from where it is starts
    actual_data = False
    host_found = [True, '-']
    
    res = get_SSHResp(chan, cmd)
    
    all_gw_response[hostname] = dict(cmd1=res)
    log_file.write("\n==========================RES_START==========================\n")
    
    for line in res.split("\n"): 
        if (actual_data):                 
            line = line.strip()
            log_file.write(line + "\n")

            if (line == '' or "unassigned" in line or "unset" in line or ' --More--' in line or hostname in line):
                continue
            
            row = line.split()        
            data[str(row[0].strip())] = dict(ip=str(row[1].strip()))
            
            log_file.write(" "*80 + "VALID:   " + str(row[0].strip()) + "\n")

        if (cmd in line):
            actual_data = True
            log_file.write(line + "\n")

            # gw_name = line.split("#")[0].strip()
            if hostname not in line:
                host_found = [False, line]
    
    log_file.write("\n==========================RES_END============================\n")
    log_file.write("\nCMD1: Done\n\n")
    return [data, host_found]

def get_lab(desc):
    more_lab_match_list = []

    pattern = re.compile(r'LRT[\s:#_-]*\d{4,7}\d*', re.IGNORECASE)
    more_lab_match_list_1 = re.findall(pattern, desc)
    # print(more_lab_match_list_1)
    for i in more_lab_match_list_1: 
        more_lab_match_list.append(i)
        
    pattern = re.compile(r'lab[\s:#_-]*id[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
    more_lab_match_list_1 = re.findall(pattern, desc)
    # print(more_lab_match_list_1)
    for i in more_lab_match_list_1: 
        more_lab_match_list.append(i)
    
    pattern = re.compile(r'lab[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
    more_lab_match_list_1 = re.findall(pattern, desc)
    # print(more_lab_match_list_1)
    for i in more_lab_match_list_1: 
        more_lab_match_list.append(i)

    pattern = re.compile(r'labs[\s:#_-]*\d{4,5}\d*', re.IGNORECASE)
    more_lab_match_list_1 = re.findall(pattern, desc)
    # print(more_lab_match_list_1)
    for i in more_lab_match_list_1: 
        more_lab_match_list.append(i)
    

    ###
    # need to add
    #  (labs id numbers) condition

    # print(more_lab_match_list)

    # number sequence without identifiers. eg: ["to SJ-15-TNQ-STE_50368_dole", "ANCD|CID:1357/12345|#|BW:0Mb/0Mb"]
    # in te output list, using [] identifier to save separate sheet in excel
    if (len(more_lab_match_list) == 0):
        pattern = re.compile(r'\d{4,5}', re.IGNORECASE)
        number_sequence = re.findall(pattern, desc)
        if (len(number_sequence)):
            return "[" + ", ".join(number_sequence) + "]"
        else:
            return None        
    """
    if (len(more_lab_match_list) == 1):
        pattern = re.compile(r'LRT[0-9]+', re.IGNORECASE)
        lrt = pattern.search(desc)
        if (lrt):
            return "valid: " + str(lrt.group())
    """
    if (len(more_lab_match_list) != 0):        
        output_labid_set = set()
        for i in more_lab_match_list:

            pattern = re.compile(r'LRT[0-9]+', re.IGNORECASE)
            lrt = pattern.search(i)
            if (lrt):
                output_labid_set.add(str(lrt.group()))
            else:
                pattern = re.compile(r'\d+', re.IGNORECASE)
                lab_id = pattern.search(i)
                if (lab_id):
                    output_labid_set.add(str(lab_id.group()))
        return ", ".join(output_labid_set)
    return None


def get_valid_lab_id(lab_id, hostname, interface, parent_data, add=True):
    global incorrect_lab_id_with_details
    if len(lab_id) == 4:
        val_lab_id = "LRT000"+lab_id
        if (add):
            incorrect_lab_id_with_details.append(
                [lab_id, val_lab_id ,hostname, interface, parent_data[interface]['ip'], parent_data[interface]["description"]])
        return val_lab_id
    elif len(lab_id) == 5:
        val_lab_id = "LRT00"+lab_id
        if (add):
            incorrect_lab_id_with_details.append(
                [lab_id, val_lab_id, hostname, interface, parent_data[interface]['ip'], parent_data[interface]["description"]])
        return val_lab_id
    elif lab_id == 'LRT0000000' or 'LRT0000' in lab_id or '0' == lab_id:
        val_lab_id = "incorrect lab id"
        if (add):
            incorrect_lab_id_with_details.append(
                [lab_id, val_lab_id, hostname, interface, parent_data[interface]['ip'], parent_data[interface]["description"]])
        return val_lab_id
    elif 'LRT' in lab_id and len(lab_id) != 10:
        id = str(int(lab_id.split("LRT")[1]))
        val_lab_id = get_valid_lab_id(id, None, None, None, False)
        if (add):
            incorrect_lab_id_with_details.append(
                [lab_id, val_lab_id, hostname, interface, parent_data[interface]['ip'], parent_data[interface]["description"]])
        return val_lab_id
    else:
        return lab_id

def get_labid_from_mapping(gw, interface, desc):
    global lab_id_from_mapping_matched_count

    if gw not in gw_int_desc_labid_map:
        return None
    if interface not in gw_int_desc_labid_map[gw]:
        return None
    if desc not in gw_int_desc_labid_map[gw][interface]:
        return None
    
    # print "\n[", gw, interface, desc, gw_int_desc_labid_map[gw][interface][desc],"]\n"
    lab_id_from_mapping_matched_count = lab_id_from_mapping_matched_count + 1
    return gw_int_desc_labid_map[gw][interface][desc]

def cmd2(chan, hostname, interface, ss_lab_cmd4_result, parent_data, log_file):
    log_file.write("CMD2-UP-INT:  " + interface)

    lab_id = None
    actual_data = False
    forward_lab = ''        

    parent_data[interface]["inAcl"] = ''
    parent_data[interface]["outAcl"] = ''
    
    res = ""
    if (interface+"_ss_lab_cmd5" in all_gw_response[hostname]):
        res = all_gw_response[hostname][interface+"_ss_lab_cmd5"]
        
        log_file.write("\nCM2_RESPONSE_FOUNT_FROM_SS_LAB:  " + interface)
    elif (interface+"_up_int_cmd5" in all_gw_response[hostname]):
        res = all_gw_response[hostname][interface+"_up_int_cmd5"]
        
        log_file.write("\nCM2_RESPONSE_FOUNT_FROM_DIFF_UP:  " + interface)
    else:
        log_file.write("\nCM2_NEW_INT:   " + interface)

        res = get_SSHResp(chan, 'sh run int ' + interface)

    # res = get_SSHResp(chan, 'sh run int ' + interface).split("\n")
    # print("\n\n")
    # print(interface + " : ")
    all_gw_response[hostname][interface+"_cmd2"] = res
    log_file.write("\nResponse:")
    log_file.write("\n==========================RES_START==========================\n")
    log_file.write(res)
    log_file.write("\n==========================RES_END============================\n")

    for line in res.split("\n"):
        # if (actual_data):
        # print(line)

        line = str(line.strip())

        if ('description' in line):
            parent_data[interface]["description"] = line

            lab_id = get_lab(line)
            if (lab_id is not None):
                if (',' not in lab_id and '[' not in lab_id):
                    lab_id = get_valid_lab_id(lab_id, hostname, interface, parent_data)
                else:
                    temp_id = get_labid_from_mapping(hostname, interface, parent_data[interface]["description"])
                    lab_id = temp_id if temp_id else lab_id

                parent_data[interface]["labid"] = lab_id
                # got_lapid = True

        elif ("forwarding" in line and lab_id 
                                    and ',' not in lab_id 
                                    and '[' not in lab_id 
                                    and "incorrect lab id" not in lab_id):
            parent_data[interface]["forwarding_lab"] = line
            forward_lab = line.split(" ")[-1].strip()
            get_subnet_nexthop_cmd3(chan, hostname, forward_lab, interface, lab_id, parent_data, log_file)
            # break
                    
        # for inACL & outACL
        elif ( # forward_lab != '' and 
                forward_lab != 'ss-lab'
                and line.startswith("ip ") 
                and " access-group " in line 
                and (line.endswith(" in") or line.endswith(" out"))):
            acl = line.split(" ")[2]

            if line.endswith(" in"):
                acl = acl if acl.endswith("in") else acl + "in"
                parent_data[interface]["inAcl"] = acl
            else:
                acl = acl if acl.endswith("out") else acl + "out"
                parent_data[interface]["outAcl"] = acl
        """
        if ("interface" in line):
            actual_data = True
            log_file.write("\n" + line + "\n")            
        """
    
    log_file.write("\n")
    log_file.write("IN_ACL :  " + parent_data[interface]["inAcl"] + "\n")
    log_file.write("OUT_ACL:  " + parent_data[interface]["outAcl"] + "\n")
    log_file.write("FORWARD_LAB:  " + str(forward_lab) + "\n")

    """
    log_file.write("\n")
    if (forward_lab == "ss-lab" and parent_data[interface]["outAcl"] == ''):        
        ss_lab_cmd4_run = ss_lab_cmd4_result[0]
        ss_lab_cmd4_value = ss_lab_cmd4_result[1]

        # if-else, to prevent unnecessary execution.
        # run the ss_lab_cmd4() in one time and storing the result for future use for single Gateway                
        if (ss_lab_cmd4_run and ss_lab_cmd4_value != "Not Found"):
            log_file.write("SS_LAB_CMD4 : Ran already\n")
            log_file.write("VALUE       : " + ss_lab_cmd4_value + "\n")

            parent_data[interface]["outAcl"] = ss_lab_cmd4_value
        else: 
            if (not ss_lab_cmd4_run):
                ss_lab_acl_new_result = ss_lab_cmd4(chan, hostname, parent_data, log_file)
                ss_lab_cmd4_result[0] = True
                ss_lab_cmd4_result[1] = ss_lab_acl_new_result
                # ss_lab_cmd4_run = True
                # ss_lab_cmd4_value = ss_lab_acl_result
                if (ss_lab_acl_new_result != "Not Found"):
                    parent_data[interface]["outAcl"] = "lab-lenientout" if ss_lab_acl_new_result == "lab-lenientout" else "global-uplinkout"
                
                log_file.write("SS_LAB_CMD4 : Ran first time\n")
                log_file.write("VALUE       : "+ ss_lab_acl_new_result + "\n")
                log_file.write("\n\nCMD4: Done\n\n")
            else:
                log_file.write("SS_LAB_CMD4 : Ran already\n")
                log_file.write("VALUE       : " + ss_lab_cmd4_value + "\n")
    """

    if (lab_id 
        # and "subnet" in parent_data[interface]
        # and forward_lab != '' 
        and forward_lab != 'ss-lab'
        and ',' not in lab_id 
        and '[' not in lab_id):
        # and (parent_data[interface]["inAcl"] != '' or parent_data[interface]["outAcl"] != '')):

        if ( lab_id not in inAcl_outAcl_labId_gw_merge):
            inAcl_outAcl_labId_gw_merge[lab_id] = []
        
        curr_dc = get_dc(hostname)
        inAcl_outAcl_labId_gw_merge[lab_id].append([parent_data[interface]["inAcl"], parent_data[interface]["outAcl"], hostname, curr_dc])    
    
    log_file.write("\nOUTPUT:\n")
    log_file.write(interface + ":   " + str(parent_data[interface]))
    log_file.write("\n\nCMD2: "+interface+" is done\n\n")

def get_subnet_nexthop_cmd3(chan, hostname, forward, interface, lab_id, parent_data, log_file):
    log_file.write("\nCMD3:   " + 'sh ip cef vrf ' + forward + ' ' + interface)
    
    
    # print(forward)
    actual_data = False
    subnet_list = []
    nexthop_list = []
    nexthop_list_set = set()

    cmd = 'sh ip cef vrf ' + forward + ' ' + interface
    res = get_SSHResp(chan, cmd)
    
    all_gw_response[hostname][interface+"_cmd3"] = res
    log_file.write("\nResponse:")
    log_file.write("\n==========================RES_START==========================\n")
    log_file.write(res)
    log_file.write("\n==========================RES_END============================\n")
    
    for line in res.split("\n"):
        if (actual_data):
            # print(line)
            line = line.strip()

            if (line == '' or 'attached' in line or hostname in line):
                continue
            
            # if (interface in line and "nexthop" in line):
            if ("nexthop" in line):
                    nexthop_list_set.add(str(line.strip().split(" ")[1].strip()))
            else:
                subnet = line.strip()
                if (subnet != '' and 'attached' not in line and 'nexthop' not in line):
                    subnet_list.append(str(subnet))

        if (cmd in line):
            actual_data = True

    if (len(subnet_list)):
        parent_data[interface]['subnet'] = ", ".join(subnet_list)
    if (len(nexthop_list_set)):
        parent_data[interface]['nexthop'] = ", ".join(list(nexthop_list_set))    
    
    curr_dc = get_dc(hostname)

    if (len(subnet_list) and len(nexthop_list_set) and 'LRT' in lab_id):
        for subnet in subnet_list:
            # subnet with lab id merge
            if subnet in subnet_with_lab_dict:
                # subnet_with_lab_dict[subnet].add(lab_id)
                subnet_with_lab_dict[subnet]["lab_ids"].add(lab_id)
                subnet_with_lab_dict[subnet]["dc"].add(curr_dc)
            else:
                # subnet_with_lab_dict[subnet] = {lab_id}
                subnet_with_lab_dict[subnet] = dict(lab_ids=set(), dc=set(), start_ip=0, end_ip=0)
                subnet_with_lab_dict[subnet]["lab_ids"].add(lab_id)
                subnet_with_lab_dict[subnet]["dc"].add(curr_dc)

                start_ip, end_ip = NetWork_Util.get_ip_range(subnet)
                start_ip_range = NetWork_Util.ip_to_integer(start_ip)
                end_ip_range = NetWork_Util.ip_to_integer(end_ip)
                subnet_with_lab_dict[subnet]["start_ip_range"] = start_ip_range
                subnet_with_lab_dict[subnet]["end_ip_range"] = end_ip_range

            # lab_id, gateway, subnet merge and missing and uplink
            if lab_id not in labid_gw_subnet_merge:
                labid_gw_subnet_merge[lab_id] = {hostname: {'uplink': set(), 'subnet': set()},
                                                'labSubnets': set()}
            elif lab_id in labid_gw_subnet_merge and hostname not in labid_gw_subnet_merge[lab_id]:
                labid_gw_subnet_merge[lab_id][hostname] = {'uplink': set(), 'subnet': set()}

            if "/30" in subnet or "/32" in subnet:
                labid_gw_subnet_merge[lab_id][hostname]['uplink'].add(subnet)
            else:
                labid_gw_subnet_merge[lab_id][hostname]['subnet'].add(subnet)
                labid_gw_subnet_merge[lab_id]['labSubnets'].add(subnet)

    # print(parent_data[interface]['subnet'])
    # print(parent_data[interface]['nexthop'])
    log_file.write("\n\nCMD3: Done\n\n")    

def ss_lab_cmd4(chan, hostname, parent_data, log_file):
    log_file.write("\nCMD4:   sh ip cef vrf ss-lab")
    # actual_data -> use to skip Cisco default messag
    actual_data = False

    # int_proccessed_set -> this will prevent dublicate execution on single GW
    int_proccessed_set = set()

    cmd = 'sh ip cef vrf ss-lab'
    res = get_SSHResp(chan, cmd)
    # excel cell limit issue
    # all_gw_response[hostname]["sh_ip_cef_vrf_ss_lab_cmd4"] = res
    log_file.write("\nResponse:")
    log_file.write("\n==========================RES_START==========================\n")
    log_file.write(res)
    log_file.write("\n==========================RES_END============================\n")

    for line in res.split("\n"):    
        line = str(line).strip()

        if (actual_data):

            line_list = [x.strip() for x in line.split()]            
                        
            if (len(line_list) == 3 and 'Prefix' != line_list[0]
                                    and 'Next Hop' != line_list[1]
                                    and '' != line_list[2]
                                    and 'Interface' not in line_list[2]
                                    and 'Null' not in line_list[2] ):
                interface = line_list[2]
                if (interface not in int_proccessed_set):
                    int_proccessed_set.add(interface)
                    result = lab_lenient_or_global_uplink_cmd5(chan, hostname, interface, "_ss_lab_cmd5", log_file)
                    if (result != "Not Found"):
                        return result
                    
        if (cmd in line):
            actual_data = True            
    
    up_interface_set = {interface for interface in parent_data.keys()}
    up_interface_diff_set = up_interface_set.difference(int_proccessed_set)

    log_file.write("\nup int                  : ")
    log_file.write(str(up_interface_set))
    log_file.write("\nprocessed ss-lab int    : ")
    log_file.write(str(int_proccessed_set))
    log_file.write("\ndiff up int             : ")
    log_file.write(str(up_interface_diff_set))
    log_file.write("\n\nss_lab_cmd4 -> diff_up_int -> lab_lenient_or_global_uplink_cmd5\n")

    for interface in up_interface_diff_set:
        result = lab_lenient_or_global_uplink_cmd5(chan, hostname, interface, "_up_int_cmd5", log_file)
        if (result != "Not Found"):
            return result
                
    return "Not Found"

def lab_lenient_or_global_uplink_cmd5(chan, hostname, interface, cmd_number, log_file):
    log_file.write("\nFROM: " + cmd_number)
    log_file.write("\nCMD5: sh run interface " + interface)    
    
    actual_data = False
    cmd = 'sh run interface ' + interface


    res = ""
    if (interface+"_cmd2" in all_gw_response[hostname]):
        res = all_gw_response[hostname][interface+"_cmd2"]
        
        log_file.write("\nCMD5_INT_RESPONSE_FOUND_FROM_CMD2:  " + interface)
    else:
        log_file.write("\nCD5_NEW_INT:   " + interface)
        
        res = get_SSHResp(chan, cmd)

    
    all_gw_response[hostname][interface + cmd_number] = res
    log_file.write("\nResponse:")
    log_file.write("\n==========================RES_START==========================\n")
    log_file.write(res)
    log_file.write("\n==========================RES_END============================\n")

    if ("ip access-group lab-lenient out" in res):
            # log_file.write("\nVALUE_FOUND:    lab-lenient\n")
            return "lab-lenientout"
    elif ("ip access-group global-uplink out" in res):
            # log_file.write("\nVALUE_FOUND:    global-uplink\n")
            return "global-uplinkout"
    
    """
    for line in res.split("\n"):    
        line = str(line).strip()        
        log_file.write(line + "\n")
        
        if ("ip access-group lab-lenient out" == line):
            return "lab-lenientout"
        elif ("ip access-group global-uplink out" == line):
            return "global-uplinkout"
    """
                
    # log_file.write("VALUE_FOUND: Not\n")    
    return "Not Found"

def get_DeviceStatus(hostname, gw_ip):
    global gw_done_count, gw_error_count, gw_finished_count, gw_invoke_shell_error_count, no_status_for_gw
    f = None

    print("{:<5}  {:<16}  {:<30}  {:<12}  {:<12}  {}\n".format("----", gw_ip, hostname, '-', '-', "started"))    
    
    status_msg = 'No Status'
    output_count = 0
    host_name_not_found = ['', '']
    ss_lab_cmd4_result = [False, "Not Found"]
    
    try:
        f = open("log/"+hostname+".txt", "w")

        ssh = get_paramiko_client(gw_ip)
        chan = ssh.invoke_shell()
        
        [data, host_name_not_found] = cmd1(chan, hostname, f)
        for interface in data.keys():
            cmd2(chan, hostname, interface, ss_lab_cmd4_result, data, f)
        output_count = create_data(hostname, gw_ip,data)

        status_msg = "done"
        
        gw_done_count = gw_done_count + 1
        # output_count = len(da)

        close_resource(ssh)
        close_resource(f)
    
    except PIA_Exception as e:
        # e = traceback.format_exc()
        status_msg = str(e)
        # failed_host_with_ip_status.append([hostname, gw_ip, str(e)])

        gw_error_count = gw_error_count + 1
    except Exception:
        e = traceback.format_exc()
        status_msg = str(e)
        if "object has no attribute 'invoke_shell'" in status_msg:
            status_msg = "Could not request an interactive shell session. \nMaybe object has no attribute 'invoke_shell'"
            gw_invoke_shell_error_count = gw_invoke_shell_error_count + 1
        # failed_host_with_ip_status.append([hostname, gw_ip, str(e)])

        gw_error_count = gw_error_count + 1
    finally:
        host_with_ip_status.append([hostname, gw_ip, status_msg])
        gw_finished_count = gw_finished_count + 1

        print("{:<5}  {:<16}  {:<30}  {:<12}  {:<12}  {}\n".format(gw_finished_count, gw_ip, hostname, str(host_name_not_found[0]), output_count, status_msg))
        
        if (not host_name_not_found[0] and ("Authentication failed!" not in status_msg 
                                            and "Device is not connected" not in status_msg 
                                            and "Network is unreachable" not in status_msg
                                            and "Connection timed out" not in status_msg
                                            and "Could not request an interactive shell session" not in status_msg
                                            and "Unknown error" not in status_msg)):
            host_not_matched_list.append([gw_ip, hostname, host_name_not_found[1]])

def init_for_lab_id_from_mapping():
    #gw_int_desc_labid_map
    global lab_id_from_mapping_count
    try:
        print('inside try-----------------------------------')
        csv_file = open('input/gw_int_desc_labid_map.csv','r')
        csv_data = csv.reader(csv_file)
        for line in csv_data:
            
            if (len(line) == 0):
                continue

            if ('' == line[0] or ('gw' == line[0] and 'labid' in line[3])):
                continue

            gw = line[0].strip()
            interface = line[1].strip()
            desc = line[2].strip()
            labId = line[3].strip()

            if (gw not in gw_int_desc_labid_map):
                gw_int_desc_labid_map[gw] = {}

            if (interface not in gw_int_desc_labid_map[gw]):
                gw_int_desc_labid_map[gw][interface] = {}

            if (desc not in gw_int_desc_labid_map[gw][interface]):
                gw_int_desc_labid_map[gw][interface][desc] = labId
                
                lab_id_from_mapping_count = lab_id_from_mapping_count + 1
            
        print("Input:Excel :  GW->Int->Desc->LabId mapping list is fetched from gw_int_desc_labid_map.csv")
        print("Input:Excel :  count: " + str(lab_id_from_mapping_count))
        close_resource(csv_file)
    except:
        e = traceback.format_exc()
        raise PIA_Exception("Input:Excel :  GW->Int->Desc->LabId mapping list couldn't be fetched from gw_int_desc_labid_map.csv\n" + str(e))

def get_lab_gateway_as_list():
    gw_set = set()
    try:
        csv_file = open('input/Gateway_with_lab_type.csv','r')
        csv_data = csv.reader(csv_file)
        for line in csv_data:
            lab_tpe = line[1].strip()
            gw = line[0].strip()
            #print('' in line or '' in line[0] or 'Lab ID' == line[0] or "ss-dmzlab" not in forwarding_info)
            if ('' == line or '' == gw or 'Remark' == lab_tpe or "Lab" not in lab_tpe):
                continue
            
            gw_set.add(gw)
            print("{} - {}".format(gw, lab_tpe))

        Gateway_Util.close_resource(csv_file)

        return gw_set
    except Gateway_Util_Exception as e:
        raise e
    except Exception as e:
        raise e
    
def get_script_date_time():
    try:
        print("Config : Reading date from config/PIA_SCRIPT_DATE.txt...", end="")
        f = open("config/PIA_SCRIPT_DATE.txt", "r")
        date = f.read().strip()
        print(" | Date = " + date)
        return date
    except Exception as e:
        print(" | Error")
        raise e

def process():
    global current_exec_count, gw_done_count, gw_error_count, gw_unreachable_count, gw_conn_time_out_count, gw_not_connected_count, gw_unknown_error_count, gw_auth_failed_count, is_excel_file_created
    global lab_id_from_mapping_matched_count, lab_id_from_mapping_count, gw_invoke_shell_error_count, gw_nslookup_error
    global dmz_acl_template, job_id
    error_message = ''
    got_error = False
    try:
        print("Process :  started")

        # init_db()
        init_for_lab_id_from_mapping()
             
        # exec_count = get_script_today_status()
        exec_count = 0
        if exec_count >= 0:
            # gw_with_ip = get_input_gw(0)
            # old list
            # gw_with_ip =  [["aar02-lab-gw1", None],["alln01-lab-gw1"],["awn01-lab-gw1"],["ala03-lab-gw1"],["aer01-mda1-lab-gw1"],["aer01-mda2-lab-gw2"],["alp03-lab-gw1"],["alp03-lab-gw2"],["amm02-lab-gw1"],["ams5-lab-gw1"],["ann01-lab-gw1"],["argrp1-in-lab-gw1"],["argrp4-in-lab-gw1"],["argrp4-in-lab-gw2"],["argrp5-in-lab-gw1"],["ath01-lab-gw1"],["atl-lab-gw1"],["atl11-lab-gw1"],["akl02-lab-gw1"],["ast04-lab-gw1"],["ast09-lab-gw1"],["ast09-lab-gw2"],["bgl11-00-lab-gw1"],["bgl11-00-lab-gw2"],["bgl12-00-lab-gw1"],["bgl12-00-lab-gw2"],["bgl13-lab-gw2"],["bgl13-lab-gw1"],["bgl14-00-lab-gw2"],["bgl14-00-lab-gw1"],["bgl15-00-lab-gw1"],["bgl15-00-lab-gw2"],["bgl16-00-lab-gw2"],["bgl16-00-lab-gw1"],["bgl17-dmzvlab-gw1"],["bgl17-00-lab-gw2"],["bgl17-00-lab-gw1"],["bgl18-00-lab-gw1"],["bgl18-00-lab-gw2"],["bgl25-lab-gw1"],["bgl26-lab-gw1"],["bng02-lab-gw1"],["brc2-lab-gw1"],["brc2-lab-gw2"],["bvw01-lab-gw1"],["bdlk10-00-lab-gw1"],["bdlk10-31-lab-gw1"],["bdlk11-00-lab-gw1"],["bdlk11-00-lab-gw2"],["bdlk09-00-lab-gw2"],["bdlk09-00-lab-gw1"],["bdlk09-12-lab-gw1"],["bjn6-lab-gw1"],["bjn6-lab-gw2"],["bey01-lab-gw1"],["bel01-lab-gw2"],["bel01-lab-gw1"],["beg02-lab-gw1"],["blv-lab-gw1"],["bnt01-lab-gw1"],["blndc01-lab-gw2"],["blndc01-lab-gw1"],["bln2-lab-gw1"],["bln2-lab-gw2"],["bgt2-lab-gw1"],["bonn01-lab-gw1"],["bos02-lab-gw1"],["bxb23-lab-gw1"],["bxb23-lab-gw2"],["bla-lab-gw1"],["bts05-lab-gw1"],["brb05-lab-gw1"],["bcr2-lab-gw1"],["bud01-lab-gw1"],["bua2-lab-gw1"],["cae02-lab-gw2"],["cae02-lab-gw1"],["cai02-lab-gw1"],["clg5-lab-gw2"],["clg5-lab-gw1"],["cbr04-lab-gw1"],["csb03-lab-gw2"],["csb03-lab-gw1"],["csb04-lab-gw1"],["csb04-lab-gw2"],["cas02-lab-gw1"],["csv-lab-gw1"],["chn08-lab-gw1"],["chn09-lab-gw2"],["chn09-lab-gw1"],["chg12-lab-gw1"],["chg12-lab-gw2"],["cjs04-lab-gw1"],["cgn03-lab-gw2"],["cgn03-lab-gw1"],["cmb03-lab-gw1"],["ccntrx7-us-lab-gw1"],["cph06-lab-gw1"],["cosm02-lab-gw1"],["cwy01-lab-gw1"],["cwy01-lab-gw2"],["dlc02-lab-gw2"],["dlc02-lab-gw1"],["dgm-lab-gw1"],["dgm2-lab-gw2"],["dgm2-lab-gw1"],["dgm2-lab-gw3"],["dgm3-lab-gw1"],["dgm3-lab-gw2"],["doh03-lab-gw1"],["dbi03-lab-gw1"],["dblir3-lab-gw1"],["dlf1-lab-gw1"],["els01-lab-gw1"],["embsys2-in-lab-gw1"],["embsys2-in-lab-gw2"],["fkf3-lab-gw2"],["fkf3-lab-gw1"],["esp02-lab-gw1"],["est1-jo-lab-gw2"],["est1-jo-lab-gw1"],["foxc1-cn-lab-gw1"],["fka1-lab-gw1"],["ful01-lab-gw2"],["ful01-lab-gw1"],["gwy03-lab-gw1"],["got-lab-gw1"],["glj3-lab-gw1"],["gng03-lab-gw1"],["ggn01-lab-gw2"],["ggn01-lab-gw1"],["hal01-lab-gw1"],["hbg-lab-gw1"],["hgh05-lab-gw1"],["hgh06-ext-lab-gw1"],["hgh06-ext-lab-gw2"],["hni05-lab-gw1"],["hcl14-in-lab-gw1"],["hcl14-in-lab-gw2"],["hcl17-in-lab-gw2"],["hcl17-in-lab-gw1"],["hcl19-in-lab-gw2"],["hcl19-in-lab-gw1"],["hcl7-in-lab-gw2"],["hcl7-in-lab-gw1"],["hfe02-lab-gw1"],["hfe02-lab-gw2"],["hrn6-lab-gw2"],["hrn6-lab-gw1"],["hkg1-lab-gw1"],["hkg1-lab-gw2"],["ibm3-bg-lab-gw1"],["ibm3-bg-lab-gw2"],["infy9-in-lab-gw1"],["ips02-lab-gw1"],["irv8-lab-gw1"],["ist2-lab-gw1"],["jkt05-lab-gw1"],["jkt05-lab-gw2"],["knv-lab-gw1"],["kjk04-lab-gw1"],["krk02-lab-gw1"],["krk04-lab-gw1"],["krk07-lab-gw2"],["krk07-lab-gw1"],["kul02-lab-gw1"],["kwi01-lab-gw1"],["los03-lab-gw1"],["lwr01-lab-gw2"],["lwr01-lab-gw1"],["lma1-lab-gw1"],["lion3-pl-lab-gw1"],["lju02-lab-gw1"],["lon06-lab-gw1"],["lon07-lab-gw1"],["lux1-lab-gw1"],["lys01-lab-gw1"],["lys01-lab-gw2"],["mdr1-lab-gw1"],["man3-lab-gw1"],["mhm03-lab-gw1"],["mel03-lab-gw1"],["mxc-14-lab-gw1"],["mxc10-lab-gw2"],["mxc10-lab-gw1"],["mxc12-lab-gw2"],["mxc12-lab-gw1"],["mim1-lab-gw1"],["mrd01-lab-gw2"],["mrd01-lab-gw1"],["mil01-lab-gw2"],["mil01-lab-gw1"],["mtc2-in-lab-gw1"],["mtl02-lab-gw1"],["mmb12-lab-gw2"],["mmb12-lab-gw1"],["muc07-lab-gw1"],["musc01-lab-gw1"],["ngo1-lab-gw1"],["nbo03-lab-gw1"],["ntn01-lab-gw1"],["ntn01-lab-gw2"],["nyc1-lab-gw2"],["nyc1-lab-gw1"],["nsd5-lab-gw1"],["nsd5-lab-gw2"],["nue01-lab-gw1"],["ors03-lab-gw2"],["ors03-lab-gw1"],["osk04-lab-gw1"],["ott01-lab-gw1"],["ott02-lab-gw1"],["par03-lab-gw1"],["par03-lab-gw2"],["pen3-lab-gw2"],["pen3-lab-gw1"],["prt3-lab-gw1"],["prg5-lab-gw1"],["prg5-lab-gw2"],["prg7-lab-gw2"],["prg7-lab-gw1"],["pnq05-lab-gw2"],["pnq05-lab-gw1"],["gpk03-lab-gw1"],["gpk03-lab-gw2"],["rcdn5-lab-gw2"],["rcdn5-lab-sipt-sw1"],["rcdn5-lab-gw1"],["rcdn5-dmzlab-gw2"],["rcdn6-lab-gw2"],["rcdn6-lab-gw1"],["rcdn9-sdfa-dmzvlab-gw1"],["rcdn9-cd2-lab-gw2"],["rcdn9-cd1-lab-gw1"],["req01-lab-gw1"],["req02-lab-gw1"],["ryd4-lab-gw1"],["gai03-lab-gw2"],["gai03-lab-gw1"],["rol01-lab-gw1"],["rom2-lab-gw1"],["rtp1-dmzlab-gw1"],["rtp1-lab-gw1"],["rtp1-lab-gw2"],["rtp10-00-lab-gw2"],["rtp10-00-lab-gw1"],["rtp10-cd-dmzvlab-gw1"],["rtp11-dmzlab-gw1"],["rtp11-lab-gw2"],["rtp11-lab-gw1"],["rtp12-00-lab-gw1"],["rtp12-00-lab-gw2"],["rtp2-lab-gw1"],["rtp3-lab-gw1"],["rtp4-00-lab-gw2"],["rtp4-00-lab-gw1"],["rtp5-dmzvlab-gw1"],["rtp5-dmzlab-gw1"],["rtp5-lab-gw2"],["rtp5-lab-gw1"],["rtp6-lab-gw2"],["rtp6-lab-gw1"],["rtp7-lab-gw2"],["rtp7-lab-gw1"],["rtp8-lab-gw2"],["rtp8-lab-gw1"],["rtp9-lab-gw1"],["rtp9-lab-gw2"],["sla01-lab-gw1"],["sla01-lab-gw2"],["sjocr02-lab-gw1"],["snt03-lab-gw1"],["spl1-lab-gw1"],["schp01-lab-gw1"],["sea1-lab-gw1"],["sea1-lab-gw2"],["sol2-lab-gw1"],["shn15-lab-gw1"],["shn15-lab-gw2"],["shn17-lab-gw2"],["shn17-lab-gw1"],["shn6-lab-gw1"],["shn7-lab-gw2"],["shn7-lab-gw1"],["shn4-lab-gw1"],["shn4-lab-gw2"],["szn04-lab-gw1"],["szn05-lab-gw1"],["svta01-lab-gw1"],["sngidc-dmzvlab-gw1"],["sngidc-dmzvlab-gw2"],["sng15-lab-gw2"],["sng15-lab-gw1"],["sjc01-lab-gw2"],["sjc01-lab-gw1"],["sjc02-lab-gw1"],["sjc02-lab-gw2"],["sjc03-lab-gw2"],["sjc03-lab-gw1"],["sjc04-lab-gw2"],["sjc04-lab-gw1"],["sjc05-lab-gw1"],["sjc05-lab-gw2"],["sjc06-lab-gw2"],["sjc06-lab-gw1"],["sjc07-lab-gw2"],["sjc07-lab-gw1"],["sjc08-lab-gw1"],["sjc08-lab-gw2"],["sjc09-lab-gw1"],["sjc09-lab-gw2"],["sjc10-lab-gw1"],["sjc10-lab-gw2"],["sjc11-lab-gw1"],["sjc12-lab-gw2"],["sjc12-lab-gw1"],["sjc13-lab-gw2"],["sjc13-lab-gw1"],["sjc14-lab-gw2"],["sjc14-lab-gw1"],["sjc15-lab-gw1"],["sjc15-lab-gw2"],["sjc16-lab-gw2"],["sjc16-lab-gw1"],["sjc17-lab-gw2"],["sjc17-lab-gw1"],["sjc18-lab-gw1"],["sjc18-lab-gw2"],["sjc19-lab-gw1"],["sjc19-lab-gw2"],["sjc20-lab-gw1"],["sjc20-lab-gw2"],["sjc21-lab-gw2"],["sjc21-lab-gw1"],["sjc22-lab-gw1"],["sjc22-lab-gw2"],["sjc23-lab-gw1"],["sjc23-lab-gw2"],["sjc24-lab-gw1"],["sjc24-lab-gw2"],["sjcp-lab-gw2"],["sjcp-lab-gw1"],["syc02-lab-gw1"],["mnl02-lab-gw1"],["sof2-lab-gw1"],["sof7-lab-gw2"],["sof7-lab-gw1"],["sprg01-lab-gw2"],["sprg01-lab-gw1"],["stld1-lab-gw2"],["stld1-lab-gw1"],["stk03-lab-gw2"],["stk03-lab-gw1"],["stk06-lab-gw2"],["stk06-lab-gw1"],["stg02-lab-gw1"],["sykes1-co-lab-gw1"],["sykes2-cr-lab-gw1"],["tpe02-lab-gw1"],["tmh2-in-lab-gw2"],["tmh2-in-lab-gw1"],["twl03-lab-gw1"],["tky7-lab-gw1"],["tky7-lab-gw2"],["trn6-lab-gw2"],["trn6-lab-gw1"],["tul04-lab-gw2"],["tul04-lab-gw1"],["tun03-lab-gw1"],["vnc2-lab-gw1"],["vnc3-lab-gw2"],["vnc3-lab-gw1"],["vnaa-lab-gw1"],["vbn02-lab-gw2"],["vbn02-lab-gw1"],["vmct04-lab-gw1"],["vmct05-lab-gw2"],["vmct05-lab-gw1"],["wdf02-lab-gw1"],["wlsn01-lab-gw1"],["wlt06-lab-gw1"],["wlt06-lab-gw2"],["waw02-lab-gw1"],["wshdc02-lab-gw1"],["wln2-lab-gw1"],["wnp02-lab-gw1"],["wpr2-in-lab-gw1"],["wpr8-in-lab-gw1"],["yer03-lab-gw1"],["zgr02-lab-gw1"]]
            # gw_with_ip =  [["mtv5-mda1-cibb-gw1", None], ["sfo12-cibb-gw2"], ["sjc18-lab-gw2"], ["sjc22-lab-gw2"], ["sjc22-lab-gw1"], ["sjc18-lab-gw1"], ["tyoidc5-cp-pxtr1-gw2"], ["clg5-lab-gw1"], ["clg5-lab-gw2"], ["sjc12-cp-mgre1-gw1"], ["cjs04-lab-gw1"], ["wnp02-lab-gw1"], ["mxc-14-lab-gw1"], ["bnt01-lab-gw1"], ["lma1-lab-gw1"], ["bla-lab-gw1"], ["sjocr02-lab-gw1"], ["mxc10-lab-gw2"], ["mxc10-lab-gw1"], ["snt03-lab-gw1"], ["alln01-mda2-cp-pxtr1-gw2"], ["alln01-mda1-cibb-gw3"], ["rcdn9-cd1-cp-mgre1-gw1"], ["alln01-mda2-dmzaas-gw2"], ["alln01-mda1-cp-pxtr1-gw1"], ["alln01-mda2-cibb-gw4"], ["ast04-lab-gw1"], ["alln01-lab-gw1"], ["alln01-mda1-dmzaas-gw1"], ["rcdn9-cd2-cp-mgre1-gw2"], ["rcdn5-lab-sipt-sw1"], ["bgt2-lab-gw1"], ["rcdn5-lab-gw1"], ["ast09-lab-gw2"], ["ast09-lab-gw1"], ["glj3-lab-gw1"], ["bua2-lab-gw1"], ["spl1-lab-gw1"], ["ast04-cibb-gw2"], ["rcdn9-sdfc-dmzvaas-gw2"], ["rcdn9-sdfa-dmzvaas-gw1"], ["rcdn5-lab-gw2"], ["ast04-cibb-gw1"], ["rcdn6-lab-gw2"], ["rcdn9-sdfa-dmzvlab-gw1"], ["rcdn6-lab-gw1"], ["rcdn5-cibb-gw1"], ["rcdn9-cd2-lab-gw2"], ["rcdn9-cd1-lab-gw1"], ["rcdn5-dmzlab-gw2"], ["rcdn9-cd2-dmzaas-gw2"], ["rcdn9-cd1-dmzaas-gw1"], ["lion3-pl-lab-gw1"], ["ntn01-lab-gw1"], ["ntn01-lab-gw2"], ["mtl02-lab-gw1"], ["hal01-lab-gw1"], ["ntn01-cp-pxtr1-gw1"], ["bos02-lab-gw1"], ["nyc1-lab-gw1"], ["nyc1-lab-gw2"], ["awn01-lab-gw1"], ["ntn01-cp-pxtr1-gw2"], ["ott02-lab-gw1"], ["ott01-lab-gw1"], ["bxb23-lab-gw1"], ["cai02-lab-gw1"], ["bxb23-lab-gw2"], ["cas02-lab-gw1"], ["ryd4-lab-gw1"], ["waw02-lab-gw1"], ["man3-lab-gw1"], ["lys01-lab-gw1"], ["vnaa-lab-gw1"], ["got-lab-gw1"], ["dgm3-lab-gw2"], ["prg5-lab-gw1"], ["muc07-lab-gw1"], ["dgm2-lab-gw2"], ["vbn02-lab-gw1"], ["krk07-lab-gw2"], ["bts05-lab-gw1"], ["lys01-cibb-gw1"], ["ist2-lab-gw1"], ["sof7-lab-gw2"], ["cae02-lab-gw1"], ["zgr02-lab-gw1"], ["brc2-lab-gw2"], ["ams5-lab-gw1"], ["prg5-lab-gw2"], ["stk03-lab-gw2"], ["vbn02-lab-gw2"], ["bonn01-lab-gw1"], ["ath01-lab-gw1"], ["dblir3-lab-gw1"], ["cae02-lab-gw2"], ["lys01-lab-gw2"], ["brc2-lab-gw1"], ["mhm03-lab-gw1"], ["ibm3-bg-lab-gw1"], ["los03-lab-gw1"], ["ibm3-bg-lab-gw2"], ["dgm2-lab-gw3"], ["mdr1-lab-gw1"], ["dgm2-lab-gw1"], ["dlf1-lab-gw1"], ["dgm-lab-gw1"], ["krk07-lab-gw1"], ["lys01-cibb-gw2"], ["est1-jo-lab-gw1"], ["est1-jo-lab-gw2"], ["stk03-lab-gw1"], ["dgm3-lab-gw1"], ["vmct04-lab-gw1"], ["ala03-lab-gw1"], ["krk02-lab-gw1"], ["aer01-mda1-cp-pxtr1-gw1"], ["sof7-lab-gw1"], ["amm02-lab-gw1"], ["krk04-lab-gw1"], ["lon11-cibb-gw2"], ["doh03-lab-gw1"], ["sykes1-co-lab-gw1"], ["els01-lab-gw1"], ["wlsn01-lab-gw1"], ["loncaf-cp-pxtr1-gw1"], ["lju02-lab-gw1"], ["vmct05-lab-gw2"], ["loncaf-cp-pxtr1-gw2"], ["lon11-cibb-gw1"], ["tun03-lab-gw1"], ["cph06-lab-gw1"], ["rol01-lab-gw1"], ["stk06-lab-gw1"], ["beg02-lab-gw1"], ["aer01-mda1-lab-gw1"], ["aer01-mda2-cp-pxtr1-gw2"], ["stk06-lab-gw2"], ["aer01-mda2-lab-gw2"], ["lon06-lab-gw1"], ["musc01-lab-gw1"], ["sof2-lab-gw1"], ["vmct05-lab-gw1"], ["rom2-lab-gw1"], ["gpk03-lab-gw1"], ["els01-cibb-gw2"], ["aer01-mda2-cp-mgre1-gw2"], ["fkf3-lab-gw1"], ["gpk03-cibb-gw1"], ["fkf3-lab-gw2"], ["gpk03-cibb-gw2"], ["aer01-mda1-cp-mgre1-gw1"], ["gpk03-lab-gw2"], ["lon07-lab-gw1"], ["dbi03-lab-gw1"], ["bcr2-lab-gw1"], ["kjk04-lab-gw1"], ["nue01-lab-gw1"], ["nbo03-lab-gw1"], ["bud01-lab-gw1"], ["stg02-lab-gw1"], ["kwi01-lab-gw1"], ["gwy03-lab-gw1"], ["ips02-lab-gw1"], ["rtp1-mda2-cibbfo-sw1"], ["rtp1-mda2-cibbfo-sw2"], ["sjc20-cz-sdlab-gw1"], ["hrn6-lab-gw1"], ["hkg1-lab-gw2"], ["rtp1-mda2-cibb-fw1"], ["sjc21-cz-sdlab-gw2"], ["sjc20-cz-sdlab-gw2"], ["rtp1-mda2-cibb-fw1"], ["tpe02-lab-gw1"], ["sjc21-cz-sdlab-gw1"], ["hkg1-lab-gw1"], ["hrn6-lab-gw2"], ["atl-lab-gw1"], ["rtp1-mda2-cibb-wan-gw2"], ["rtp1-mda2-cibb-wan-gw1"], ["rtp10-cd-cp-mgre1-gw1"], ["lwr01-lab-gw1"], ["rtp7-cibb-gw1"], ["rtp10-cd-cp-pxtr1-gw1"], ["bjn6-lab-gw1"], ["lwr01-lab-gw2"], ["rtp1-mda2-cibb-fw1-ironport"], ["knv-lab-gw1"], ["bjn6-lab-gw2"], ["knv3-cibb-gw2"], ["knv3-cibb-gw1"], ["stld1-mda1-cp-mgre1-gw1"], ["stld1-mda2-cp-mgre1-gw2"], ["csb04-lab-gw2"], ["csb04-lab-gw1"], ["blndc01-lab-gw2"], ["blndc01-lab-gw1"], ["rtp5-dmzvlab-gw1"], ["ann01-lab-gw1"], ["shnidc-cp-pxtr1-gw2"], ["mrd01-lab-gw2"], ["mrd01-lab-gw1"], ["mim1-lab-gw1"], ["shnidc-cp-pxtr1-gw1"], ["esp02-lab-gw1"], ["prg7-lab-gw2"], ["prg7-lab-gw1"], ["alp03-lab-gw2"], ["rtp10-cd-dmzvlab-gw1"], ["sngidc-cp-pxtr1-gw2"], ["rtp1-mda1-cp-mgre1-gw1"], ["alp03-lab-gw1"], ["cgn03-lab-gw2"], ["wdf02-lab-gw1"], ["cgn03-lab-gw1"], ["rtp10-cd-dmzaas-gw1"], ["chn09-lab-gw2"], ["chn09-lab-gw1"], ["chg12-lab-gw2"], ["chg12-cibb-gw1"], ["chg12-cibb-gw2"], ["chg12-lab-gw1"], ["tul04-lab-gw2"], ["tul04-lab-gw1"], ["sjc05-cp-mgre1-gw1"], ["hcl7-in-lab-gw1"], ["hcl7-in-lab-gw2"], ["sngidc-cp-pxtr1-gw1"], ["hbg-lab-gw1"], ["rtp5-cibb-gw1"], ["trn6-lab-gw1"], ["trn6-lab-gw2"], ["rtp7-lab-gw1"], ["ful01-lab-gw2"], ["ful01-lab-gw1"], ["wshdc02-lab-gw1"], ["rtp3-lab-gw1"], ["rtp10-00-lab-gw2"], ["rtp9-lab-gw1"], ["rtp4-00-lab-gw2"], ["rtp2-lab-gw1"], ["sla01-lab-gw2"], ["rtp1-lab-gw1"], ["rtp12-00-lab-gw2"], ["rtp1-lab-gw2"], ["rtp12-00-lab-gw1"], ["rtp6-lab-gw2"], ["sla01-lab-gw1"], ["rtp6-lab-gw1"], ["rtp9-lab-gw2"], ["rtp11-lab-gw1"], ["sykes2-cr-lab-gw1"], ["req02-lab-gw1"], ["sol2-lab-gw1"], ["sea1-lab-gw1"], ["rtp5-lab-gw1"], ["rtp11-lab-gw2"], ["rtp1-mda1-cp-pxtr1-gw1"], ["rtp7-lab-gw2"], ["rtp8-lab-gw2"], ["embsys2-in-lab-gw2"], ["embsys2-in-lab-gw1"], ["sngidc-dmzvlab-gw1"], ["sngidc-dmzvlab-gw2"], ["pen3-lab-gw1"], ["pen3-lab-gw2"], ["jkt05-lab-gw2"], ["jkt05-lab-gw1"], ["rtp1-dmzvaas-gw1"], ["rtp7-dmzvaas-gw1"], ["ful01-fw1"], ["rtp5-dmzlab-gw1"], ["rtp8-lab-gw1"], ["req01-lab-gw1"], ["rtp1-dmzlab-gw1"], ["rtp11-dmzlab-gw1"], ["csv-lab-gw1"], ["atl11-lab-gw2"], ["atl11-lab-gw1"], ["ors03-lab-gw2"], ["cwy01-lab-gw1"], ["ors03-lab-gw1"], ["cwy01-lab-gw2"], ["gai03-lab-gw2"], ["bel01-lab-gw2"], ["bel01-lab-gw1"], ["aar02-lab-gw1"], ["bln2-lab-gw2"], ["gai03-lab-gw1"], ["bln2-lab-gw1"], ["tyoidc5-cp-pxtr1-gw1"], ["twl03-lab-gw1"], ["mil01-lab-gw1"], ["mil01-lab-gw2"], ["schp01-lab-gw1"], ["bgl16-00-lab-gw1"], ["argrp4-in-lab-gw1"], ["wpr2-in-lab-gw1"], ["bgl16-00-lab-gw2"], ["argrp4-in-lab-gw2"], ["bgl17-cp-mgre1-gw1"], ["argrp1-in-lab-gw1"], ["mtc2-in-lab-gw1"], ["bgl13-lab-gw2"], ["bgl13-cp-pxtr1-gw1"], ["bgl13-cibb-gw1"], ["bgl17-cp-pxtr1-gw1"], ["bgl13-lab-gw1"], ["bgl17-cibb-gw1"], ["pnq05-lab-gw2"], ["pnq05-lab-gw1"], ["hcl14-in-lab-gw1"], ["hcl14-in-lab-gw2"], ["bgl18-00-lab-gw1"], ["cmb03-lab-gw1"], ["infy9-in-lab-gw1"], ["bgl13-cp-mgre1-gw1"], ["bgl14-00-lab-gw1"], ["bgl18-00-lab-gw2"], ["bgl14-00-lab-gw2"], ["chn08-lab-gw1"], ["ggn01-lab-gw1"], ["ggn01-lab-gw2"], ["bgl26-lab-gw1"], ["shn15-lab-gw1"], ["argrp5-in-lab-gw1"], ["bgl17-00-lab-gw1"], ["bgl17-00-lab-gw2"], ["wpr8-in-lab-gw1"], ["hcl19-in-lab-gw2"], ["hcl19-in-lab-gw1"], ["bgl11-00-lab-gw2"], ["bgl11-00-lab-gw1"], ["bgl12-00-lab-gw1"], ["mmb12-lab-gw1"], ["mmb12-lab-gw2"], ["bgl12-00-lab-gw2"], ["kul02-lab-gw1"], ["bgl15-00-lab-gw1"], ["bgl15-00-lab-gw2"], ["hcl17-in-lab-gw1"], ["hcl17-in-lab-gw2"], ["bng02-lab-gw1"], ["hgh06-ext-lab-gw2"], ["hgh06-ext-lab-gw1"], ["sngdc01-mda2-cibb-gw2"], ["sngdc01-mda1-cibb-gw1"], ["akl02-lab-gw1"], ["mel03-lab-gw1"], ["tky7-lab-gw1"], ["hgh05-lab-gw1"], ["shn4-cibb-gw1"], ["shn15-lab-gw2"], ["shn6-lab-gw1"], ["shn7-lab-gw2"], ["tky7-lab-gw2"], ["ngo1-lab-gw1"], ["sng15-lab-gw1"], ["shn7-lab-gw1"], ["shn4-lab-gw2"], ["shn4-cibb-gw2"], ["shn4-lab-gw1"], ["sng15-lab-gw2"], ["prt3-lab-gw1"], ["nsd5-lab-gw2"], ["nsd5-lab-gw1"], ["cbr04-lab-gw1"], ["foxc1-cn-lab-gw1"], ["gng03-lab-gw1"], ["hfe02-lab-gw1"], ["hfe02-lab-gw2"], ["tky7-cibb-gw2"], ["tky7-cibb-gw1"], ["stld1-lab-gw2"], ["stld1-lab-gw1"], ["szn04-lab-gw1"], ["szn05-lab-gw1"], ["wln2-lab-gw1"], ["hni05-lab-gw1"], ["dlc02-lab-gw1"], ["dlc02-lab-gw2"], ["fka1-lab-gw1"], ["osk04-lab-gw1"], ["brb05-lab-gw1"], ["sngdc01-mda2-dmzaas-gw2"], ["sngdc01-mda1-dmzaas-gw1"], ["mnl02-lab-gw1"], ["shn17-lab-gw1"], ["shn17-lab-gw2"], ["svta01-lab-gw1"], ["yer03-lab-gw1"], ["sjc23-lab-gw2"], ["sjc21-lab-gw1"], ["sjc20-cibb5-gw1"], ["sjc20-lab-gw1"], ["sjcp-lab-gw2"], ["sjc23-lab-gw1"], ["sjc24-lab-gw1"], ["sjc21-lab-gw2"], ["sjc24-lab-gw2"], ["sjc20-lab-gw2"], ["sjcp-lab-gw1"], ["bvw01-lab-gw1"], ["sea1-lab-gw2"], ["vnc2-lab-gw1"], ["sjc5-cibbfo-sw2"], ["sjc5-cibbfo-sw1"], ["sjc5-cibb-wan-gw1"], ["sjc5-cibb-fw1"], ["wlt06-lab-gw2"], ["sjc12-dmzvaas-gw1"], ["sjc05-dmzvaas-gw1"], ["blv-lab-gw1"], ["wlt06-lab-gw1"], ["sjc5-cibb-fw1-ironport"], ["sjc12-cibb4-gw1"], ["sjc5-cibb-wan-gw2"], ["sjc12-lab-gw1"], ["sjc12-cp-pxtr1-gw1"], ["sfo12-cibb-gw1"], ["sjc5-cibb4-gw1"], ["sjc05-cp-pxtr1-gw1"], ["sjc02-lab-gw1"], ["sjc14-lab-gw1"], ["sjc16-lab-gw1"], ["sjc11-lab-gw1"], ["sjc08-lab-gw1"], ["sjc03-lab-gw1"], ["sjc01-lab-gw1"], ["sjc5-cibb4-gw2"], ["sjc15-lab-gw2"], ["sjc09-lab-gw1"], ["sjc07-lab-gw1"], ["sjc17-lab-gw1"], ["sjc13-lab-gw1"], ["sjc06-lab-gw2"], ["sjc04-lab-gw1"], ["sjc15-lab-gw1"], ["sjc19-lab-gw1"], ["sjc10-lab-gw1"], ["sjc04-lab-gw2"], ["sjc16-lab-gw2"], ["sjc14-lab-gw2"], ["sjc03-lab-gw2"], ["sjc13-lab-gw2"], ["sjc05-lab-gw2"], ["sjc06-lab-gw1"], ["sjc02-lab-gw2"], ["sjc01-lab-gw2"], ["sjc05-lab-gw1"], ["sjc09-lab-gw2"], ["sjc12-cibb4-gw2"], ["sjc10-lab-gw2"], ["sjc19-lab-gw2"], ["sjc08-lab-gw2"], ["sjc12-lab-gw2"], ["sjc07-lab-gw2"], ["sjc17-lab-gw2"], ["csb03-lab-gw1"], ["syc02-lab-gw1"], ["cosm02-lab-gw1"], ["sprg01-lab-gw2"], ["irv8-lab-gw1"], ["csb03-lab-gw2"], ["lux1-lab-gw1"], ["rtp5-lab-gw2"], ["rtp4-00-lab-gw1"], ["bgl17-dmzvlab-gw1"], ["bgl13-dmzaas-gw1"], ["bgl17-dmzaas-gw1"], ["bgl25-lab-gw1"], ["rcdn6-cibb-gw1"], ["sprg01-lab-gw1"], ["sjc23-cibb5-gw1"], ["par03-lab-gw2"], ["par03-lab-gw1"], ["bdlk11-cibb-gw1"], ["bdlk09-00-lab-gw1"], ["bdlk10-31-lab-gw1"], ["bdlk09-12-lab-gw1"], ["bdlk09-cibb-gw1"], ["bdlk10-00-lab-gw1"], ["bdlk09-00-lab-gw2"], ["bdlk11-00-lab-gw2"], ["bdlk11-00-lab-gw1"], ["rtp10-00-lab-gw1"], ["rtp5-dmzaas-gw1"], ["lon06-cibb-gw1"], ["els01-cibb-gw1"], ["mtv5-mda2-cibb-gw2"], ["sjc05-dmzvlab-gw1"], ["sjc5-cibb-fw2-ironport"], ["sjc5-cibb-fw2"], ["rtp1-mda2-cibb-fw2"], ["rtp1-mda2-cibb-fw2-ironport"], ["rtp1-mda2-cibb-fw2-latisys"]]
            # gws = get_lab_gateway_as_list()
            DB.init_db()
            job_id = [DB.get_job_id(Script_Type.PIA, Script_State.STARTED)]
            print("JOB ID: {}".format(job_id[0]))
            
            gw_dc_list = DB.get_input_lab_gw_with_dc(Script_Type.PIA)
            DB.close_db_conn()

            gws = []
            for i in gw_dc_list:
                gw_name = i[0]
                dc_name = i[1]

                gws.append(gw_name)

                if (dc_name != None):
                    gw_dc_map[gw_name] = dc_name
            print("GW-DC mapping count: ", len(gw_dc_map))

            #gws = ["bgl11-00-lab-gw1", "bgl12-00-lab-gw1", "bgl12-00-lab-gw2", 
             #      "sjc19-lab-gw1", "sjc19-lab-gw2", "sjc14-lab-gw1", "sjc14-lab-gw2"]
            # gws= ["aer01-mda1-lab-gw1"]
            # gws = ["bgl12-00-lab-gw2", "bgl11-00-lab-gw1", "bgl16-00-lab-gw1", "ntn01-lab-gw1"]            
            
            # gws = [gws[0]]
            # print("\nCount : Total source GW :  " + str(len(gws)))
            
            nslookup_res = NetWork_Util.get_ip_address_by_nslookup(gws)
            gw_with_ip = nslookup_res[0]
            nslookup_failed_gw = nslookup_res[1]
            gw_nslookup_error = len(nslookup_failed_gw)
            gw_error_count += gw_nslookup_error

            for row in nslookup_failed_gw: 
                host_with_ip_status.append(row)

            # gw_with_ip =  [["ann01-lab-gw1", None]]
            # for i in gw_with_ip: print(i)            
            # print "\nTOTAL GW:  " + str(len(gw_with_ip))

            # if current source doesn't have IP adress, then have to run get_ip_address_by_nslookup(gws)
            # if (gw_with_ip[0][1] == None):
            #    gw_with_ip = get_ip_address_by_nslookup(gw_with_ip)
            
            no_of_worker = 10 if len(gw_with_ip) >= 10 else len(gw_with_ip)
            print("Count : Thread : {}".format(no_of_worker))

            print("\nProcess : Starting thread process...\n")
            print("\n{:<5}  {:<16}  {:<30}  {:<12}  {:<12}  {}".format('Count', 'Ip', 'Host', 'Host_Matched', "Data_Count",'Status') + "\n")
            with ThreadPoolExecutor(max_workers = no_of_worker) as executor:
                index = 0
                for gw_name, gw_ip in gw_with_ip:
                    # print("{} {}".format(gw_name, gw_ip))
                    # if gw_name in {'sjc18-lab-gw2', 'sjc18-lab-gw1', 'sjc05-dmzvaas-gw1', 'sjc12-dmzvaas-gw1'}:
                    #     executor.submit(get_DeviceStatus, gw_name.strip(), gw_ip.strip())
                    executor.submit(get_DeviceStatus, gw_name.strip(), gw_ip.strip())

                    """
                    if (index == 0):
                       break
                    index += 1
                    """
            
            print("Excel : Creating records...")
            # create_excel_file()
            create_excel_with_sheet()
            # create_final_excel()            

            # initiating database connection
            DB.init_db()

            # STEP 1: Move old data
            # Move data from main to history
            DB.execudbproc_main_to_history()  # newly added
            # DB.move_data_from_main_to_history(DB_TABLE.PIA_MASTER_DATE, DB_TABLE.PIA_MASTER_DATE_HISTORY, job_id[0])
            # DB.move_data_from_main_to_history(DB_TABLE.ANOMALY, DB_TABLE.ANOMALY_HISTORY, job_id[0])
            # DB.move_data_from_main_to_history(DB_TABLE.ANOMALY_CLEAN_DATA, DB_TABLE.ANOMALY_CLEAN_DATA_HISTORY, job_id[0])
            print()
            
            # STEP 2: Clean
            # Cleaing process
            DB.truncate_table(DB_TABLE.PIA_MASTER_DATE)
            DB.truncate_table(DB_TABLE.ANOMALY)
            DB.truncate_table(DB_TABLE.ANOMALY_CLEAN_DATA)
            DB.truncate_table(DB_TABLE.PIA_MASTER_DATE_TEMP)
            print()

            # STEP 3: Insert
            # Master data
            DB.insert_pia_master_report(datas, job_id[0])
            # convert Te -TenGigabitEthernet | Gi-GigabitEthernet
            DB.execudbproc_main()
            # Anomaly 1
            DB.insert_anomaly(Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB, same_subnet_multi_lab_list, job_id[0])
            # Anomaly 2
            DB.insert_anomaly(Anomaly_Type.WITH_OUT_NEXTHOP, None, job_id[0])
            # Anomaly 3css
            DB.insert_anomaly(Anomaly_Type.NO_VRF, None, job_id[0])
            # Source for PIA Overlapping Subnet
            DB.insert_pia_subnet_with_lab_list(subnet_with_lab_list, job_id[0])
            # Anomaly 4
            DB.insert_anomaly(Anomaly_Type.PIA_OVERLAPPING_SUBNET, None, job_id[0])
            # Anomaly 5
            DB.insert_anomaly(Anomaly_Type.DMZ_TEMPLATE_ACL, dmz_acl_template, job_id[0])
            # clean Data
            # DB.insert_clean_data_table(job_id[0], DB_TABLE.PIA_MASTER_DATE, DB_TABLE.ANOMALY_CLEAN_DATA)
            # Gateway Status
            DB.insert_gw_process_status(Script_Type.PIA, host_with_ip_status, job_id[0])
            # print()
            DB.close_db_conn()

            print(get_gw_status_massage())

            # Anomaly 6
            try:
                pia_inacl_anomaly_with_gw.start_inacl_process(job_id[0])
            except pia_inacl_anomaly_with_gw.PIA_InACL_Anomaly_Exception as e:
                error_message = str(e)
 
            print("Data : Now, have Master data and Six Anomaly datas")
            DB.init_db()
            # STEP 4: Update tag column
            # Update Data_state, Lab_state and Lab_sub_type
            DB.update_tag_col(Row_Tag.CLEAN_AND_NOT_CLEAN, job_id[0], DB_TABLE.PIA_MASTER_DATE)
            DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.PIA_MASTER_DATE)
            DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.NO_VRF)
            DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.DMZ_TEMPLATE_ACL)
            DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.ALL)
            DB.update_tag_col(Row_Tag.LAB_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET)
            
            # Step 5: Delete Unnecessary rows from NO_VRF and GLOBALOUT
            DB.delete_from_anomaly(Anomaly_Type.NO_VRF,
                                         job_id[0],
                                         Delete_Data_criteria_list.No_VRF_criteria_list.value)
            DB.delete_from_anomaly(Anomaly_Type.PIA_OVERLAPPING_SUBNET,
                                        job_id[0] )
            DB.delete_from_anomaly(Anomaly_Type.GLOBALOUT,
                                         job_id[0],
                                         Delete_Data_criteria_list.GLOBALOUT_criteria_list.value)

            DB.execudbproc()
            DB.execudbproc_main_temp()
            DB.segregate_subnet(job_id[0])
            print()

            # STEP 6: Delete invalid data
            # Delete data from datable where LAB_STATE and LAB_TYPE is empty
            # DB.delete_row_by_lab_tags(DB_TABLE.PIA_MASTER_DATE, job_id[0])
            # DB.delete_row_by_lab_tags(DB_TABLE.ANOMALY, job_id[0])
            # print()

            # Update the Job Status
            DB.update_job_status(Script_Type.PIA, Script_State.DONE, job_id[0])

            # update_script_today_status()
            DB.close_db_conn()
            
            if (is_reach_max_execution):
                print("Script: is_reach_max_execution: " + str(is_reach_max_execution))
                
        else:
            print("Script Status: Already reached maximum execution")
        
        # close_resource(cursor)
        # close_resource(connection)

        vrf_offramp_with_pxtr.start_process(job_id[0])
        data_creation.create_final_excel_with_master_and_anomaly(job_id[0])

    except NetWork_Util_Exception as ex:
        got_error = True
        error_message = ex.message
    except Util_Exception as ex:
        got_error = True
        error_message = ex.message
    except Gateway_Util_Exception as ex:
        got_error = True
        error_message = ex.message
    except DB_Exception as ex:
        got_error = True
        error_message = ex.message
    except PIA_Exception as ex:
        got_error = True
        error_message = ex.message
        # print("Main Excetion:\n", str(ex))
    except:
        ex = traceback.format_exc()
        got_error = True
        error_message = ''
        for i in ex.split("\n"):
            error_message = error_message + i + "\n"
        # print("Main: Excetion:\n {}".format(str(ex)))
    finally:
        
        if (got_error):
            DB.init_db()
            DB.update_job_status(Script_Type.PIA, Script_State.ERROR, job_id[0])
            DB.close_db_conn()

            print(error_message)

        # Gateway_Util.send_mail_from_server_cmd("noreply@cisco.com", ["aagnel@cisco.com"], "PIA Script finished", "master.log")
        # pia_inacl_anomaly_with_gw.start_inacl_process()

def get_gw_status_massage():
    global current_exec_count, gw_done_count, gw_error_count, gw_unreachable_count, gw_conn_time_out_count, gw_not_connected_count, gw_unknown_error_count, gw_auth_failed_count, is_excel_file_created
    global lab_id_from_mapping_matched_count, lab_id_from_mapping_count, gw_invoke_shell_error_count, gw_nslookup_error
    
    subject = "Lab GWs Report Done"
    message = str( "\n\n-----------------------PIA Main Script Device Status-----------------------"
    + "<br>Current Execution Count : " + str(current_exec_count + 1)
    + "<br>Total output count : " + str(len(datas))
    + "<br>Excel File : " + str("Created" if is_excel_file_created else "<b style='font-size:20px;color:red;'>Not created</b>")
    + "<br><br>Gw done : " + str(gw_done_count) 
    + "<br>Gw error : " + str(gw_error_count)
    + "<br><br>Gw IP not found by nslookup count : " + str(gw_nslookup_error)
    + "<br>Gw Unreachable : " + str(gw_unreachable_count)
    + "<br>Gw connection timed out: " + str(gw_conn_time_out_count)
    + "<br>Gw not connected : " + str(gw_not_connected_count)
    + "<br>Gw interactive shell error : " + str(gw_invoke_shell_error_count)
    + "<br>Gw Unknown error : " + str(gw_unknown_error_count)
    + "<br>Gw authentication failed : " + str(gw_auth_failed_count)
    + "<br><br>No_status for GW : " + str("<b style='font-size:20px;color:red;'>Yes</b>" if is_no_status_for_gw else "No")
    + "<br><br>Incorrect Lab ID count : " + str(len(incorrect_lab_id_with_details))
    + "<br><br>Lab Id mapping count : " + str(lab_id_from_mapping_count)
    + "<br>Lab Id mapping matched count : " + str(lab_id_from_mapping_matched_count))
            
    if len(host_not_matched_list):
        message = message + str("<br><br><b style='font-size:20px;color:red;'>Host not matched with IP:</b><br>"
        + "Count: " + str(len(host_not_matched_list))
        + "<br>List:<br>")
        message = message + """<table>
                            <thead>
                                <th>Ip_Address</th>
                                <th>&nbsp&nbsp&nbsp Host_Name</th>
                                <th>&nbsp&nbsp&nbsp Host_Name_from_response</th>                                     
                            </thead>"""
        for i in host_not_matched_list:                
            message = message + "<tr><td>"+i[0]+"</td> <td>&nbsp&nbsp&nbsp&nbsp"+i[1]+"</td> <td>&nbsp&nbsp&nbsp&nbsp"+i[2]+"</td></tr>"
        message = message + "</table>"

    return print(message.replace("<br>", "\n").replace("&nbsp", " "))
    
"""
def nslookup(gw, gw_with_ip):
    global gw_nslookup_error

    p = subprocess.Popen('nslookup ' + gw, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    isIpAddressLine = False
    ip_addresses = []
    for line in p.stdout.readlines():
        line = line.decode()

        if ("can't find" in line):
            print"{:<30}    {}".format(gw, "Can not find IP Address by nslookup")
            failed_host_with_ip_status.append(["", gw, "Can not find IP Address by nslookup"])
            gw_nslookup_error = gw_nslookup_error + 1
            return

        if (isIpAddressLine and 'Name' not in line and line.strip() != ''):
            ip_addresses.append(line.replace("Address:", "").replace("Addresses:", "").strip())
            # gws_ip.append[gw, line.replace("Address:", "").replace("Addresses:", "").strip()]
            # break

        if ("Name" in line and gw in line and "can't find" not in line):
            isIpAddressLine = True
            
    print "{:<30}    {}".format(gw, ip_addresses)
    # currently tacking IPv4 address
    got_ipv4 = False
    for ip in ip_addresses:        
        try:            
            socket.inet_aton(ip)
            gw_with_ip.append([gw, str(ip)]) # ['host_name',IPv4]
            got_ipv4 = True
        except socket.error:
            if (len(ip_addresses) == 1):
                print "not IPv4: " + gw +", "+ ip
                try:
                    socket.inet_pton(socket.AF_INET6, ip)
                    gw_with_ip.append([gw, ip]) # ['host_name', 'ipv6' ,IPv6]
                except socket.error as e:
                    print "Ip error: ", e

    if (got_ipv4 == False):
        print "no ipv4 found. used IPv6  ==> {:<30}    {}".format(gw, ip_addresses)
    
def get_ip_address_by_nslookup(gws):    
    avoid_gw = "rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1, rtp1-mda2-cibb-fw1-ironport, ful01-fw1, sjc5-cibb-fw1, sjc5-cibb-fw1-ironport, sjc5-cibb-fw2-ironport, sjc5-cibb-fw2, rtp1-mda2-cibb-fw2-ironport, rtp1-mda2-cibb-fw2, rtp1-mda2-cibb-fw2-latisys"
    
    gws_ip = []
    print("{:<30}    {}".format('Gateway', 'Ip'))
    with ThreadPoolExecutor(max_workers=30) as executor:    
        for gw in gws:
            if (gw[0].strip() not in avoid_gw):
                executor.submit(nslookup, gw[0].strip(), gws_ip)
            
    print "\ntotal gws_ip by nslookup = ", len(gws_ip), "\n"
    for i in gws_ip:
        print(i)
    return gws_ip
"""

def ping(gw):
    global pinged, not_pinged    

    print(gw)
    # p = subprocess.Popen('nslookup ' + gw, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    p = subprocess.Popen('ping ' + gw, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    res = ""
    for line in p.stdout.readlines():
        line = line.decode()
        res = res + line

    if ("Request timed out" in res):
        not_pinged.append(gw)
    else:
        pinged.append(gw)

def check_ping_thread():
    global pinged, not_pinged

    init_db()
    gws = get_input_gw(0)
    print("total gws = ", len(gws))

    with ThreadPoolExecutor(max_workers=30) as executor:
        for gw in gws:
            executor.submit(ping, gw[0])

    print("\npinged")
    print("ping: ", len(pinged))
    print(pinged)

    print()

    print("not pinged")
    print("not ping: ", len(not_pinged))
    print(not_pinged)

def ssh_connection_check(host_name, ip, run_by_ip):
    global gw_done_count, gw_error_count, gw_finished_count, host_name_matched_count
    status_msg = 'No Status'
    host_matched = '--'
    found_host_name = '--'
    try:
        print()
        print("{:<5}  {:<16}  {:<25}  {:<12}  {:<25}  {}".format("----", ip, host_name, "-", "-", "started"))
        ssh = None
        if (run_by_ip):
            ssh = get_paramiko_client(ip)
        else:
            ssh = get_paramiko_client(host_name)
        chan = ssh.invoke_shell()
        res = get_SSHResp(chan, "").split("\n")
        for line in res:
            if ("#" in line):
                if (host_name.strip() == line.replace("#", "").strip()):
                    host_matched = True
                else:
                    found_host_name = line.replace("#", "").strip()                    
                    host_name_matched_count = host_name_matched_count + 1
                break

        gw_done_count = gw_done_count + 1        
        status_msg = "done"
        close_resource(ssh)
    except Exception as e:
        status_msg = str(e.message)     
        gw_error_count = gw_error_count + 1 
    finally:
        gw_finished_count = gw_finished_count + 1
        print()
        print("{:<5}  {:<16}  {:<25}  {:<12}  {:<25}  {}".format(gw_finished_count, ip, host_name, str(host_matched), found_host_name, status_msg))
    
def check_ssh_thread():
    global current_exec_count, gw_done_count, gw_error_count, gw_unreachable_count, gw_conn_time_out_count, gw_not_connected_count, gw_unknown_error_count, gw_auth_failed_count, host_name_matched_count    

    # init_db()
    # gw_with_ip = get_input_gw(0)
    gw_with_ip = [["aar02-lab-gw1", "10.228.217.195"]]
    print("total gws = ", len(gw_with_ip))
            
    # if current source doesn't have IP adress, so hav to run get_ip_address_by_nslookup(gws)
    if (gw_with_ip[0][1] == None):
        # gw_with_ip = get_ip_address_by_nslookup(gw_with_ip)
        pass
    
    print("GW Conunt: ", len(gw_with_ip))
    print("{:<5}  {:<16}  {:<25}  {:<12}  {:<25}  {}".format('Count', 'Ip', 'Host', 'Host_Matched', 'Valid_Host', 'Status'))

    with ThreadPoolExecutor(max_workers=10) as executor:    
        for gw in gw_with_ip:
            executor.submit(ssh_connection_check, gw[0], gw[1], True)

    print(str(
        "\n\nGw done : " + str(gw_done_count) 
        + "\nGw error : " + str(gw_error_count)
        + "\n\nGw Unreachable : " + str(gw_unreachable_count)
        + "<br>Gw connection timed out: " + str(gw_conn_time_out_count)
        + "\nGw not connected : " + str(gw_not_connected_count)
        + "\nGw Unknown error : " + str(gw_unknown_error_count)
        + "\nGw authentication failed : " + str(gw_auth_failed_count)
        + "\n\nGw name not matched count : " + str(host_name_matched_count)
    )) 

def zip_and_mail():
    try:
        today = date.today()
        today = str(today.strftime("%d-%m-%Y"))
        
        print(os.getcwd())
        os.system("zip pia-"+today+".zip *.csv")
        Util.send_mail_from_server_cmd("noreply@cisco.com", ["shoraj@cisco.com"], "Lab High Rish script finished", "master.log", "pia-"+today+".zip")
    except Exception as e:
        print("zip_and_mail() got error")
        print(e)
        Util.send_mail_from_server_cmd("noreply@cisco.com", ["shoraj@cisco.com"], "Lab High Rish script finished", "master.log")
def decrypt_password(username):
    try:
        KEY=b'oXoOlhKRstOqDxWDiUK1Fax0Kslk5EXb3cXM7Hscgfc='#Fernet.generate_key()
        cipher = Fernet(KEY)
        encrypted_password=retrieve_password_from_db(username)
        return cipher.decrypt(encrypted_password).decode('utf-8')

    except Exception as e:
        traceback.print_exc()
        print(f"no password retrieved from the database: {e}")

def retrieve_password_from_db(username):
    try:
        dsn = cx_Oracle.makedsn("dbs-nprd2-vm-013.cisco.com", 1535, service_name="ESMDBSTG.cisco.com")
        connection = cx_Oracle.connect(user="ESMSCSTG", password='Cisco_123', dsn=dsn, encoding="UTF-8")
        connection.autocommit = True
        cursor = connection.cursor()

        cursor.execute(f"SELECT ENCRYPTED_PASSWORD FROM  {DB_TABLE.PIA_PASSWORD_DB.value} WHERE USER_NAME = :username",
                        {'username': username})

        encrypted_password = cursor.fetchone()[0]

        cursor.close()
        connection.close()
        return encrypted_password
    except Exception as e:
        traceback.print_exc()
        print(f"Error retrieving password from the database: {e}")
        return None
if __name__ == "__main__":
    print("PIA script started")
    _username = 'morashee.web'

    #_password = decrypt_password(_username)
    # Later, if you need to decrypt the password
    #decrypted_password = decrypt_password(encrypted_password, KEY)
    # print(f"Decrypted Password: {_password}")
    # _username = input("username: ")
    # _password = getpass.getpass("password: ")

    #
    # To check ping status
    # check_ping_thread()

    #
    # To check accessiable GWs
    # check_ssh_thread()

    #
    # to run single GW
    # get_DeviceStatus('ann01-lab-gw1', '10.151.59.37')

    #
    # To get the ip address
    # print(get_ip_address_by_nslookup(get_input_gw(0)))

    #
    # start from main method for list of GWs
    # today = get_script_date_time()
    print("Date : " + today)
    # if (today != ""):


    process()
    """job_id=[192]
    print("Data : Now, have Master data and Six Anomaly datas")            
    DB.init_db()
    # STEP 4: Update tag column
    # Update Data_state, Lab_state and Lab_sub_type
    DB.update_tag_col(Row_Tag.CLEAN_AND_NOT_CLEAN, job_id[0], DB_TABLE.PIA_MASTER_DATE)
    DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.PIA_MASTER_DATE)
    DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.NO_VRF)
    DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.DMZ_TEMPLATE_ACL)            
    DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.ALL)
    DB.update_tag_col(Row_Tag.LAB_SUB_TYPE, job_id[0], DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET)
    
    DB.execudbproc()
    print()                                    

    # STEP 5: Delete invalid data
    # Delete data from datable where LAB_STATE and LAB_TYPE is empty
    # DB.delete_row_by_lab_tags(DB_TABLE.PIA_MASTER_DATE, job_id[0])
    # DB.delete_row_by_lab_tags(DB_TABLE.ANOMALY, job_id[0])            
    # print()

    # Update the Job Status
    
    # update_script_today_status()            
    DB.close_db_conn()
        
    data_creation.create_final_excel_with_master_and_anomaly(job_id[0])
    """

    # DB.init_db()
    # gws = DB.get_input_lab_gw()
    # print(gws)

    # check_ssh_thread()

    # zip_and_mail()

    print("PIA script finished")

