from cryptography.fernet import Fernet
import cx_Oracle
import traceback
import getpass
KEY=b'oXoOlhKRstOqDxWDiUK1Fax0Kslk5EXb3cXM7Hscgfc='#Fernet.generate_key()
def encrypt_password(password, KEY):
    cipher = Fernet(KEY)
    encrypted_password = cipher.encrypt(password.encode('utf-8'))
    print(password)
    print(encrypted_password)
    return encrypted_password

def store_password_in_db(username, encrypted_password):
    try:
        print(f"Username: {username}")
        #print(f"Encrypted Password: {encrypted_password}")
        dsn = cx_Oracle.makedsn("dbs-nprd2-vm-013.cisco.com", 1535, service_name="ESMDBSTG.cisco.com")
        connection = cx_Oracle.connect(user="ESMSCSTG", password='Cisco_123', dsn=dsn, encoding="UTF-8")
        connection.autocommit = True
        cursor = connection.cursor()
        print("DB :  Connected")

        # Check if the user already exists in the database
        cursor.execute(
            "SELECT COUNT(*) FROM PASSWORD_STORAGE WHERE USER_NAME = :username",
            {'username': username})

        user_count = cursor.fetchone()[0]

        if user_count > 0:
            # User already exists, update the existing record
            cursor.execute(
                "UPDATE PASSWORD_STORAGE SET ENCRYPTED_PASSWORD = :encrypted_password WHERE USER_NAME = :username",
                {'username': username, 'encrypted_password': encrypted_password})
            print(f"Updated encrypted password for user {username}")
        else:
            # User doesn't exist, insert a new record
            cursor.execute(
                "INSERT INTO PASSWORD_STORAGE (USER_ID, USER_NAME, ENCRYPTED_PASSWORD) VALUES (USER_ID_SEQ.NEXTVAL, :username, :encrypted_password)",
                {'username': username, 'encrypted_password': encrypted_password})
            print(f"Inserted new encrypted password for user {username}")

        connection.commit()

        cursor.close()
        connection.close()
        print("DB: Disconnected")
    except Exception as e:
        traceback.print_exc()
        print(f"Error during database operation: {e}")
        print(f"Failed to store encrypted password for user {username}")



if __name__ == "__main__":
    _username = 'morashee.web'
    _password = '%Tgb0okm9ijn'

    encrypted_password = encrypt_password(_password, KEY).decode('utf-8')

    # Store the username and encrypted password in the database
    store_password_in_db(_username, encrypted_password)

