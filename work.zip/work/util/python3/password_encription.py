"""
'''
    This process is to Encrypt the password
'''
from cryptography.fernet import Fernet

# Generate an encryption key (this should be kept secret)
encryption_key = Fernet.generate_key()
print(encryption_key)

# Initialize the Fernet symmetric encryption object
cipher_suite = Fernet(encryption_key)

# Encrypt the password and store it securely (e.g., in your code)
password = "$Rfv0okm9i"
userid = "morashee.web"
encrypted_password = cipher_suite.encrypt(password.encode())
encrypted_userId = cipher_suite.encrypt(userid.encode())
print(encrypted_password)
print(encrypted_userId)

# Later, when you need to use the password, decrypt it
decrypted_password = cipher_suite.decrypt(encrypted_password).decode()
decrypted_userId = cipher_suite.decrypt(encrypted_userId).decode()

print(f"Decrypted Password: {decrypted_password}")
print(f"Decrypted UserId: {decrypted_userId}")
'----------------------------------------------------------------------------------------------------------------------'
"""
'''
    This process is to Decrypt the password
'''
from cryptography.fernet import Fernet

# This is your encryption key in bytes, not wrapped in single quotes
encryption_key = b'7zwveYBLhPN2A3RT5DUiNPJ0Hn4nKiZXp4ULNZeCqts='

# This is your encrypted password in bytes, not wrapped in single quotes
encrypted_password = b'gAAAAABlO6cvD0FunRBF9nVHabyTxxR2FAG94By9MlYoqg6FgVq4rJ7vBF3E28tJTMJ2EUKl4Frpx3PkjqiZ9khYfByH3WwcfA=='
encrypted_userId =  b'gAAAAABlO6cv60t-V2zs20HX7kPwY_wnKCQBcp67jf18K27yj7oGx-3qhPfXSo2HjaXIyQ9qd3apdQg8RyexvA0tmaDHAFafnw=='

cipher_suite = Fernet(encryption_key)

decrypted_password = cipher_suite.decrypt(encrypted_password).decode()
decrypted_userId = cipher_suite.decrypt(encrypted_userId).decode()

print(f"Decrypted Password: {decrypted_password}")
print(f"Decrypted UserId: {decrypted_userId}")
