import sys
import os
import platform
parent_directory_path = os.path.dirname(os.getcwd())
sys.path.append(parent_directory_path)

if (platform.system() != 'Windows'):
    util_package = parent_directory_path + "/util/python3"
else:
    util_package = parent_directory_path + "\\util\python3"

sys.path.append(util_package)

import pandas as pd
from datetime import datetime

from util.python3.util import Util
from util.python3.database_util import DB
from util.python3.database_util import DB_TABLE
from util.python3.database_util import Script_Type
from util.python3.database_util import Anomaly_Type

def create_final_excel_with_master_and_anomaly(job_id: int):
    print(f"Excel : Job ID = {job_id} | Creating excel from DB with Tag columns")

    """newly added"""
    # Get the current date and time
    current_datetime = datetime.now()
    formatted_datetime = str(current_datetime.strftime("%m-%d-%y"))

    try:
        # writer = Util.create_new_excel_writer_obj("SAMPLE_PIA")
        writer = pd.ExcelWriter(f"output/PIA_Master_With_Anomaly-{formatted_datetime}.xlsx",  mode="w", engine='xlsxwriter')
        DB.init_db()

        master_data = DB.get_data_from_db(DB_TABLE.PIA_MASTER_DATE_TEMP, job_id)
        Util.create_excel_sheet(writer, "PIA_MASTER_DATA", DB.MASTER_DATE_COLUMNS_WITH_TAG, master_data)

        no_vrf_anomaly = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.NO_VRF)
        # Util.create_excel_sheet(writer, "NO_VRF_ANOMALY", DB.NO_VRF_COLUMNS, no_vrf_anomaly)
        Util.create_excel_sheet(writer, "VRF Config missing", DB.NO_VRF_COLUMNS, no_vrf_anomaly)

        with_out_nexthop = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.WITH_OUT_NEXTHOP)
        # Util.create_excel_sheet(writer, "WITHOUT_NEXTHOP_ANOMALY", DB.WITHOUT_NEXtHOP_COLUMNS, with_out_nexthop)
        Util.create_excel_sheet(writer, "Next Hop Config missing", DB.WITHOUT_NEXtHOP_COLUMNS, with_out_nexthop)

        overlapping = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.PIA_OVERLAPPING_SUBNET)
        # Util.create_excel_sheet(writer, "OVERLAPPING_SUBNET_ANOMALY", DB.OVERLAPPING_COLUMNS, overlapping)
        Util.create_excel_sheet(writer, "Overlapping Subnet", DB.OVERLAPPING_COLUMNS, overlapping)

        same_subnet_mutiple_lab = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB)
        # Util.create_excel_sheet(writer, "SAME_SUBNET_MUTIPLE_LAB_ANOMALY", DB.SAM_SUBNET_MULTIPLE_LAB_COLUMNS, same_subnet_mutiple_lab)
        Util.create_excel_sheet(writer, "Subnets Routed in Multiple Labs", DB.SAM_SUBNET_MULTIPLE_LAB_COLUMNS, same_subnet_mutiple_lab)

        dmz_inacl = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.PIA_DMZ_INACL)
        # Util.create_excel_sheet(writer, "DMZ_INACL_ANOMALY", DB.DMZ_INACL_COLUMNS, dmz_inacl)
        Util.create_excel_sheet(writer, "Covered ACL in DMZ Lab", DB.DMZ_INACL_COLUMNS, dmz_inacl)

        dmz_template_acl = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.DMZ_TEMPLATE_ACL)
        # Util.create_excel_sheet(writer, "DMZ_TEMPLATE_ACL_ANOMALY", DB.DMZ_TEMPLATE_ACL_COLUMNS, dmz_template_acl)
        Util.create_excel_sheet(writer, "DMZ ACL Control", DB.DMZ_TEMPLATE_ACL_COLUMNS, dmz_template_acl)

        vrf_offramp = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.VRF_OFFRAMP)
        # Util.create_excel_sheet(writer, "VRF_OFFRAMP_ANOMALY", DB.VRF_OFFRAMP_COLUMNS, vrf_offramp)
        Util.create_excel_sheet(writer, "Lab-lenient ACL control", DB.VRF_OFFRAMP_COLUMNS, vrf_offramp)

        globalout = DB.get_data_from_db(DB_TABLE.ANOMALY, job_id, Anomaly_Type.GLOBALOUT)
        # Util.create_excel_sheet(writer, "GLOBALOUT_ANOMALY", DB.GLOBALOUT_COLUMNS, globalout)
        Util.create_excel_sheet(writer, "Uplink ACL Control", DB.GLOBALOUT_COLUMNS, globalout)

        # Newly added
        anomaly_clean_data = DB.get_data_from_db(DB_TABLE.ANOMALY_CLEAN_DATA, job_id)
        # print('printing "anomaly_clean_data":\n',anomaly_clean_data)
        Util.create_excel_sheet(writer, "ANOMALY CLEAN DATA", DB.ANOMALY_CLEAN_DATA_COLUMNS, anomaly_clean_data)

        DB.close_db_conn()

        print("Execl : File created")
        Util.close_resource(writer)
        # writer.close()
    except Exception as e:
        raise Exception(f"Excel Creation Error.\n {str(e)}")



if __name__ == "__main__":
    DB.init_db()
    # job_id = DB.get_job_id_by_script_name(Script_Type.PIA)
    # print(DB.get_data_from_db(DB_TABLE.ANOMALY_CLEAN_DATA, 245))
    print(DB.get_data_from_db(DB_TABLE.PIA_MASTER_DATE_TEMP, 483))
    DB.close_db_conn()

    # if (job_id == None):
    #     print(f"Job ID is not valid. \nPIA_JOB_ID: {job_id}")
    # else:
    #     create_final_excel_with_master_and_anomaly(job_id)