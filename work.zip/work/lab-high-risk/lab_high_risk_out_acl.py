import sys
import os
import platform
"""  # commenting to change the directory path to check for util inside the same directory.

parent_directory_path = os.path.dirname(os.getcwd())
sys.path.append(parent_directory_path)
util_package = ""
if (platform.system() != 'Windows'):
    util_package = parent_directory_path + "/util/python3"
else:
    util_package = parent_directory_path + "\\util\python3"

sys.path.append(util_package)
"""
current_directory_path = os.getcwd()
util_package = ""
if platform.system() != 'Windows':
    util_package = os.path.join(current_directory_path, "util", "python3")
else:
    util_package = os.path.join(current_directory_path, "util", "python3")

sys.path.append(util_package)



import paramiko
import traceback
import time, re, csv
import pandas as pd
import multiprocessing
from functools import partial
from threading import Lock
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from pytz import timezone 
from datetime import datetime

from util.python3.gateway_util import Gateway_Util
from util.python3.gateway_util import Gateway_Util_Exception
from util.python3.network_util import NetWork_Util
from util.python3.network_util import NetWork_Util_Exception
from util.python3.database_util import DB, DB_TABLE
from util.python3.database_util import Script_State
from util.python3.database_util import Script_Type
from util.python3.database_util import DB_Exception
from util.python3.acl_parser_util import ParseAcl
from util.python3.acl_parser_util import Parse_Acl_Exception

today = date.today()
today = str(today.strftime("%d-%m-%Y"))

# day_time = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')
day_time = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y')
job_id: list = []
lock = Lock()

gw_finished_count = 0

gw_conn_status = dict(gw_done_count = 0,
                        gw_error_count = 0,
                        gw_unreachable_count = 0,
                        gw_conn_time_out_count = 0,
                        gw_not_connected_count = 0,
                        gw_unknown_error_count = 0,
                        gw_auth_failed_count = 0,
                        gw_connected_count = 0,
                        gw_nslookup_error = 0)

pia_source_data = {}
labid_subnet_dict = {}

in_acl_output_data = []
out_acl_output_data = []

no_permit_data = []
datas_with_no_labid = []
inproper_desc_for_lab_id = []
lrt_formatted_lab_id_with_details = []
unprocessed_or_error_acl = []

processed_out_acl_set = set()

# for gateway info
host_status = []

class Lab_High_Risk_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(Lab_High_Risk_Exception, self).__init__(self.message)

def get_connection(host):
    return Gateway_Util.get_paramiko_client(host, _username, _password, gw_conn_status, lock)
        
def add_data_to_main(hostname, host_ip, data):
    # print(data)
    output_count = 0
    for interface_name, interface_data in data.items():
        if ("ss-dmzlab" in interface_data["forwarding_info"]):
            lab_id = interface_data["labid"]

            new_row = [lab_id, hostname, host_ip, interface_name, interface_data["ip"], interface_data["description"], 
                                                                    interface_data["forwarding_info"], interface_data["out_acl"]]

            if (Gateway_Util.is_valid_lrt_id(lab_id)):
                #print "\n"
                #print(data) 
                
                if (len(interface_data["in_acl_result"]) > 0):
                    pass

                if (len(interface_data["out_acl_result"]) > 0):
                    for acl_part in interface_data["out_acl_result"]:

                        upd_ports = ", ".join(acl_part[1])
                        tcp_ports = ", ".join(acl_part[2])

                        new_row = [lab_id, hostname, host_ip, interface_name, interface_data["ip"], interface_data["forwarding_info"], 
                                                            interface_data["out_acl"], acl_part[0], upd_ports, tcp_ports, acl_part[3]]
                                                                                      # aclRawLine                       # any any
                        with lock:
                            out_acl_output_data.append(new_row)
                        output_count += 1
                else:                
                    with lock:
                        no_permit_data.append([lab_id, hostname, host_ip, interface_name, interface_data["ip"], 
                                                    interface_data["forwarding_info"], interface_data["out_acl"]])
                                                            
            elif(lab_id != ''):
                with lock:
                    inproper_desc_for_lab_id.append(new_row)
            else:
                with lock:
                    datas_with_no_labid.append(new_row)

    return output_count

def create_excel():
    try:

        # for DB
        """
        IP_SUBNET
        START_IP_INT
        END_IP_INT
        CISCO_IP_SUBNET
        """
        columns = ["Lab ID", "Device", "Device IP Address", "OutACL", "Raw ACL Line", "UDP Risk Port", 
                        "TCP Risk Port", "Any Any", "IP Address", "Start IP Range", "End IP Range", "LAB SUB TYPE", "IP_CHECK"]
        lab_high_risk_data =DB.get_data_from_db_highRisk()
        Gateway_Util.save_data_to_new_csv('output/Lab_High_Rish_Report-comp_data', columns, lab_high_risk_data)

        columns = ["Lab ID", "Device", "Device IP Address", "OutACL", "Raw ACL Line", "UDP Risk Port",
                   "TCP Risk Port", "Any Any", "IP Address", "Start IP Range", "End IP Range", "LAB SUB TYPE",
                   "IP_CHECK"]
        lab_high_risk_data_cleaned = DB.get_data_from_db_highRisk_cleaned()
        Gateway_Util.save_data_to_new_csv('output/Lab_High_Rish_Report-ext', columns, lab_high_risk_data_cleaned)

        columns = ["Lab ID", "Device", "Device IP Address", "OutACL"]
        Gateway_Util.save_data_to_new_csv('output/No_Permit_Report', columns, no_permit_data)

        columns = ["Lab ID", "Device", "OutACL", "Raw ACL Line", "Status"]
        Gateway_Util.save_data_to_new_csv('output/Unproccessed_OR_Error', columns, unprocessed_or_error_acl)
        
        columns = ["Device", "Device IP", "Status"]
        Gateway_Util.save_data_to_new_csv('output/Device_status', columns, host_status)

    except:
        e = traceback.format_exc()
        raise Parse_Acl_Exception("Excel Error:\n" + str(e))


def get_int_config(chan, hostname, interface, parent_data, log_file):
    log_file.write("CMD:  get_int_config\n")

    lab_id = None    
    forward_lab = None    

    parent_data[interface]["description"] = ''
    parent_data[interface]["lab_id_acl"] = {'lab_id': '', 'acl': []}
    parent_data[interface]["forwarding_info"] = ''
    parent_data[interface]["inAcl"] = ''
    parent_data[interface]["outAcl"] = ''
    
    #res = get_SSHResp(chan, 'sh run int ' + interface)
    res = Gateway_Util.exec_command(chan, 'sh run int ' + interface)
    log_file.write("\nResponse:\n" + res + "\nRES_END====\n")
    # print(res)

    if ("vrf forwarding ss-dmzlab" in res):
        actual_data = False
        for line in res.split("\n"):        
            if (actual_data):
                line = str(line.strip())
                # print line
                if ('description' in line):
                    parent_data[interface]["description"] = line

                    ## lab_id = get_lab(line)
                    lab_id = Gateway_Util.get_lab_from_desc(line)
                    if (lab_id):
                        if (',' not in lab_id and '[' not in lab_id):
                            # lab_id = get_valid_lab_id(lab_id, hostname, interface, parent_data)
                            lab_id_datas = Gateway_Util.get_lrt_formatted_id(lab_id, hostname, interface, parent_data[interface]['ip'], 
                                                                                                    parent_data[interface]["description"])
                            lab_id = lab_id_datas[0]
                            if (len(lab_id_datas[1]) != 0):
                                lrt_formatted_lab_id_with_details.append(lab_id_datas[1])
                            
                        parent_data[interface]["lab_id_acl"]["lab_id"] = lab_id
                    
                elif ("forwarding" in line):
                    parent_data[interface]["forwarding_info"] = line

                # for inACL & outACL
                elif (line.startswith("ip access-group ")):
                    # if (parent_data[interface]["inAcl"] == ''):
                    #    parent_data[interface]["inAcl"] = Gateway_Util.get_in_acl(line)
                    if (parent_data[interface]["outAcl"] == ''):
                        parent_data[interface]["outAcl"] = Gateway_Util.get_out_acl(line)                                                                        

            if ("interface" in line):
                actual_data = True
        
        #got_access = False
        out_acl = parent_data[interface]["outAcl"]
        if (out_acl != '' and Gateway_Util.is_valid_lrt_id(lab_id)):            
            
            start_exec_for_acl(chan, interface, hostname, parent_data[interface]["outAcl"], parent_data, log_file)
            
            # to provent dublicate execution for outACL
            """
            with lock:
                if (out_acl not in processed_out_acl_set):
                    processed_out_acl_set.add(out_acl)
                    got_access = True

            if (got_access):
                start_exec_for_acl(chan, interface, hostname, parent_data[interface]["outAcl"], parent_data, log_file)
            else:
                parent_data[interface]["outAcl"] = ''
            """        

def start_exec_for_acl(chan, acl_name, lab_id, hostname, host_data, log_file):
    log_file.write("\nstart_exec_for_acl: " + acl_name + "\n")

    filter = " | in permit (ip|tcp|udp)"
    if (acl_name.endswith("in")):
        filter = " | in permit"

    cmd = 'Show access-lists ' + acl_name + filter
    chan.send(cmd+'\n')
    while not chan.recv_ready():
        time.sleep(3)
    time.sleep(2)
    
    isBigResponse = False
    out = chan.recv(9999)
    respose = out.decode("ascii")    
    
    with ThreadPoolExecutor(max_workers=2) as executor:
        if '--More--' in respose:
            isBigResponse = True
            # respose = str(respose.replace("--More--", "").replace("\x08", "").strip())                        
            log_file.write("\nbatch execution")
            # executor.submit(acl_process, acl_name, respose, lab_id, hostname, host_data, log_file)
        else:
            #print("no batch execution")
            log_file.write("\nno batch execution")        
        respose = str(respose.replace("--More--", "").replace("\x08", "").strip())
        executor.submit(acl_process, acl_name, respose, lab_id, hostname, host_data, log_file)

        #all_res = respose
        while isBigResponse:
            # print("waiting next batch execution")
            log_file.write("\nwaiting next batch execution")
            chan.send(" " + '\r')
            while not chan.recv_ready():
                time.sleep(3)
            time.sleep(2)
            out = chan.recv(9999)
            respose = out.decode("ascii")
            
            if '--More--' not in respose:
                isBigResponse = False

            respose = str(respose.replace("--More--", "").replace("\x08", "").strip())
            # print("batch execution")
            log_file.write("\nbatch execution")
            executor.submit(acl_process, acl_name, respose, lab_id, hostname, host_data, log_file)

    #print("acl multi threading is done")
    log_file.write("acl multi threading is done\n")
    #log_file.write("\nRES\n" + all_res)
    #return str(respose)
     
def acl_process(acl_name, res, lab_id, hostname, host_data, log_file):
    log_file.write("\nRES_START====:\n" + res + "\nRES_END====\n\n")
    
    for line in res.split("\n"):
        line = line.strip()        
        
        if line == '':
            continue
        if acl_name in line or "permit" not in line:
            continue       
        
        try:
            acl =  ParseAcl(line)
            log_file.write(line + " --> " + str(acl.risk_port_is_found) + "\n")

            if (acl.risk_port_is_found):
                ip_address = ""
                start_ip_range = 0
                end_ip_range = 0

                if (acl.source_host != '' and (not acl.source_is_any)):
                    ip_address = acl.source_host
                    start_ip_range = NetWork_Util.ip_to_integer(ip_address)
                    end_ip_range = start_ip_range
                elif (acl.source_subnet != '' and (not acl.source_is_any)):
                    cidr = NetWork_Util.get_cidr(acl.source_subnet)
                    log_file.write("CIDR Conversion: {} -> {})\n".format(acl.source_subnet, cidr))

                    ip_address = cidr
                    start_ip, end_ip = NetWork_Util.get_ip_range(cidr)
                    start_ip_range = NetWork_Util.ip_to_integer(start_ip)
                    end_ip_range = NetWork_Util.ip_to_integer(end_ip)

                log_file.write("IP to int: {}({},{})\n".format(ip_address, start_ip_range, end_ip_range))

                add_to_output(acl_name, acl, lab_id, hostname, host_data, ip_address, start_ip_range, end_ip_range)            

        except NetWork_Util_Exception as e:
            # print(e)            
            with lock:
                unprocessed_or_error_acl.append([lab_id, hostname, acl_name, line, str(e)])
        except Parse_Acl_Exception as e:
            # print(e)            
            with lock:
                unprocessed_or_error_acl.append([lab_id, hostname, acl_name, line, str(e)])
        except Exception as e:
            # print(e)            
            e = traceback.format_exc()
            with lock:
                unprocessed_or_error_acl.append([lab_id, hostname, acl_name, line, str(e)])    
        
    #print("batch execution done")
    #log_file.write("\nbatch execution done\n")
    # time.sleep(5)

def add_to_output(out_acl_name, acl: ParseAcl, lab_id, hostname, host_data, 
                  ip_address, start_ip_range: int, end_ip_range: int):    
    gw_ip =  host_data["gw_ip"]
    with lock:
        out_acl_output_data.append([lab_id, hostname, gw_ip, out_acl_name, acl.actual_acl, 
                                    ", ".join(acl.udp_risk_port), ", ".join(acl.tcp_risk_port), 
                                    acl.any_any, ip_address, start_ip_range, end_ip_range])
        host_data["out_acl_result_count"] += 1

def get_input_data_from_pia(rows: list):    
    try:
        pia_data = {}        

        for row in rows:            
            labid = row[0].strip()
            gw = row[1].strip()
            gw_ip = row[2].strip()
            if (row[3] == None or row[3] == ''):
                continue
            out_acl = row[3].strip()
            """
            if (gw != "rtp1-lab-gw1"):
                continue
            """

            if gw not in pia_data:
                pia_data[gw] = dict(gw_ip = gw_ip, 
                                    out_acl_result_count = 0)
            if labid not in pia_data[gw]:
                pia_data[gw][labid] = set()
                                        
            pia_data[gw][labid].add(out_acl)

        return pia_data
    except:
        e = traceback.format_exc()
        print(e)
    
def get_DeviceStatus(hostname, host_obj):
    global gw_finished_count

    host_ip = host_obj["gw_ip"]

    print("{:<5}  {:<30}  {:<16}  {:<12}  {} \n".format("----", hostname, host_ip, '-', "started"))
    
    status_msg = 'No Status'    
    output_count = 0
    try:
        ssh = get_connection(host_ip)
        chan = ssh.invoke_shell()
        
        out_acl_log_file = open("log/"+hostname+"_outACL.txt", "w")    

        for lab_id, out_acl_set in host_obj.items():            
            if (type(out_acl_set) != set):
                continue                        
            
            for out_acl in out_acl_set:

                if (out_acl != ''):
                    start_exec_for_acl(chan, out_acl, lab_id, hostname, host_obj, out_acl_log_file)                
                    # print(lab_id, hostname, out_acl)

        output_count = host_obj["out_acl_result_count"]


        # output_count = add_data_to_main(hostname, host_ip, host_data)        

        status_msg = "done"
        gw_conn_status["gw_done_count"] += 1

        Gateway_Util.close_resource(ssh)
        # Gateway_Util.close_resource(in_acl_log_file)
        Gateway_Util.close_resource(out_acl_log_file)
    except Gateway_Util_Exception as ex:
        gw_conn_status["gw_error_count"] += 1
        status_msg  = str(ex.message)
    except:
        gw_conn_status["gw_error_count"] += 1
        status_msg = str(traceback.format_exc())
    finally:
        gw_finished_count = gw_finished_count + 1

        print("{:<5}  {:<30}  {:<16}  {:<12}  {} \n".format(gw_finished_count, hostname, host_ip, output_count, status_msg))

        with lock:
            host_status.append([hostname, host_ip, status_msg])

def cidrtosubnetwildmask(cidr):
    ip, prefix_length = cidr.split('/')
    prefix_length = int(prefix_length)
    subnet_mask = '1' * prefix_length + '0' * (32 - prefix_length)
    subnet_mask_components = [int(subnet_mask[i:i+8], 2) for i in range(0, 32, 8)]
    subnet_mask_str = '.'.join(map(str, subnet_mask_components))
    wildcard_mask_components = [(255 - component) for component in subnet_mask_components]
    wildcard_mask_str = '.'.join(map(str, wildcard_mask_components))
    return f"{ip} {wildcard_mask_str}"

def start_process():
    global job_id
    try:
        print("start")
        """
        gw = ["mtv5-mda1-cibb-gw1", "sfo12-cibb-gw2", "sjc18-lab-gw2", "sjc22-lab-gw2", "sjc22-lab-gw1", "sjc18-lab-gw1", "tyoidc5-cp-pxtr1-gw2", "clg5-lab-gw1", "clg5-lab-gw2", "sjc12-cp-mgre1-gw1", "cjs04-lab-gw1", "wnp02-lab-gw1", "mxc-14-lab-gw1", "bnt01-lab-gw1", "lma1-lab-gw1", "bla-lab-gw1", "sjocr02-lab-gw1", "mxc10-lab-gw2", "mxc10-lab-gw1", "snt03-lab-gw1", "alln01-mda2-cp-pxtr1-gw2", "alln01-mda1-cibb-gw3", "rcdn9-cd1-cp-mgre1-gw1", "alln01-mda2-dmzaas-gw2", "alln01-mda1-cp-pxtr1-gw1", "alln01-mda2-cibb-gw4", "ast04-lab-gw1", "alln01-lab-gw1", "alln01-mda1-dmzaas-gw1", "rcdn9-cd2-cp-mgre1-gw2", "rcdn5-lab-sipt-sw1", "bgt2-lab-gw1", "rcdn5-lab-gw1", "ast09-lab-gw2", "ast09-lab-gw1", "glj3-lab-gw1", "bua2-lab-gw1", "spl1-lab-gw1", "ast04-cibb-gw2", "rcdn9-sdfc-dmzvaas-gw2", "rcdn9-sdfa-dmzvaas-gw1", "rcdn5-lab-gw2", "ast04-cibb-gw1", "rcdn6-lab-gw2", "rcdn9-sdfa-dmzvlab-gw1", "rcdn6-lab-gw1", "rcdn5-cibb-gw1", "rcdn9-cd2-lab-gw2", "rcdn9-cd1-lab-gw1", "rcdn5-dmzlab-gw2", "rcdn9-cd2-dmzaas-gw2", "rcdn9-cd1-dmzaas-gw1", "lion3-pl-lab-gw1", "ntn01-lab-gw1", "ntn01-lab-gw2", "mtl02-lab-gw1", "hal01-lab-gw1", "ntn01-cp-pxtr1-gw1", "bos02-lab-gw1", "nyc1-lab-gw1", "nyc1-lab-gw2", "awn01-lab-gw1", "ntn01-cp-pxtr1-gw2", "ott02-lab-gw1", "ott01-lab-gw1", "bxb23-lab-gw1", "cai02-lab-gw1", "bxb23-lab-gw2", "cas02-lab-gw1", "ryd4-lab-gw1", "waw02-lab-gw1", "man3-lab-gw1", "lys01-lab-gw1", "vnaa-lab-gw1", "got-lab-gw1", "dgm3-lab-gw2", "prg5-lab-gw1", "muc07-lab-gw1", "dgm2-lab-gw2", "vbn02-lab-gw1", "krk07-lab-gw2", "bts05-lab-gw1", "lys01-cibb-gw1", "ist2-lab-gw1", "sof7-lab-gw2", "cae02-lab-gw1", "zgr02-lab-gw1", "brc2-lab-gw2", "ams5-lab-gw1", "prg5-lab-gw2", "stk03-lab-gw2", "vbn02-lab-gw2", "bonn01-lab-gw1", "ath01-lab-gw1", "dblir3-lab-gw1", "cae02-lab-gw2", "lys01-lab-gw2", "brc2-lab-gw1", "mhm03-lab-gw1", "ibm3-bg-lab-gw1", "los03-lab-gw1", "ibm3-bg-lab-gw2", "dgm2-lab-gw3", "mdr1-lab-gw1", "dgm2-lab-gw1", "dlf1-lab-gw1", "dgm-lab-gw1", "krk07-lab-gw1", "lys01-cibb-gw2", "est1-jo-lab-gw1", "est1-jo-lab-gw2", "stk03-lab-gw1", "dgm3-lab-gw1", "vmct04-lab-gw1", "ala03-lab-gw1", "krk02-lab-gw1", "aer01-mda1-cp-pxtr1-gw1", "sof7-lab-gw1", "amm02-lab-gw1", "krk04-lab-gw1", "lon11-cibb-gw2", "doh03-lab-gw1", "sykes1-co-lab-gw1", "els01-lab-gw1", "wlsn01-lab-gw1", "loncaf-cp-pxtr1-gw1", "lju02-lab-gw1", "vmct05-lab-gw2", "loncaf-cp-pxtr1-gw2", "lon11-cibb-gw1", "tun03-lab-gw1", "cph06-lab-gw1", "rol01-lab-gw1", "stk06-lab-gw1", "beg02-lab-gw1", "aer01-mda1-lab-gw1", "aer01-mda2-cp-pxtr1-gw2", "stk06-lab-gw2", "aer01-mda2-lab-gw2", "lon06-lab-gw1", "musc01-lab-gw1", "sof2-lab-gw1", "vmct05-lab-gw1", "rom2-lab-gw1", "gpk03-lab-gw1", "els01-cibb-gw2", "aer01-mda2-cp-mgre1-gw2", "fkf3-lab-gw1", "gpk03-cibb-gw1", "fkf3-lab-gw2", "gpk03-cibb-gw2", "aer01-mda1-cp-mgre1-gw1", "gpk03-lab-gw2", "lon07-lab-gw1", "dbi03-lab-gw1", "bcr2-lab-gw1", "kjk04-lab-gw1", "nue01-lab-gw1", "nbo03-lab-gw1", "bud01-lab-gw1", "stg02-lab-gw1", "kwi01-lab-gw1", "gwy03-lab-gw1", "ips02-lab-gw1", "rtp1-mda2-cibbfo-sw1", "rtp1-mda2-cibbfo-sw2", "sjc20-cz-sdlab-gw1", "hrn6-lab-gw1", "hkg1-lab-gw2", "rtp1-mda2-cibb-fw1", "sjc21-cz-sdlab-gw2", "sjc20-cz-sdlab-gw2", "rtp1-mda2-cibb-fw1", "tpe02-lab-gw1", "sjc21-cz-sdlab-gw1", "hkg1-lab-gw1", "hrn6-lab-gw2", "atl-lab-gw1", "rtp1-mda2-cibb-wan-gw2", "rtp1-mda2-cibb-wan-gw1", "rtp10-cd-cp-mgre1-gw1", "lwr01-lab-gw1", "rtp7-cibb-gw1", "rtp10-cd-cp-pxtr1-gw1", "bjn6-lab-gw1", "lwr01-lab-gw2", "rtp1-mda2-cibb-fw1-ironport", "knv-lab-gw1", "bjn6-lab-gw2", "knv3-cibb-gw2", "knv3-cibb-gw1", "stld1-mda1-cp-mgre1-gw1", "stld1-mda2-cp-mgre1-gw2", "csb04-lab-gw2", "csb04-lab-gw1", "blndc01-lab-gw2", "blndc01-lab-gw1", "rtp5-dmzvlab-gw1", "ann01-lab-gw1", "shnidc-cp-pxtr1-gw2", "mrd01-lab-gw2", "mrd01-lab-gw1", "mim1-lab-gw1", "shnidc-cp-pxtr1-gw1", "esp02-lab-gw1", "prg7-lab-gw2", "prg7-lab-gw1", "alp03-lab-gw2", "rtp10-cd-dmzvlab-gw1", "sngidc-cp-pxtr1-gw2", "rtp1-mda1-cp-mgre1-gw1", "alp03-lab-gw1", "cgn03-lab-gw2", "wdf02-lab-gw1", "cgn03-lab-gw1", "rtp10-cd-dmzaas-gw1", "chn09-lab-gw2", "chn09-lab-gw1", "chg12-lab-gw2", "chg12-cibb-gw1", "chg12-cibb-gw2", "chg12-lab-gw1", "tul04-lab-gw2", "tul04-lab-gw1", "sjc05-cp-mgre1-gw1", "hcl7-in-lab-gw1", "hcl7-in-lab-gw2", "sngidc-cp-pxtr1-gw1", "hbg-lab-gw1", "rtp5-cibb-gw1", "trn6-lab-gw1", "trn6-lab-gw2", "rtp7-lab-gw1", "ful01-lab-gw2", "ful01-lab-gw1", "wshdc02-lab-gw1", "rtp3-lab-gw1", "rtp10-00-lab-gw2", "rtp9-lab-gw1", "rtp4-00-lab-gw2", "rtp2-lab-gw1", "sla01-lab-gw2", "rtp1-lab-gw1", "rtp12-00-lab-gw2", "rtp1-lab-gw2", "rtp12-00-lab-gw1", "rtp6-lab-gw2", "sla01-lab-gw1", "rtp6-lab-gw1", "rtp9-lab-gw2", "rtp11-lab-gw1", "sykes2-cr-lab-gw1", "req02-lab-gw1", "sol2-lab-gw1", "sea1-lab-gw1", "rtp5-lab-gw1", "rtp11-lab-gw2", "rtp1-mda1-cp-pxtr1-gw1", "rtp7-lab-gw2", "rtp8-lab-gw2", "embsys2-in-lab-gw2", "embsys2-in-lab-gw1", "sngidc-dmzvlab-gw1", "sngidc-dmzvlab-gw2", "pen3-lab-gw1", "pen3-lab-gw2", "jkt05-lab-gw2", "jkt05-lab-gw1", "rtp1-dmzvaas-gw1", "rtp7-dmzvaas-gw1", "ful01-fw1", "rtp5-dmzlab-gw1", "rtp8-lab-gw1", "req01-lab-gw1", "rtp1-dmzlab-gw1", "rtp11-dmzlab-gw1", "csv-lab-gw1", "atl11-lab-gw2", "atl11-lab-gw1", "ors03-lab-gw2", "cwy01-lab-gw1", "ors03-lab-gw1", "cwy01-lab-gw2", "gai03-lab-gw2", "bel01-lab-gw2", "bel01-lab-gw1", "aar02-lab-gw1", "bln2-lab-gw2", "gai03-lab-gw1", "bln2-lab-gw1", "tyoidc5-cp-pxtr1-gw1", "twl03-lab-gw1", "mil01-lab-gw1", "mil01-lab-gw2", "schp01-lab-gw1", "bgl16-00-lab-gw1", "argrp4-in-lab-gw1", "wpr2-in-lab-gw1", "bgl16-00-lab-gw2", "argrp4-in-lab-gw2", "bgl17-cp-mgre1-gw1", "argrp1-in-lab-gw1", "mtc2-in-lab-gw1", "bgl13-lab-gw2", "bgl13-cp-pxtr1-gw1", "bgl13-cibb-gw1", "bgl17-cp-pxtr1-gw1", "bgl13-lab-gw1", "bgl17-cibb-gw1", "pnq05-lab-gw2", "pnq05-lab-gw1", "hcl14-in-lab-gw1", "hcl14-in-lab-gw2", "bgl18-00-lab-gw1", "cmb03-lab-gw1", "infy9-in-lab-gw1", "bgl13-cp-mgre1-gw1", "bgl14-00-lab-gw1", "bgl18-00-lab-gw2", "bgl14-00-lab-gw2", "chn08-lab-gw1", "ggn01-lab-gw1", "ggn01-lab-gw2", "bgl26-lab-gw1", "shn15-lab-gw1", "argrp5-in-lab-gw1", "bgl17-00-lab-gw1", "bgl17-00-lab-gw2", "wpr8-in-lab-gw1", "hcl19-in-lab-gw2", "hcl19-in-lab-gw1", "bgl11-00-lab-gw2", "bgl11-00-lab-gw1", "bgl12-00-lab-gw1", "mmb12-lab-gw1", "mmb12-lab-gw2", "bgl12-00-lab-gw2", "kul02-lab-gw1", "bgl15-00-lab-gw1", "bgl15-00-lab-gw2", "hcl17-in-lab-gw1", "hcl17-in-lab-gw2", "bng02-lab-gw1", "hgh06-ext-lab-gw2", "hgh06-ext-lab-gw1", "sngdc01-mda2-cibb-gw2", "sngdc01-mda1-cibb-gw1", "akl02-lab-gw1", "mel03-lab-gw1", "tky7-lab-gw1", "hgh05-lab-gw1", "shn4-cibb-gw1", "shn15-lab-gw2", "shn6-lab-gw1", "shn7-lab-gw2", "tky7-lab-gw2", "ngo1-lab-gw1", "sng15-lab-gw1", "shn7-lab-gw1", "shn4-lab-gw2", "shn4-cibb-gw2", "shn4-lab-gw1", "sng15-lab-gw2", "prt3-lab-gw1", "nsd5-lab-gw2", "nsd5-lab-gw1", "cbr04-lab-gw1", "foxc1-cn-lab-gw1", "gng03-lab-gw1", "hfe02-lab-gw1", "hfe02-lab-gw2", "tky7-cibb-gw2", "tky7-cibb-gw1", "stld1-lab-gw2", "stld1-lab-gw1", "szn04-lab-gw1", "szn05-lab-gw1", "wln2-lab-gw1", "hni05-lab-gw1", "dlc02-lab-gw1", "dlc02-lab-gw2", "fka1-lab-gw1", "osk04-lab-gw1", "brb05-lab-gw1", "sngdc01-mda2-dmzaas-gw2", "sngdc01-mda1-dmzaas-gw1", "mnl02-lab-gw1", "shn17-lab-gw1", "shn17-lab-gw2", "svta01-lab-gw1", "yer03-lab-gw1", "sjc23-lab-gw2", "sjc21-lab-gw1", "sjc20-cibb5-gw1", "sjc20-lab-gw1", "sjcp-lab-gw2", "sjc23-lab-gw1", "sjc24-lab-gw1", "sjc21-lab-gw2", "sjc24-lab-gw2", "sjc20-lab-gw2", "sjcp-lab-gw1", "bvw01-lab-gw1", "sea1-lab-gw2", "vnc2-lab-gw1", "sjc5-cibbfo-sw2", "sjc5-cibbfo-sw1", "sjc5-cibb-wan-gw1", "sjc5-cibb-fw1", "wlt06-lab-gw2", "sjc12-dmzvaas-gw1", "sjc05-dmzvaas-gw1", "blv-lab-gw1", "wlt06-lab-gw1", "sjc5-cibb-fw1-ironport", "sjc12-cibb4-gw1", "sjc5-cibb-wan-gw2", "sjc12-lab-gw1", "sjc12-cp-pxtr1-gw1", "sfo12-cibb-gw1", "sjc5-cibb4-gw1", "sjc05-cp-pxtr1-gw1", "sjc02-lab-gw1", "sjc14-lab-gw1", "sjc16-lab-gw1", "sjc11-lab-gw1", "sjc08-lab-gw1", "sjc03-lab-gw1", "sjc01-lab-gw1", "sjc5-cibb4-gw2", "sjc15-lab-gw2", "sjc09-lab-gw1", "sjc07-lab-gw1", "sjc17-lab-gw1", "sjc13-lab-gw1", "sjc06-lab-gw2", "sjc04-lab-gw1", "sjc15-lab-gw1", "sjc19-lab-gw1", "sjc10-lab-gw1", "sjc04-lab-gw2", "sjc16-lab-gw2", "sjc14-lab-gw2", "sjc03-lab-gw2", "sjc13-lab-gw2", "sjc05-lab-gw2", "sjc06-lab-gw1", "sjc02-lab-gw2", "sjc01-lab-gw2", "sjc05-lab-gw1", "sjc09-lab-gw2", "sjc12-cibb4-gw2", "sjc10-lab-gw2", "sjc19-lab-gw2", "sjc08-lab-gw2", "sjc12-lab-gw2", "sjc07-lab-gw2", "sjc17-lab-gw2", "csb03-lab-gw1", "syc02-lab-gw1", "cosm02-lab-gw1", "sprg01-lab-gw2", "irv8-lab-gw1", "csb03-lab-gw2", "lux1-lab-gw1", "rtp5-lab-gw2", "rtp4-00-lab-gw1", "bgl17-dmzvlab-gw1", "bgl13-dmzaas-gw1", "bgl17-dmzaas-gw1", "bgl25-lab-gw1", "rcdn6-cibb-gw1", "sprg01-lab-gw1", "sjc23-cibb5-gw1", "par03-lab-gw2", "par03-lab-gw1", "bdlk11-cibb-gw1", "bdlk09-00-lab-gw1", "bdlk10-31-lab-gw1", "bdlk09-12-lab-gw1", "bdlk09-cibb-gw1", "bdlk10-00-lab-gw1", "bdlk09-00-lab-gw2", "bdlk11-00-lab-gw2", "bdlk11-00-lab-gw1", "rtp10-00-lab-gw1", "rtp5-dmzaas-gw1", "lon06-cibb-gw1", "els01-cibb-gw1", "mtv5-mda2-cibb-gw2", "sjc05-dmzvlab-gw1", "sjc5-cibb-fw2-ironport", "sjc5-cibb-fw2", "rtp1-mda2-cibb-fw2", "rtp1-mda2-cibb-fw2-ironport", "rtp1-mda2-cibb-fw2-latisys"]
        # gw = ["argrp4-in-lab-gw1"]

        # gw_with_ip = Gateway_Util.get_ip_address_by_nslookup(gw)[0]
        nslookup_status = Gateway_Util.get_ip_address_by_nslookup(gw)
        gw_with_ip = nslookup_status[0]
        
        # add the failed nslookup details to host_status
        gw_conn_status["gw_nslookup_error"] = len(nslookup_status[1])
        for row in nslookup_status[1]: 
            host_status.append(row)
        """
        DB.init_db()
        DB.truncate_table(DB_TABLE.LAB_HIGH_RISK)
        job_id = [DB.get_job_id(Script_Type.PIA, Script_State.STARTED)]
        pia_data_from_db = DB.get_input_from_pia_for_lab_high_risk()
        DB.close_db_conn()
        
        pia_source_data = get_input_data_from_pia(pia_data_from_db)
        print("\nTotal Gateway = {}\n".format(len(pia_source_data)))
        no_of_worker = 10 if len(pia_source_data) >= 10 else len(pia_source_data)
        with ThreadPoolExecutor(max_workers = no_of_worker) as executor:
            for gw_name, gw_data in pia_source_data.items():
                #if (gw_name == "rtp1-lab-gw1"):
                executor.submit(get_DeviceStatus, gw_name, gw_data)
                    # break
        #for i in input_data:
        # get_DeviceStatus("rtp6-lab-gw1".strip(), "172.18.0.66".strip(), "TenGigabitEthernet1/7".strip())



        DB.init_db()
        DB.insert_lab_high_risk(out_acl_output_data, day_time)
        DB.insert_gw_process_status(Script_Type.LAB_HIGH_RISK, host_status, job_id[0])

        # cmdr_data = DB.get_data_from_cmdr_network_data()
        # mask_data = []
        # for data in cmdr_data:
        #     mask_data.append(cidrtosubnetwildmask(data))
        # mask_data = list(set(mask_data))
        # DB.internal_lab_check(mask_data)
        DB.update_ip_range_check()

        create_excel()
        DB.close_db_conn()
    except DB_Exception as e:
        print(e.message)
    except:
        e = str(traceback.format_exc())
        print(e)
    finally:
        message = str("Gw done : " + str(gw_conn_status["gw_done_count"]) 
        + "\nGw error : " + str(gw_conn_status["gw_nslookup_error"] + gw_conn_status["gw_error_count"])
        + "\n\nGw IP not found by nslookup count : " + str(gw_conn_status["gw_nslookup_error"])
        + "\nGw Unreachable : " + str(gw_conn_status["gw_unreachable_count"])
        + "\nGw connection timed out: " + str(gw_conn_status["gw_conn_time_out_count"])
        + "\nGw not connected : " + str(gw_conn_status["gw_not_connected_count"])
        + "\nGw Unknown error : " + str(gw_conn_status["gw_unknown_error_count"])
        + "\nGw authentication failed : " + str(gw_conn_status["gw_auth_failed_count"])
        + "\nIncorrect Lab ID count : " + str(len(lrt_formatted_lab_id_with_details)))

        print(message)


        # try:
            #zip_file()
            #Gateway_Util.send_mail_from_server_cmd("noreply@cisco.com", ["mjoshva@cisco.com"], "Lab High Rish script finished", "master.log", "lab_high_risk-"+today+".zip")
        # except:
        # Gateway_Util.send_mail_from_server_cmd("noreply@cisco.com", ["mjoshva@cisco.com"], "Lab High Rish script finished", "master.log")

def zip_file():
    os.system("cp master.log ./output/")
    print(os.getcwd())
    os.chdir("output")
    print(os.getcwd())
    os.system("zip lab_high_risk-"+today+".zip *.csv")
    Gateway_Util.send_mail_from_server_cmd("noreply@cisco.com", ["shoraj@cisco.com"], "Lab High Rish script finished", "master.log", "lab_high_risk-"+today+".zip")


#
#   nohup python lab_high_risk_python2.py > master.log &  
#
if __name__ == "__main__":
    _username = 'morashee.web'
    _password = '%Tgb0okm9ijn'
    start_process()
    

    # DB.init_db()
    # cmdr_data = DB.get_data_from_cmdr_network_data()
    # mask_data = []
    # for data in cmdr_data:
    #     mask_data.append(cidrtosubnetwildmask(data))
    # mask_data = list(set(mask_data))
    # DB.internal_lab_check(mask_data)
    # DB.update_ip_range_check()
    # # pia_data_from_db = DB.get_input_from_pia_for_lab_high_risk()
    # # pia_source_data = get_input_data_from_pia(pia_data_from_db)
    # # print(pia_source_data)
    # # print(len(pia_source_data))
    # create_excel()
    # DB.close_db_conn()


    print("done")