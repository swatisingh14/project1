python lab_high_risk_out_acl.py | tee master.log 
echo "" |  mail -a master.log -s "Lab High Risk Script finished" -r noreply@cisco.com mjoshva@cisco.com