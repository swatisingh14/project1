python vrf-offramp_with_pxtr.py  | tee vrf_offramp_with_pxtr_master.log
echo "" |  mail -a vrf_offramp_with_pxtr_master.log -s "Vrf-offramp script finished" -r noreply@cisco.com shoraj@cisco.com 