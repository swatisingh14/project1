python PIA_scan_latest.py | tee pia_master.log
echo "" |  mail -a pia_master.log -s "PIA Script finished" -r noreply@cisco.com shoraj@cisco.com
# python pia_inacl_anomaly_with_gw.py | tee pia_inacl_anomaly_master.log 
# echo "" |  mail -a pia_inacl_anomaly_master.log -s "PIA InACL Script finished" -r noreply@cisco.com shoraj@cisco.com