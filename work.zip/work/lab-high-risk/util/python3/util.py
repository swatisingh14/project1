import csv
import os
import traceback
import pandas as pd
from pandas import ExcelWriter
from pandas import DataFrame
from typing import Union

class Util_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(Util_Exception, self).__init__(self.message)

class Util:

    @staticmethod
    def save_data_to_new_csv(filename: str, columns: list, data_list: list):
        csv_file = None
        if (not filename.endswith(".csv")):
            filename = filename + ".csv"
        try:
            csv_file = open(filename,'w')
            writer = csv.writer(csv_file)
            print("CSV : Writing report to "+filename+"... | count: {}".format(str(len(data_list))))
            writer.writerow(columns)
            for i in data_list:
                    writer.writerow(i)

            Util.close_resource(csv_file)
        except Exception as e:
            raise Util_Exception("Util Error: Couldn't create csv "+filename +"\n"+ str(e))
        
    @staticmethod
    def send_mail_from_server_cmd(sender, receivers, subject, *filenames):

        filename = " -a ".join(filenames)
        try:
            cmd = 'echo "" |  mail -a %s -s "%s" -r %s %s'%(filename, subject, sender, " ".join(receivers))
            # print(cmd)
            os.system(cmd)
            print("Mail sent")
        except:
            e = str(traceback.format_exc())
            raise Util_Exception("Error: unable to send email\n" + str(e))  

    @staticmethod
    def create_new_excel_writer_obj(file_name: str) -> ExcelWriter:
        """mode = w\n
        engine = xlsxwriter
        """
        if (file_name == None or type(file_name) != str or file_name.strip() == ''):
            raise Util_Exception(f"File Name is not valid.Value: {file_name}")
        
        if (not file_name.endswith(".xlsx")):
            file_name = file_name + ".xlsx"

        return pd.ExcelWriter(file_name,  mode="w", engine = 'xlsxwriter')

    @staticmethod
    def create_excel_sheet(writer: DataFrame, sheet_name:str, columns: list, row_datas: list):
        print("Excel : Writing report to "+sheet_name+" sheet... | count: {}".format(str(len(row_datas))))
        
        if (writer == None):
            raise Util_Exception("Util Error: writer object is empty.") 
        input_list = row_datas
        temp_list = []
        if (len(row_datas) == 0):
            temp_list.append(["" for i in range(len(columns))])
            input_list = temp_list
        try:
            df = pd.DataFrame(input_list)
            df.columns = columns        
            df.to_excel(writer, sheet_name = sheet_name, index=False)
        except Exception as e:
            raise Util_Exception("Util Error: Couldn't create excel sheet "+sheet_name+"\n"+str(e))
        
    @staticmethod
    def close_resource(*objs):
        for obj in objs:
            if (obj != None):
                try:
                    obj.close()
                except:
                    pass