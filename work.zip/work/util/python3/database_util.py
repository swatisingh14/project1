import cx_Oracle
from cx_Oracle import Cursor
import traceback
import os
from pytz import timezone 
from datetime import datetime
from enum import Enum
import platform
from typing import List
from typing import Union
from deprecated import deprecated
import json
from base64 import b64encode
import pandas as pd

from network_util import NetWork_Util
# from util.python3.network_util import NetWork_Util

today = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')
"""Time Zone = Asia/Kolkata\n
Date_TimeFormat = %d-%m-%Y %H:%M:%S\n
Example = 08-07-2023 18:53:56
"""

class DB_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(DB_Exception, self).__init__(self.message)

class Script_Type(Enum):
    PIA = "PIA"
    VRF_OFFRAMP = "VRF_OFFRAMP"
    PIA_DMZ_INACL_ANOMALY = "PIA_DMZ_INACL_ANOMALY"
    LAB_HIGH_RISK = "LAB_HIGH_RISK"

class Anomaly_Type(Enum):
    SAME_SUBNET_MULTIPLE_LAB = "Subnets Routed in Multiple Labs"  # "SAME_SUBNET_MULTIPLE_LAB"  # Same Subnets routed in Multiple Labs
    WITH_OUT_NEXTHOP = "Next Hop Config missing"  # "WITH_OUT_NEXTHOP"  # Next Hop Configuration missing in Lab Interfaces
    PIA_DMZ_INACL = "Covered ACL in DMZ Lab"  # "PIA_DMZ_INACL"  # Covered ACL in DMZ Lab
    PIA_OVERLAPPING_SUBNET = "Overlapping Subnet"  # "PIA_OVERLAPPING_SUBNET"  # Overlapping Subnet
    PIA_MASTER_NOT_A_ANOMALY = "PIA_MASTER_NOT_A_ANOMALY"
    NO_VRF = "VRF Config missing"  # "NO_VRF"  # VRF Configuration Missing in Lab Interfaces
    DMZ_TEMPLATE_ACL = "DMZ ACL Control"  # "DMZ_TEMPLATE_ACL"  # DMZ ACL Control
    VRF_OFFRAMP = "Lab-lenient ACL control"  # "VRF_OFFRAMP"  # Lab-lenient ACL control  # Newly added ## Added new column in the DB named 'GATEWAY2'- Neighbour Decive and 'GATEWAY2_IP'- Neighbour IP Address
    GLOBALOUT = "Uplink ACL Control"  # "GLOBALOUT"  # Uplink ACL Control  # Newly added
    ALL = "ALL"

class Delete_Data_criteria_list(Enum):
    """
    variables contains data which needs to be deleted from concerning anomaly type.
    """
    No_VRF_criteria_list = [
    ('RTP', 'LRT0048048', 'rtp7-dmzvaas-gw1', 'Tunnel3', 'DMZaaS', 'Compliant')
    # Add more criteria sets here as needed
    ]
    GLOBALOUT_criteria_list = [
    ('SJC', 'sjc20-cz-sdlab-gw1', '10.8.129.202', 'HundredGigE1/0/2', '10.8.129.205'),
    ('SJC', 'sjc20-cz-sdlab-gw1', '10.8.129.202', 'HundredGigE1/0/1', '10.8.129.201'),
    ('SJC', 'sjc21-cz-sdlab-gw1', '10.8.129.212', 'HundredGigE1/0/2', '10.8.129.216'),
    ('SJC', 'sjc21-cz-sdlab-gw1', '10.8.129.212', 'HundredGigE1/0/1', '10.8.129.211'),
    ('SJC', 'sjc20-cz-sdlab-gw2', '10.8.129.193', 'HundredGigE1/0/2', '10.8.129.207'),
    ('SJC', 'sjc20-cz-sdlab-gw2', '10.8.129.193', 'HundredGigE1/0/1', '10.8.129.199'),
    ('SJC', 'sjc21-cz-sdlab-gw2', '10.8.129.203', 'HundredGigE1/0/2', '10.8.129.214'),
    ('SJC', 'sjc21-cz-sdlab-gw2', '10.8.129.203', 'HundredGigE1/0/1', '10.8.129.209')
    # Add more criteria sets here as needed
    ]


class DB_TABLE(Enum):
    """Use .value to get the actual value.
    """
    SCRIPT_AUDIT = "T_SRT_PIA_PROCESS_AUDIT"
    HOST_INFO = "T_SRT_HOST_INFO"
    HOST_INFO_TEMP = "T_SRT_HOST_INFO_TEMP"  # trial DB.
    HOST_AUDIT = "T_SRT_HOST_AUDIT"
    PIA_MASTER_DATE = "T_SRT_PIA_HOST_REPORT"
    PIA_MASTER_DATE_HISTORY = "T_SRT_PIA_HOST_REPORT_H"
    ANOMALY = "T_SRT_PIA_ANOMALY"
    ANOMALY_HISTORY = "T_SRT_PIA_ANOMALY_H"
    PIA_SUBNET_WITH_LAB = "T_SRT_PIA_SUBNET_WITH_LAB"
    PIA_SUBNET_WITH_LAB_HISTORY = "T_SRT_PIA_SUBNET_WITH_LAB_H"
    LAB_HIGH_RISK = "T_SRT_LAB_HIGH_RISK_SERVICE_DATA"
    LAB_HIGH_RISK_HISTORY = "T_SRT_LAB_HIGH_RISK_SERVICE_DATA_H"
    LRT_LAB_OWNER = "T_ISP_LAB_OWNER"
    ANOMALY_CLEAN_DATA = "T_SRT_PIA_CLEAN_DATA"
    ANOMALY_CLEAN_DATA_HISTORY = "T_SRT_PIA_CLEAN_DATA_H"
    PIA_MASTER_DATE_TEMP = "T_SRT_PIA_HOST_REPORT_TEMP"
    PIA_PASSWORD_DB = "PASSWORD_STORAGE"

class Script_State(Enum):
    STARTED = "STARTED"
    PROCESSING = "PROCESSING"
    DONE = "DONE"
    ERROR = "ERROR"

class Row_Tag(Enum):
    CLEAN_AND_NOT_CLEAN = 1
    LAB_STATE_AND_SUB_TYPE = 2
    LAB_SUB_TYPE = 3


class DB:

    __connection = None
    __cursor = None

    @staticmethod
    def init_db():
        print("\nDB :  Connecting...", end="")
        try:
            if (platform.system() != 'Windows'):
                os.environ["ORACLE_HOME"]="/usr/cisco/packages/oracle/oracle-12.1.0.2"
                os.environ["LD_LIBRARY_PATH"]="$ORACLE_HOME/lib:$LD_LIBRARY_PATH"
            # global cursor, connection
            # DB.connection = cx_Oracle.connect('ESMSCSTG', 'Cisco_123', '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=dbs-nprd2-vm-013.cisco.com)(PORT=1535))(CONNECT_DATA=(SERVICE_NAME=ESMDBSTG.CISCO.COM)(Server=Dedicated)))')
            dsn = cx_Oracle.makedsn("dbs-nprd2-vm-013.cisco.com", 1535, service_name="ESMDBSTG.cisco.com")
            DB.__connection = cx_Oracle.connect(user="ESMSCSTG", password='Cisco_123', dsn=dsn,encoding="UTF-8")            
            DB.__connection.autocommit = True
            DB.__cursor = DB.__connection.cursor()
            print(" | Connected\n")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : DB couldn't be connected \n" + str(e))
        
    @staticmethod
    def get_job_id(script_name: Script_Type, state: Script_State):
        print("DB : Getting Job ID | {} with state = {}...".format(script_name.value, state.value), end="")
        try:
            columns = ["SCRIPT_NAME", "STATUS"]
            sql = DB.__get_sql_insert_query(DB_TABLE.SCRIPT_AUDIT.value, columns)
            sql = sql + " returning JOB_ID into :3"
            # print(sql)
            new_row_id = DB.__cursor.var(cx_Oracle.STRING)
            row = [script_name.value, state.value, new_row_id]
            DB.__cursor.execute(sql, row)
            print(" | Added")
            
            return int(new_row_id.getvalue()[0])
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Script entry couldn't be inserted" + str(e))
    
    @staticmethod
    def update_job_status(script_name: Script_Type, state: Script_State, job_id: int):
        print("DB : Job_ID = {} | Updating job status | {} with state = {}...".format(job_id, 
                                                                                       script_name.value, 
                                                                                       state.value), 
                                                                                end="")
        try:            
            sql = f"UPDATE {DB_TABLE.SCRIPT_AUDIT.value} SET STATUS=:status WHERE JOB_ID=:job_id and SCRIPT_NAME=:script_name"
            # print(sql)
            DB.__cursor.execute(sql, status=state.value, job_id=job_id, script_name=script_name.value)
            print(f" | Updated: count={DB.__cursor.rowcount}")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Job Status is updated" + str(e))

    @staticmethod
    def get_job_id_by_script_name(script_name: Script_Type) -> Union[int, None]:
        """Return latest JOB_ID by script name for STATUS = 'DONE'
        """

        print("DB : Fetching lasted job id | {}...".format(script_name.value), end="")
        try:
            job_id = None
            sql = DB.__LATEST_JOB_ID
            # print(sql)
            DB.__cursor.execute(sql, script_name=script_name.value)
            data = DB.__cursor.fetchall()
            for row in data:
                if (row[0] != None and row[0] != ''):
                    job_id = row[0]
                
            if (len(data)> 1):
                raise DB_Exception("DB Error: Got more than one latest job id\nValues: {}\n{}".format(len(data), str(e)))
            
            print(" | Job ID = {}".format(job_id))
            return job_id            
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Script's latest job id couldn't be fetchted\n" + str(e))

    @staticmethod
    def get_input_lab_gw_with_dc(script_type: Script_Type):
        print("DB : Fetching source gws from  {}...".format(DB_TABLE.HOST_INFO.value), end="")
        try:
            gw = []
            sql = "select HOSTNAME, DC, TYPE from {} where TYPE='Lab'".format(DB_TABLE.HOST_INFO.value)
            DB.__cursor.execute(sql)
            
            rows = DB.__cursor.fetchall()
            for row in rows:
                
                # if (row[0] not in {"sjc18-lab-gw1", "sjc18-lab-gw2", "sjc05-dmzvaas-gw1", "sjc12-dmzvaas-gw1"}):
                #     continue

                if (script_type == Script_Type.PIA):
                    gw.append([row[0], row[1]])
                elif (script_type == Script_Type.VRF_OFFRAMP):
                  # if ("dmz" not in row[0]):
                    gw.append([row[0], row[1]])     # change

            print(" | Count :  " + str(len(gw)))
            return gw
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Source GW details couldn't be fetched \n" + str(e))
        
    @staticmethod
    def insert_pia_master_report(rows: List[list], job_id: int):
        """It uses executemany(). So each inner list must have 11 data.\n
        (lab_id, host_name, host_ip, interface, interface_ip, description,\n
        forwarding_lab, in_acl, out_acl, lab_route_subnet, next_hop)
        """

        print("DB : Job_ID = {} | Inserting | PIA Master report | {}... | count = {}".format(job_id, DB_TABLE.PIA_MASTER_DATE.value, len(rows)), end="")
        if (len(rows) == 0 ):
            print(" | Not inserted")
            return
        
        try:
            # today = date_time
            # today = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')
            cols = ["dc", "lab_id", "host_name", "host_ip", "interface", "interface_ip", "description", 
                        "forwarding_lab", "in_acl", "out_acl", "lab_route_subnet", "next_hop"]
            sql = DB.__get_sql_insert_query(DB_TABLE.PIA_MASTER_DATE.value, cols, [["job_id", job_id]])
            # print(sql)
            DB.__cursor.executemany(sql, rows)
            print(" | Inserted")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : GW master details couldn't be inserted" + str(e))            

    @staticmethod
    def insert_anomaly(anomaly_type: Anomaly_Type, rows: list, job_id: int):

        if (anomaly_type == Anomaly_Type.PIA_OVERLAPPING_SUBNET):
            DB.__in_db_insert_for_anomaly(anomaly_type, job_id, DB_TABLE.PIA_SUBNET_WITH_LAB ,DB_TABLE.ANOMALY)
            return
        
        if (anomaly_type == Anomaly_Type.NO_VRF):
            DB.__in_db_insert_for_anomaly(anomaly_type, job_id, DB_TABLE.PIA_MASTER_DATE ,DB_TABLE.ANOMALY)
            return
        
        if (anomaly_type == Anomaly_Type.WITH_OUT_NEXTHOP):
            DB.__in_db_insert_for_anomaly(anomaly_type, job_id, DB_TABLE.PIA_MASTER_DATE ,DB_TABLE.ANOMALY)
            return


        print("DB : Job_ID = {} | inserting | Anomaly : {} | {}... | count = {}".format(
                                                                            job_id,
                                                                            anomaly_type.value, 
                                                                            DB_TABLE.ANOMALY.value, 
                                                                            len(rows)), 
                                                                        end="")
        if (len(rows) == 0 ):
            print(" | Not inserted")
            return
        
        # today = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')

        sql = ""
        # sql = "insert into {} (DATA_CENTER, LAB_ID".format(DB_TABLE.ANOMALY.value)
        # values = "values("
        columns = []
        if (anomaly_type == Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB):
            # sql += ", SUBNET "
            # values += ":1, :2, :3, '"+anomaly_type.value+"'"
            columns = ["DATA_CENTER", "LAB_ID", "SUBNET"]            
        elif (anomaly_type == Anomaly_Type.PIA_DMZ_INACL):
            # sql += ", GATEWAY, IN_ACL, RAW_ACL_LINE"
            # values += ":1, :2, :3, :4, :5, '"+anomaly_type.value+"'"            
            columns = ["DATA_CENTER", "LAB_ID", "GATEWAY", "IN_ACL", "RAW_ACL_LINE"]
        elif (anomaly_type == Anomaly_Type.DMZ_TEMPLATE_ACL):
            columns = ["DATA_CENTER", "LAB_ID", "IN_ACL", "OUT_ACL", "GATEWAY"]
        elif (anomaly_type == Anomaly_Type.VRF_OFFRAMP):
            columns = ["DATA_CENTER", "GATEWAY", "GATEWAY_IP", "GATEWAY2", "GATEWAY2_IP",
                       "INTERFACE", "INTERFACE_IP", "FORWARD_INFO", "OUT_ACL"]
        elif (anomaly_type == Anomaly_Type.GLOBALOUT):
            columns = ["DATA_CENTER", "GATEWAY", "GATEWAY_IP",
                       "INTERFACE", "INTERFACE_IP", "OUT_ACL"]

        
        common_col = [["ANOMALY_TYPE", anomaly_type.value], ["JOB_ID", job_id]]
        sql = DB.__get_sql_insert_query(DB_TABLE.ANOMALY.value, columns, common_col)
            

        # values = values + ", {})".format(job_id)
        # sql += ", ANOMALY_TYPE, JOB_ID)" + values


        try:
            # print(sql)
            DB.__cursor.executemany(sql, rows)
            print(" | Inserted")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : "+anomaly_type.value+" anomaly report couldn't be inserted" + str(e))
        
    @staticmethod
    @deprecated(reason="Use insert_pia_subnet_with_lab_list()")
    def insert_pia_subnet_with_labid(rows: List[list], job_id: int):
        """@deprecated"""

        print("DB : Job_ID = {} |  Inserting | SubnetwithLabIDList | {}... | count = {}".format(job_id,
                                                                            DB_TABLE.PIA_SUBNET_WITH_LAB.value, 
                                                                            len(rows)), 
                                                                        end="")
        try:
            column_list = ["subnet", "lab_id_list"]
            sql = DB.__get_sql_insert_query(DB_TABLE.PIA_SUBNET_WITH_LAB.value, column_list)
            DB.__cursor.executemany(sql, rows)
            print(" | Done")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("Subnet with Lab Id details couldn't be Inserted \n" + str(e))    
    
    @staticmethod
    def insert_pia_subnet_with_lab_list(rows: List[list], job_id: int):
        print("DB : Job_ID = {} | Inserting | SubnetWithLabIdList (Overlapping input) | {}... | count = {}".format(job_id,
                                                                                DB_TABLE.PIA_SUBNET_WITH_LAB.value, 
                                                                                len(rows)), 
                                                                            end="")        
        try:
            column_list = ["SUBNET", "LAB_ID_LIST", "DC", "START_IP_RANGE", "END_IP_RANGE"]        
            sql = DB.__get_sql_insert_query(DB_TABLE.PIA_SUBNET_WITH_LAB.value, 
                                            column_list,
                                            [["JOB_ID", job_id]])
            DB.__cursor.executemany(sql, rows)
            print(" | Inserted")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Subnet with LabId list couldn't be Inserted \n" + str(e))
        
    @staticmethod
    def insert_gw_process_status(script_type: Script_Type, rows: list, job_id: int):
        """It uses executemany(). So each inner list must have 4 data.\n
        (host_name, IP_ADDRESS, status, TYPE)
        """

        print("DB : Job_ID = {} | Inserting | Gateway status | {}... | count = {}".format(
                                                                                    job_id,
                                                                                    DB_TABLE.HOST_AUDIT.value, 
                                                                                    len(rows)), 
                                                                                end="")
        try:  
            # today = date_time          
            # today = datetime.now(timezone("Asia/Kolkata")).strftime('%d-%m-%Y %H:%M:%S')
            sql = DB.__get_sql_insert_query(DB_TABLE.HOST_AUDIT.value, ["host_name", "IP_ADDRESS", "status"], 
                                            [["TYPE", script_type.value], ["JOB_ID", job_id]])
            """
                    insert into {} 
                        (host_name, IP_ADDRESS, status, TYPE) 
                        values(:1, :2, :3, '{}')
            .format(DB_TABLE.T_SRT_HOST_AUDIT.value, script_type.value)"""
            #print(sql)
            DB.__cursor.executemany(sql, rows)
            print(" | Inserted")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Gateway process status details couldn't be Inserted \n" + str(e))
        
    @staticmethod
    def __get_sql_insert_query(table_name: str, columns: List[str], commom_columns_and_values: List[list] = None):
        """For insert data only.\n
        If you want where clause use __add_equal_condition().\n\n
        commom_columns: [["JOB_ID", 1234], ["Status", "Done"]] -> (..., JOB_ID, Status) values(..., 1234, 'Done')\n
        commom_columns do not support for Date value.
        """

        sql = "insert into " + table_name + "("
        value_part = "values("
        for idx, col_name in enumerate(columns):
            sql = sql + col_name
            value_part = value_part + ":{}".format(idx + 1)

            if (idx != len(columns) - 1):
                sql = sql + ", "
                value_part = value_part + ", "
                    
        if (commom_columns_and_values != None):
            for idx, data in enumerate(commom_columns_and_values):
                col_name = data[0]
                col_val = data[1]

                if (type(col_val) == str):
                    col_val = "'" + col_val + "'"

                sql = sql + ", " + col_name
                value_part = value_part + ", " + str(col_val)

        sql = sql + ") " + value_part + ")"
        return sql
    
    @staticmethod
    def __add_equal_condition(equal_conditions: list = None):
        """equal_conditions = [["JOB_ID", 101], ["Status", "Done"]] ->  returns JOB_ID=101 and Status='Done'\n
        Currently not support for Date
        """

        if (equal_conditions == None):
            return ""
        
        sql = " "
        for idx, data in enumerate(equal_conditions):
            col_name = data[0]
            col_val = data[1]

            if (type(col_val) == str):
                col_val = "'" + col_val + "'"

            sql = sql + " {}={}".format(col_name, col_val)

            if (idx < len(equal_conditions) - 1):
                sql = sql + " AND "

        return sql
            
    @staticmethod
    def insert_lab_high_risk(rows: list, date_time: str = None):
        print("DB : Inserting | Lab High Risk Data | {}... | count = {}".format(
                                                                            DB_TABLE.LAB_HIGH_RISK.value, 
                                                                            len(rows)), 
                                                                        end="")
                
        sql1 = """insert into {}
                    (LABID, HOSTNAME, HOSTNAME_IP, OUT_ACL, ACTUAL_ACL, UDP_RISK_PORT, TCP_RISK_PORT, 
                        ANY_ANY, IP_SUBNET, START_IP_INT, END_IP_INT)
                    values(:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11)
                    """.format(DB_TABLE.LAB_HIGH_RISK.value)
        column_list = ["LABID", "HOSTNAME", "HOSTNAME_IP","OUT_ACL", "ACTUAL_ACL", "UDP_RISK_PORT", 
                            "TCP_RISK_PORT", "ANY_ANY", "IP_SUBNET", "START_IP_INT", "END_IP_INT"]
        sql = DB.__get_sql_insert_query(DB_TABLE.LAB_HIGH_RISK.value, column_list)
        # print(sql)
        try:
            DB.__cursor.executemany(sql, rows)
            print(" | Inserted")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Lab High Risk Data couldn't be Inserted \n" + str(e))

    @staticmethod
    def get_input_from_pia_for_lab_high_risk():
        print("DB : Fetching inputs from PIA master table | {}...".format(DB_TABLE.PIA_MASTER_DATE.value), end="")
        try:
            lhr_input = []
            sql = """select distinct lab_id, host_name, host_ip, out_acl from {} 
                        where forwarding_lab like '%ss-dmzlab%' 
                        and LAST_UPDATED_ON=(select max(LAST_UPDATED_ON) from {})
                """.format(DB_TABLE.PIA_MASTER_DATE.value, DB_TABLE.PIA_MASTER_DATE.value)
            # print(sql)
            DB.__cursor.execute(sql)
            
            rows = DB.__cursor.fetchall()
            for row in rows:
                lhr_input.append([row[0], row[1], row[2], row[3]])

            print(" | Count :  " + str(len(lhr_input)))
            return lhr_input
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Inputs details couldn't be fetched \n" + str(e))

    # newly added
    @staticmethod
    def segregate_subnet(job_id: int):
        print("DB : Segrigating data from Clean Data Table | {}...".format(DB_TABLE.ANOMALY_CLEAN_DATA.value), end="")
        def updatedbysql(sql, params):
            try:
                DB.__cursor.execute(sql, params)
                print(" | Updated: Count = {}".format(DB.__cursor.rowcount))
            except Exception as e:
                DB.__connection.rollback()  # Rollback changes in case of an error
                print(" | Error:", str(e))

        sql = DB.__LAB_ROUTE_SUBNET_CLEAN
        # print(sql)
        params = {'job_id': job_id}
        DB.__cursor.execute(sql, params)
        rows = DB.__cursor.fetchall()

        for row in rows:
            lab_id = row[0]
            host_name = row[1]
            interface = row[2]
            subnet_list = str(row[3])

            # Use NetWork_Util.getparentsubnets to get the filtered and other subnets
            # print('before')
            filtered_subnets, other_subnets = NetWork_Util.getparentsubnets(subnet_list)
            # print('filtered_subnets- \t', filtered_subnets)
            # print('after')

            # Build the SQL query with placeholders to avoid SQL injection
            sql = DB.__UPDATE_CLEAN_DATA_SUBNETS

            params = {'filtered_subnets' : filtered_subnets,
                      'other_subnets' : other_subnets,
                      'job_id' : job_id,
                      'lab_id' : lab_id,
                      'host_name' : host_name,
                      'interface' : interface}

            # Execute the SQL query with parameters
            updatedbysql(sql, params)

    @staticmethod
    def truncate_table(table_name: DB_TABLE):
        print("DB : Truncate | {}...".format(table_name.value), end="")
        sql = "truncate table " + table_name.value
        try:
            # DB.__cursor.execute(sql)
            """Newly added"""
            DB.__cursor.execute(sql)
            print(" | Done")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Couldn't truncate the table.\nValue: {}\n{}".format(table_name.value, str(e)))

    @staticmethod
    def update_lab_high_risk_with_esp_ip_network():
        print("DB : updating {} by comparing T_ESP_IP_NETWORK...".format(DB_TABLE.LAB_HIGH_RISK.value), end="")
        sql = """
            update {} A set  CISCO_IP_SUBNET_YN = 'Y'
                where 
                    A.START_IP_INT >0
	                AND RECORD_ID IN (SELECT DISTINCT RECORD_ID 
                                        FROM  {} B, T_ESP_IP_NETWORK C 
                                        WHERE 
						                B.START_IP_INT >= C.START_IP_INT AND B.END_IP_INT<=C.END_IP_INT
                                    )
        """.format(DB_TABLE.LAB_HIGH_RISK.value, DB_TABLE.LAB_HIGH_RISK.value)
        # print(sql)     
        try:
            DB.__cursor.execute(sql)
            print(" | Updated: Count = {}".format(DB.__cursor.rowcount))
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : {} couldn't be updated \n {}".format(DB_TABLE.LAB_HIGH_RISK.value, str(e)))            
    
    @staticmethod
    def __in_db_insert_for_anomaly(anomaly_type: Anomaly_Type, job_id: int, from_table: DB_TABLE, to_table: DB_TABLE):
        print(f"DB : Job_ID = {job_id} | IN_DB_INSERT | Anomaly: {anomaly_type.value} | {from_table.value} to {to_table.value}...", end="")
        
        sql = ""
        if (anomaly_type == Anomaly_Type.PIA_OVERLAPPING_SUBNET):
            sql = DB.__OVERLAPPING
        elif (anomaly_type == Anomaly_Type.WITH_OUT_NEXTHOP):
            sql = DB.__WITHOUT_NEXTHOP
        elif (anomaly_type == Anomaly_Type.NO_VRF):
            sql = DB.__NO_VRF

        try:
            # print(sql)
            DB.__cursor.execute(sql, job_id=job_id)
            print(f" | Inserted: Count = {DB.__cursor.rowcount}")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Couldn't be inserted \n {str(e)}")
    @staticmethod
    def insert_clean_data_table(job_id: int, from_table: DB_TABLE, to_table: DB_TABLE):
        print(f"DB : Job_ID = {job_id} | IN_DB_INSERT | {from_table.value} to {to_table.value}...", end="")
        sql = ""
        if to_table == DB_TABLE.ANOMALY_CLEAN_DATA:
            sql = DB.__INSERT_TO_CLEAN_DATA

        try:
            # print(sql)
            DB.__cursor.execute(sql, job_id=job_id)
            print(f" | Inserted: Count = {DB.__cursor.rowcount}")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Couldn't be inserted \n {str(e)}")
    @staticmethod
    def delete_from_anomaly(anomaly_type: Anomaly_Type, job_id: int, criteria_list = None):
        """
        Newly Added.
        to delete particular entries form Anomaly table where criteria_list satisfy.
        """
        try:
            if criteria_list != None:
                for criteria in criteria_list:
                    # Execute the query with named parameters
                    if anomaly_type == Anomaly_Type.NO_VRF:
                        # Create a dictionary with named parameters
                        parameters = {
                            'job_id': job_id,
                            'anomaly_type': Anomaly_Type.NO_VRF.value,
                            'data_center': criteria[0],
                            'lab_id': criteria[1],
                            'gateway': criteria[2],
                            'interface': criteria[3],
                            'lab_sub_type': criteria[4],
                            'lab_state': criteria[5]
                        }
                        # print("SQL Query:", DB.__DELETE_FROM_NO_VRF)
                        # print("Parameters:", parameters)
                        DB.__cursor.execute(DB.__DELETE_FROM_NO_VRF, parameters)
                        print(" | NO VRF columns deleted successfully.")
                    if anomaly_type == Anomaly_Type.GLOBALOUT:
                        # Create a dictionary with named parameters
                        parameters = {
                            'job_id': job_id,
                            'anomaly_type': Anomaly_Type.GLOBALOUT.value,
                            'data_center': criteria[0],
                            'gateway': criteria[1],
                            'gateway_ip': criteria[2],
                            'interface': criteria[3],
                            'interface_ip': criteria[4],
                        }
                        # print("SQL Query:", DB.__DELETE_FROM_GLOBALOUT)
                        # print("Parameters:", parameters)
                        DB.__cursor.execute(DB.__DELETE_FROM_GLOBALOUT, parameters)
                        print(" | GLOBALOUT columns deleted successfully.")
            elif (criteria_list == None):
                if anomaly_type == Anomaly_Type.PIA_OVERLAPPING_SUBNET:
                    # print('inside else.')
                    # Create a dictionary with named parameters
                    parameters = {
                        'job_id': job_id,
                        'anomaly_type': Anomaly_Type.GLOBALOUT.value
                    }
                    # print("SQL Query:", DB.__DELETE_FROM_PIA_OVERLAPPING_SUBNET)
                    # print("Parameters:", parameters)
                    DB.__cursor.execute(DB.__DELETE_FROM_PIA_OVERLAPPING_SUBNET, parameters)
                    print(" | PIA_OVERLAPPING_SUBNET columns deleted successfully.")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Error while deleting the unnecessary {anomaly_type} data.\n{str(e)}")

    # @staticmethod
    # @deprecated(value = "")
    # def update_dc(table_name: Anomaly_Type, job_ID: int):
    #     sql = ""
    #     if (table_name == Anomaly_Type.PIA_MASTER_NOT_A_ANOMALY):
    #         sql = DB.__PIA_UPDATE_DC.format(DB_TABLE.PIA_MASTER_DATE.value, DB_TABLE.HOST_INFO.value)
    #     elif (table_name == Anomaly_Type.PIA_DMZ_INACL):
    #         sql = DB.__PIA_DMZ_INACL_ANOMALY.format(DB_TABLE.ANOMALY.value, DB_TABLE.HOST_INFO.value, Anomaly_Type.PIA_DMZ_INACL.value)
    #
    #     print(sql)

    @staticmethod
    def move_data_from_main_to_history(from_table: DB_TABLE, to_table: DB_TABLE, job_id: int):
        print(f"DB : Job_ID = {job_id} | Moving data | {from_table.value} to {to_table.value}...", end="")

        cols = []
        if (from_table == DB_TABLE.PIA_MASTER_DATE and to_table == DB_TABLE.PIA_MASTER_DATE_HISTORY):
            cols = DB.MASTER_DATE_COLUMNS_WITH_TAG
        elif (from_table == DB_TABLE.ANOMALY and to_table == DB_TABLE.ANOMALY_HISTORY):
            cols = DB.ANOMALY_DATA_COLUMNS_WITH_TAG
        elif (from_table == DB_TABLE.ANOMALY_CLEAN_DATA and to_table == DB_TABLE.ANOMALY_CLEAN_DATA_HISTORY):
            cols = DB.ANOMALY_CLEAN_DATA_COLUMNS_TAG
        try:
            cols_str = ", ".join(cols) + ", JOB_ID"
            sql = DB.__INSERT_MAIN_TO_HISTORY_TABLE.format(to_table.value, cols_str, cols_str, from_table.value)
            # print(sql)
            DB.__cursor.execute(sql, job_id=job_id-1)
            print(f" | Moved: Count = {DB.__cursor.rowcount}")
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Couldn't be moved \n {str(e)}")
         

    @staticmethod
    def get_ips_token():
        """It will return Basic token for IPS gen username and password
        """

        print("DB : Fetching detail for ISP...", end="")
        try:
            json_str = None
            sql = "select CONFIG_JSON from T_ISP_APP_CONFIG where config_name='ISPUSER.GEN_AD_INFO'"
            DB.__cursor.execute(sql)
            data = DB.__cursor.fetchall()
            for row in data:
                json_str = row[0]

            if (len(data) > 1):
                raise DB_Exception("DB Error : Got more rows for ISP token.\n" + str(e))
            print(" | Fetched")

            json_object = json.loads(json_str)
            return DB.get_basic_token(json_object["AD_USER"], json_object["AD_PASSWORD"])
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception("DB Error : Error for getting credential.\n"+str(e))

    @staticmethod
    def get_basic_token(username: str, password: str):
        """It will return token with Basic type"""

        if username is None or password is None:
            raise DB_Exception("Token Error: Username and password cannot be empty.")

        try:
            token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
            return f'Basic {token}'
        except Exception as e:
            print("Error:", e)
            traceback.print_exc()
            raise DB_Exception("Token Error: Error occurred while creating token.")

    @staticmethod
    def delete_all_data_from_main_tables():
        """This will truncate data from tables.\n
        T_SRT_PIA_HOST_REPORT\n
        T_SRT_PIA_ANOMALY\n
        PIA_SUBNET_WITH_LAB\n
        T_SRT_LAB_HIGH_RISK_SERVICE_DATA"""

        DB.truncate_table(DB_TABLE.PIA_MASTER_DATE)
        DB.truncate_table(DB_TABLE.ANOMALY)
        DB.truncate_table(DB_TABLE.PIA_SUBNET_WITH_LAB)
        DB.truncate_table(DB_TABLE.LAB_HIGH_RISK)
        DB.truncate_table(DB_TABLE.ANOMALY_CLEAN_DATA)

    @staticmethod
    def update_tag_col(row_tag: Row_Tag, job_id: int, table: DB_TABLE, anomaly: Anomaly_Type = None):
        """Specify the Anomaly_Type as 'NO_VRF' for 'NO VRF' only.\n
        If Anomaly.ALL, then it will ignore 'NO_VRF', 'DMZ_INACL_TEMPLATE', 'SAME_SUBNET_MULTIPLE_LAB' and
        'PIA_OVERLAPPING_SUBNET'.\n
        SAME_SUBNET_MULTIPLE_LAB will not required tag column as of now
        """        
        
        print(f"DB : Job_ID = {job_id} |  Updating tag column | {row_tag.name} | {table.value}", end="")
        
        sql = ''
        if (row_tag == Row_Tag.CLEAN_AND_NOT_CLEAN):
            sql = DB.__UPDATE_CLEAN_TAG_FOR_MASTER_DATA
        elif (row_tag == Row_Tag.LAB_STATE_AND_SUB_TYPE):
            sql = DB.__UPDATE_LAB_STATE_AND_SUB_TYPE

            filter_part = """and B.Lab_state not in ('Decommissioned', 'Auto-Decommissioned', 'Deactivated') 
                            and B.LAB_SUB_TYPE not in ({})"""
            filter_part2 = """and B.Lab_state not in ('Decommissioned', 'Auto-Decommissioned', 'Deactivated') 
                            and B.LAB_SUB_TYPE in ({})"""
            filter = "'CCI', 'R-DMZ', 'CIBB', 'Partner Labs'"
            filter_with_virtual_lab = "'CCI', 'R-DMZ', 'CIBB', 'Partner Labs', 'Virtual DMZ', 'Virtual DMZaaS'"
            filter_with_DMZ = "'DMZ Segmented', 'DMZaaS Segmented', 'DMZaaS', 'DMZ'"

            # if (anomaly != None and anomaly == Anomaly_Type.NO_VRF or anomaly == Anomaly_Type.DMZ_TEMPLATE_ACL):
            # newly added
            if (anomaly != None and anomaly == Anomaly_Type.NO_VRF):
                print(f" | {anomaly.value}", end="")

                filter = filter_with_virtual_lab
                sql = sql + f" and ANOMALY_TYPE = '{anomaly.value}'"
                filter_part = filter_part.format(filter_with_virtual_lab)

            # Newly Added
            elif (anomaly != None and anomaly == Anomaly_Type.DMZ_TEMPLATE_ACL):
                print(f" | {anomaly.value}", end="")

                sql = sql + f" and ANOMALY_TYPE = '{anomaly.value}'"
                filter_part = filter_part2.format(filter_with_DMZ)


            elif (anomaly != None and anomaly == Anomaly_Type.ALL):
                print(f" | {anomaly.value} (exluding 4 anomaly)", end="")

                sql = sql + f""" and ANOMALY_TYPE not in ('{Anomaly_Type.NO_VRF.value}', 
                                                            '{Anomaly_Type.DMZ_TEMPLATE_ACL.value}', 
                                                            '{Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB.value}', 
                                                            '{Anomaly_Type.PIA_OVERLAPPING_SUBNET.value}'
                                                        )"""
                filter_part = filter_part.format(filter)
            elif (table == DB_TABLE.PIA_MASTER_DATE):
                filter_part = ""


            sql = sql.format(table.value, DB_TABLE.LRT_LAB_OWNER.value, filter_part)
        elif (row_tag == Row_Tag.LAB_SUB_TYPE and anomaly == Anomaly_Type.PIA_OVERLAPPING_SUBNET):
            print(f" | {anomaly.value}", end="")
            sql =  DB.__UPDATE_LAB_SUB_TYPE_FOR_OVERLAPPING
        else:
            print(f" | Row Tag is not valid. Value: {row_tag}")
            return
        
        try:
            # print(sql)
            DB.__cursor.execute(sql, job_id = job_id)
            print(f" | Updated: Count = {DB.__cursor.rowcount}")
        except :
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Could't update the column.\n{str(e)}")

      
    @staticmethod
    def execudbproc():
        DB.__cursor.callproc("SP_SRT_PIA_CLEAN")
        print("DB PROCEDURE SP_SRT_PIA_CLEAN executed")

    @staticmethod
    def execudbproc_main():
        DB.__cursor.callproc("SP_SRT_PIA_MAIN")
        print("DB PROCEDURE SP_SRT_PIA_MAIN executed")

    @staticmethod
    def execudbproc_main_temp():
        DB.__cursor.callproc("SP_SRT_PIA_MAIN_TEMP")
        print("DB PROCEDURE SP_SRT_PIA_MAIN executed")

    @staticmethod
    def execudbproc_main_to_history():
        DB.__cursor.callproc("SP_SRT_PIA_MAIN_TO_HISTORY")
        print("DB PROCEDURE SP_SRT_PIA_MAIN_TO_HISTORY executed")

    @staticmethod
    def delete_row_by_lab_tags(table: DB_TABLE, job_id: int):
        print(f"DB : Job_ID = {job_id} |  Deleting row | tag: (LAB_STATE, LAB_SUB_TYPE) on {table.value}", end="")
        try:
            sql = DB.__DELETE_ROW_BY_LAB_TAGS.format(table.value)
            # print(sql)
            DB.__cursor.execute(sql, job_id = job_id)
            print(f" | Deleted: Count = {DB.__cursor.rowcount}")
        except :
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Could't delete the rows.\n{str(e)}")
        
    @staticmethod
    def get_data_from_db(table: DB_TABLE, job_id: int, anomaly_type: Anomaly_Type = None):
        print(f"DB : Job_ID = {job_id} ", end="")
        sql = ""
        if (table == DB_TABLE.PIA_MASTER_DATE_TEMP):
            print(f"|  Fetching data from {table.value}", end="")
            sql = DB.__SELECT_QUERY.format(', '.join(DB.MASTER_DATE_COLUMNS_WITH_TAG), table.value)
        elif (table == DB_TABLE.ANOMALY):
            print(f"|  Fetching {anomaly_type.value} from {table.value}", end="")
            cols_str = ""
            if (anomaly_type == Anomaly_Type.NO_VRF):
                cols_str = ', '.join(DB.NO_VRF_COLUMNS)
            elif (anomaly_type == Anomaly_Type.WITH_OUT_NEXTHOP):
                cols_str = ', '.join(DB.WITHOUT_NEXtHOP_COLUMNS)
            elif (anomaly_type == Anomaly_Type.PIA_OVERLAPPING_SUBNET):
                cols_str = ', '.join(DB.OVERLAPPING_COLUMNS)
            elif (anomaly_type == Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB):
                cols_str = ', '.join(DB.SAM_SUBNET_MULTIPLE_LAB_COLUMNS)
            elif (anomaly_type == Anomaly_Type.PIA_DMZ_INACL):
                cols_str = ', '.join(DB.DMZ_INACL_COLUMNS)
            elif (anomaly_type == Anomaly_Type.DMZ_TEMPLATE_ACL):
                cols_str = ', '.join(DB.DMZ_TEMPLATE_ACL_COLUMNS)
            elif (anomaly_type == Anomaly_Type.GLOBALOUT):
                cols_str = ', '.join(DB.GLOBALOUT_COLUMNS)
            elif (anomaly_type == Anomaly_Type.VRF_OFFRAMP):
                cols_str = ', '.join(DB.VRF_OFFRAMP_COLUMNS)

            sql = DB.__SELECT_QUERY.format(cols_str, table.value)
            # Newly added.
            if (
                    anomaly_type.value != 'Overlapping Subnet' and
                    anomaly_type.value != 'Subnets Routed in Multiple Labs' and
                    anomaly_type.value != 'Uplink ACL Control' and
                    anomaly_type.value != 'Lab-lenient ACL control'
            ):
                sql = sql + " AND " + DB.__add_equal_condition(
                    [["ANOMALY_TYPE", anomaly_type.value]]) + " AND lab_sub_type IS NOT NULL"
            else:
                sql = sql + " AND " + DB.__add_equal_condition([["ANOMALY_TYPE", anomaly_type.value]])
        elif (table == DB_TABLE.ANOMALY_CLEAN_DATA):
            # print(f'--------------------inside else condition: {table}------------------------------')
            cols_str = ', '.join(DB.ANOMALY_CLEAN_DATA_COLUMNS)
            sql = DB.__SELECT_QUERY.format(cols_str, table.value)
            # print('sql:\t', sql)
            # print('--------------------------------------------------')
        try:
            # print('-----------------------inside the try block---------------------')
            # print("\n", sql, '\n')
            DB.__cursor.execute(sql, job_id = job_id)
            row = DB.__cursor.fetchall()
            print(f" | Count = {len(row)}")
            return row
        except:
            print(" | Error")
            e = traceback.format_exc()
            raise DB_Exception(f"DB Error : Could't be fetched.\n{str(e)}")

    @staticmethod
    def execute_sql_query(sql):
        try:
            if DB.__connection is None:
                raise DB_Exception("DB Error: Database connection is not initialized.")

            # Use the provided SQL query and the existing database connection
            df = pd.read_sql_query(sql, DB.__connection)
            return df
        except Exception as e:
            # Handle exceptions here or re-raise as needed
            raise DB_Exception("DB Error: SQL query execution failed.\n" + str(e))

    @staticmethod
    def get_data_from_anomaly_table(job_id: int, anomaly_type: List):
        print("DB: Job_ID = {} | Fetching | Anomaly: {} | {}... ".format(
            job_id,
            anomaly_type,
            DB_TABLE.ANOMALY.value),
            end="")
        try:
            # Construct the SQL query with proper formatting
            anomaly_type_str = ','.join([f"'{t}'" for t in anomaly_type])
            sql = f'select * from {DB_TABLE.ANOMALY.value} where JOB_ID=:job_id'
            sql += f" AND ANOMALY_TYPE IN ({anomaly_type_str})"
        except Exception as e:
            print(" | Error")
            traceback.print_exc()
            raise DB_Exception("Get Anomaly Error: Anomaly details couldn't be fetched\n" + str(e))

        df = DB.execute_sql_query(sql)
        return df

    @staticmethod
    def close_db_conn():
        DB.__close_resource(DB.__cursor)
        DB.__close_resource(DB.__connection)
        print("\nDB: Connection closed")

    @staticmethod
    def __close_resource(obj: object):
        if (obj != None):
            try:
                obj.close()
            except:
                pass

    MASTER_DATE_COLUMNS_WITH_TAG = [ "DC", "LAB_ID", "HOST_NAME", "HOST_IP", "INTERFACE", "INTERFACE_IP", "DESCRIPTION", "FORWARDING_LAB",
                                    "LAB_ROUTE_SUBNET", "IN_ACL", "OUT_ACL", "NEXT_HOP", "DATA_STATE",
                                    "LAB_STATE", "LAB_SUB_TYPE"]

    SAM_SUBNET_MULTIPLE_LAB_COLUMNS = ["DATA_CENTER", "LAB_ID", "SUBNET","LAB_SUB_TYPE","LAB_STATE"]

    OVERLAPPING_COLUMNS = ["SUBNET", "LAB_ID", "LAB_SUB_TYPE", "DATA_CENTER", "CHILD_SUBNET", "CHILD_LAB_ID", "LAB_SUB_TYPE2", "CHILD_DC", "REMARKS"]

    WITHOUT_NEXtHOP_COLUMNS = ["DATA_CENTER", "LAB_ID", "GATEWAY", "GATEWAY_IP", "INTERFACE", "INTERFACE_IP", "FORWARD_INFO", "IN_ACL",
                       "OUT_ACL", "SUBNET", "LAB_SUB_TYPE", "LAB_STATE"]

    NO_VRF_COLUMNS = ["DATA_CENTER", "LAB_ID", "GATEWAY", "INTERFACE", "LAB_SUB_TYPE", "LAB_STATE"]

    DMZ_INACL_COLUMNS = ["DATA_CENTER", "LAB_ID", "GATEWAY", "IN_ACL", "RAW_ACL_LINE", "LAB_SUB_TYPE", "LAB_STATE"]

    DMZ_TEMPLATE_ACL_COLUMNS = ["DATA_CENTER", "LAB_ID", "IN_ACL", "OUT_ACL", "GATEWAY", "LAB_SUB_TYPE", "LAB_STATE"]

    ANOMALY_DATA_COLUMNS_WITH_TAG = ["DATA_CENTER", "LAB_ID", "GATEWAY", "GATEWAY_IP", "INTERFACE", "INTERFACE_IP", "ANOMALY_TYPE", "SUBNET",
                                       "IN_ACL", "OUT_ACL", "RAW_ACL_LINE", "CHILD_LAB_ID", "CHILD_SUBNET", "REMARKS",
                                       "FORWARD_INFO", "CHILD_DC", "LAB_SUB_TYPE", "LAB_STATE"]

    VRF_OFFRAMP_COLUMNS  =["DATA_CENTER", "GATEWAY", "GATEWAY_IP", "GATEWAY2", "GATEWAY2_IP", "INTERFACE", "INTERFACE_IP", "FORWARD_INFO", "OUT_ACL"]

    GLOBALOUT_COLUMNS = ["DATA_CENTER", "GATEWAY", "GATEWAY_IP", "INTERFACE", "INTERFACE_IP", "FORWARD_INFO", "OUT_ACL"]

    ANOMALY_CLEAN_DATA_COLUMNS = ["LAB_ID",	"HOST_NAME", "INTERFACE", "INTERFACE_IP", "LAB_ROUTE_SUBNET", "NEXT_HOP_OLD",
                                  "HOST_IP", "DESCRIPTION", "FORWARDING_LAB", "LAST_UPDATED_ON", "IN_ACL", "OUT_ACL",
                                  "DC", "NEXT_HOP", "JOB_ID", "DATA_STATE", "LAB_STATE", "LAB_SUB_TYPE",
                                  "DATA_STAT_FINAL", "UPLINK_SUBNET", "LAB_ROUTE_SUBNET_CLEAN"]

    ANOMALY_CLEAN_DATA_COLUMNS_TAG = ["LAB_ID", "HOST_NAME", "INTERFACE", "INTERFACE_IP", "LAB_ROUTE_SUBNET",
                                  "NEXT_HOP_OLD", "HOST_IP", "DESCRIPTION", "FORWARDING_LAB", "LAST_UPDATED_ON",
                                      "IN_ACL", "OUT_ACL", "DC", "NEXT_HOP", "DATA_STATE", "LAB_STATE", "LAB_SUB_TYPE",
                                      "DATA_STAT_FINAL", "UPLINK_SUBNET",
                                      "LAB_ROUTE_SUBNET_CLEAN"]

    __SELECT_QUERY = "SELECT {} FROM {} WHERE JOB_ID=:job_id"

    __PIA_UPDATE_DC = """
                        update {} A 
                        set DC = (select DC from {} B where B.HOSTNAME=A.HOST_NAME)
                        where JOB_ID = :1
                    """

    __WITHOUT_NEXTHOP = f"""
                        insert into {DB_TABLE.ANOMALY.value}(Data_center, Lab_ID, gateway, gateway_ip, interface, interface_ip, 
                            forward_info, in_acl, out_acl, subnet, ANOMALY_TYPE, job_id) 
                        (select DC, Lab_ID, host_name, host_ip, interface, interface_ip, forwarding_lab, in_acl, out_acl, 
                            lab_route_subnet, '{Anomaly_Type.WITH_OUT_NEXTHOP.value}', job_id 
                            from {DB_TABLE.PIA_MASTER_DATE.value} 
                            where job_id=:job_id and forwarding_lab is not null and NEXT_HOP is null
                        )
                    """
    
    __NO_VRF = f"""
                insert into {DB_TABLE.ANOMALY.value}(Data_center, Lab_ID, gateway, gateway_ip, interface, interface_ip,
                    ANOMALY_TYPE, job_id) 
                (select DC, Lab_ID, host_name, host_ip, interface, interface_ip, '{Anomaly_Type.NO_VRF.value}', job_id 
                    from {DB_TABLE.PIA_MASTER_DATE.value} 
                    where job_id=:job_id and forwarding_lab is null
                )
            """

    __DELETE_FROM_NO_VRF = f"""
        DELETE FROM {DB_TABLE.ANOMALY.value}
        WHERE 
            job_id = :job_id
            AND Anomaly_type = :anomaly_type
            AND Data_center = :data_center
            AND lab_id = :lab_id
            AND gateway = :gateway
            AND interface = :interface
            AND lab_sub_type = :lab_sub_type
            AND lab_state = :lab_state
    """

    __DELETE_FROM_GLOBALOUT = f"""
        DELETE FROM {DB_TABLE.ANOMALY.value}
        WHERE
            job_id = :job_id
            AND ANOMALY_TYPE = :anomaly_type
            AND Data_center = :data_center
            AND GATEWAY = :gateway
            AND GATEWAY_IP = :gateway_ip
            AND INTERFACE = :interface
            AND INTERFACE_IP = :interface_ip
    """

    __DELETE_FROM_PIA_OVERLAPPING_SUBNET = f"""
        DELETE FROM {DB_TABLE.ANOMALY.value}
        WHERE
            job_id = :job_id
            AND ANOMALY_TYPE = :anomaly_type
            AND LAB_SUB_TYPE = 'CCI'
            AND LAB_SUB_TYPE2 IN ('CCI', 'CIBB', 'CCI-Lab')
    """

    __PIA_DMZ_INACL_ANOMALY = """
                                update {} A set data_center=(select dc from {} B where A.GATEWAY=B.HOSTNAME) 
                                where A.ANOMALY_TYPE = '{}' and job_id = :job_id
                            """
    
    __INSERT_MAIN_TO_HISTORY_TABLE  = """
                                    insert into {}({}) (select {} from {} where job_id=:job_id)
                                """
    
    __LATEST_JOB_ID = f"""
                        select JOB_ID from {DB_TABLE.SCRIPT_AUDIT.value} 
                        where 
                            RUN_DATE = (select max(RUN_DATE) from {DB_TABLE.SCRIPT_AUDIT.value} where SCRIPT_NAME = :script_name) 
                            and SCRIPT_NAME = :script_name 
                            and STATUS = '{Script_State.DONE.value}'
                    """
    
    __OVERLAPPING = f"""
                    INSERT INTO {DB_TABLE.ANOMALY.value}(
                                SUBNET, LAB_ID, DATA_CENTER, CHILD_SUBNET, CHILD_LAB_ID, CHILD_DC, REMARKS, ANOMALY_TYPE, JOB_ID)
                    (select B.SUBNET, B.LAB_ID_LIST, B.DC, A.SUBNET, A.LAB_ID_LIST, A.DC,
                        CAST(B.SUBNET as varchar(30)) || ' of ' || B.LAB_ID_LIST || ' is overlaping ' || CAST(A.SUBNET as varchar(30)) || ' of ' || A.LAB_ID_LIST,
                        '{Anomaly_Type.PIA_OVERLAPPING_SUBNET.value}', B.JOB_ID
                        from {DB_TABLE.PIA_SUBNET_WITH_LAB.value} A, {DB_TABLE.PIA_SUBNET_WITH_LAB.value} B 
                        where A.job_id=:job_id and B.job_id=A.job_id 
                        AND A.SUBNET != B.SUBNET 
                        AND A.SUBNET NOT LIKE '%/32%'
                        AND A.LAB_ID_LIST NOT LIKE '%,%' AND B.LAB_ID_LIST NOT LIKE '%,%'
                        AND A.LAB_ID_LIST != B.LAB_ID_LIST
                        AND A.END_IP_RANGE-A.START_IP_RANGE<B.END_IP_RANGE-B.START_IP_RANGE
                        and (A.START_IP_RANGE between B.START_IP_RANGE and B.END_IP_RANGE OR A.END_IP_RANGE between B.START_IP_RANGE and B.END_IP_RANGE)
                    )
                """
    
    __UPDATE_CLEAN_TAG_FOR_MASTER_DATA = f"""
                                update {DB_TABLE.PIA_MASTER_DATE.value} set data_state='Clean'
                                where
                                job_id=:job_id
                                and
                                lab_id not in (
                                    select distinct A.lab_id from {DB_TABLE.PIA_MASTER_DATE.value} A , {DB_TABLE.ANOMALY.value} B
                                    where A.job_id=:job_id  and  A.job_id=B.job_id
                                    and (B.lab_id like '%' ||  A.lab_id || '%'
                                    or B.child_lab_id like '%' || A.lab_id || '%')
                                )
                            """

    
    __UPDATE_LAB_STATE_AND_SUB_TYPE = """
                                    update {} A 
                                    SET 
                                    (A.lab_state, A.lab_sub_type) = (select B.LAB_STATE, B.LAB_SUB_TYPE from  {} B
                                                                        where A.LAB_ID=B.LAB_ID 
                                                                        {}
                                                                        ) 
                                    where A.JOB_ID=:job_id
                                """
    
    __UPDATE_LAB_SUB_TYPE_FOR_OVERLAPPING = f"""
                                            update {DB_TABLE.ANOMALY.value} A 
                                            SET 
                                            A.lab_sub_type = (select B.LAB_SUB_TYPE from  {DB_TABLE.LRT_LAB_OWNER.value} B
                                                            where A.LAB_ID=B.LAB_ID 
                                                            ),
                                            A.lab_sub_type2 = (select B.LAB_SUB_TYPE from  {DB_TABLE.LRT_LAB_OWNER.value} B
                                                            where A.CHILD_LAB_ID=B.LAB_ID 
                                                            ) 
                                            where A.JOB_ID=:job_id
                                            and A.ANOMALY_TYPE='{Anomaly_Type.PIA_OVERLAPPING_SUBNET.value}'
                                        """
    
    __DELETE_ROW_BY_LAB_TAGS = """
                            delete from {} A where A.JOB_ID=:job_id and A.lab_state is null and A.lab_sub_type is null
                        """

    __INSERT_TO_CLEAN_DATA = f"""INSERT INTO {DB_TABLE.ANOMALY_CLEAN_DATA.value} 
    (LAB_ID, HOST_NAME, INTERFACE, INTERFACE_IP, LAB_ROUTE_SUBNET, NEXT_HOP_OLD, HOST_IP, DESCRIPTION, FORWARDING_LAB,
     LAST_UPDATED_ON, IN_ACL, OUT_ACL, DC, NEXT_HOP, JOB_ID, DATA_STATE, LAB_STATE, LAB_SUB_TYPE,DATA_STAT_FINAL,
      UPLINK_SUBNET)
                        SELECT LAB_ID, HOST_NAME, INTERFACE, INTERFACE_IP, LAB_ROUTE_SUBNET, NEXT_HOP_OLD, HOST_IP,
                            DESCRIPTION, FORWARDING_LAB, LAST_UPDATED_ON, IN_ACL, OUT_ACL, DC, NEXT_HOP, JOB_ID,
                            DATA_STATE, LAB_STATE, LAB_SUB_TYPE, DATA_STAT_FINAL, UPLINK_SUBNET
                            FROM {DB_TABLE.PIA_MASTER_DATE_TEMP.value}
                            WHERE JOB_ID=:job_id AND DATA_STATE = 'PIA-Pass(Clean)'
                             or DATA_STATE = 'PIA - Pass(Clean)' 
                             or DATA_STATE = 'PIA -Pass(Clean)' 
                             or DATA_STATE = 'PIA- Pass(Clean)'
                        """

    __LAB_ROUTE_SUBNET_CLEAN = f"""
                            select LAB_ID,HOST_NAME,INTERFACE,LAB_ROUTE_SUBNET from {DB_TABLE.ANOMALY_CLEAN_DATA.value} where JOB_ID=:job_id
                        """

    __UPDATE_CLEAN_DATA_SUBNETS = f"""
        UPDATE {DB_TABLE.ANOMALY_CLEAN_DATA.value} 
        SET LAB_ROUTE_SUBNET_CLEAN=:filtered_subnets, UPLINK_SUBNET=:other_subnets 
        WHERE job_id=:job_id AND LAB_ID=:lab_id AND HOST_NAME=:host_name AND INTERFACE=:interface
    """

    __GET_PASSCRED = """
    SELECT json_value(config_json, '$.AD_PASSWORD') AS ad_password
    FROM T_ISP_APP_CONFIG where CONFIG_NAME = 'PIA_MAIN_CONFIG'
    """

    __GET_USERCRED = """
        SELECT json_value(config_json, '$.AD_USER') AS ad_user
        FROM T_ISP_APP_CONFIG where CONFIG_NAME = 'PIA_MAIN_CONFIG'
        """
    __GET_ENCRYPTED_PASSWORD = f"""
     SELECT ENCRYPTED_PASSWORD FROM  {DB_TABLE.PIA_PASSWORD_DB.value} WHERE USER_NAME = :username
    """

    @staticmethod
    def temp():
        import pandas as pd
        sql = 'SELECT DC, LAB_ID FROM T_SRT_PIA_HOST_REPORT WHERE JOB_ID=23'
        data = pd.read_sql(sql, DB.__connection)
        data.to_excel('my_oracle_table.xlsx')  #called before closing the connection
        
        
if __name__ == "__main__":
    try:
        DB.init_db()
        """
        DB.insert_master_report([["LRT0013827", "bgl12-00-lab-gw2", "10.64.55.29", "TenGigabitEthernet1/4",
                              "10.104.193.77", "description connected to 13827", "vrf forwarding ss-lab", "121", "122",
                              "10.104.180.0/24, 10.104.183.0/24, 10.104.188.0/24, 10.104.193.76/30, 10.104.193.78/32", 
                              "10.104.193.78"]])
        """
        # DB.insert_gw_process_status([["sjc-lag-gw1", "1.1.1.1", "Done"]])
        # print(len(DB.get_input_lab_gw()))
        a = ["LRT0011111","rtp1-lab-gw1","172.18.0.133","TenGigabitEthernet1/4",
                                  "192.133.195.253","vrf forwarding ss-dmzlab","RTP01LabID55892out",
                                  "permit tcp 12.130.27.0 0.0.0.255 192.133.195.252 0.0.0.3 eq telnet 443 www",
                                  "telnet","", "","12.130.27.0/24",209853184,209853439]
        # print(DB.get_input_lab_gw_with_dc(Script_Type.PIA))
        
        # print(DB.get_sql_insert_query("ABCD", ["A", "B", ""])+DB.add_equal_condition([["Name", "Apple"], ["ID", 101]]))
        # DB.delete_row_by_lab_tags(DB_TABLE.PIA_MASTER_DATE, 23)
        # DB.insert_anomaly(Anomaly_Type.WITH_OUT_NEXTHOP, None, 23)
        # print(DB.get_data_from_db(DB_TABLE.PIA_MASTER_DATE, 23)[0])
        # DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, 23, DB_TABLE.ANOMALY, Anomaly_Type.ALL)
        # DB.insert_anomaly(Anomaly_Type.DMZ_INACL_TEMPLATE, [["LABID", "INACL", "OUTACL", "GATEWAY"]], 123)
        # print( DB.get_job_id(Script_Type.PIA_DMZ_INACL_ANOMALY, Script_State.STARTED))
        # DB.move_data_from_main_to_history(DB_TABLE.PIA_MASTER_DATE, DB_TABLE.PIA_MASTER_DATE_HISTORY, 55)
        # DB.update_tag_col(Row_Tag.LAB_SUB_TYPE, 214, DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET)
        # DB.insert_anomaly(Anomaly_Type.SAME_SUBNET_MULTIPLE_LAB, [], 212)
        # DB.insert_anomaly(Anomaly_Type.NO_VRF, None, 212)
        # DB.add_tag(Row_Tag.LAB_STATE_AND_SUB_TYPE, 111, DB_TABLE.ANOMALY, Anomaly_Type.NO_VRF)
        # print(DB.get_data_from_db(DB_TABLE.ANOMALY, 214, Anomaly_Type.WITH_OUT_NEXTHOP))
        # DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, 121, DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET)  # Newly Added
        b = ["AER","LRT0031588","aer01-mda1-lab-gw1","10.115.4.37","TenGigabitEthernet1/4","173.38.209.201","description AER01 ETE | LRT0031588 | tnorling | 100Mbps","vrf forwarding ss-dmzlab","AER01LabID31588in","AER01LabID31588out","64.103.39.96/27, 173.38.209.200/30, 173.38.209.202/32","173.38.209.202"]
        # print(DB.update_tag_col(Row_Tag.LAB_SUB_TYPE, 197, DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET))
        # DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, 198, DB_TABLE.PIA_MASTER_DATE)
        # DB.temp()
        # DB.delete_from_anomaly(Anomaly_Type.GLOBALOUT,
        #                          216,
        #                          Delete_Data_criteria_list.GLOBALOUT_criteria_list.value)
        # DB.delete_from_anomaly(Anomaly_Type.PIA_OVERLAPPING_SUBNET,
        #                        216)
        # DB.delete_from_anomaly(Anomaly_Type.NO_VRF,
        #                        216,
        #                        Delete_Data_criteria_list.No_VRF_criteria_list.value)
        #DB.update_tag_col(Row_Tag.LAB_STATE_AND_SUB_TYPE, 216, DB_TABLE.ANOMALY, Anomaly_Type.PIA_OVERLAPPING_SUBNET)
        # DB.move_data_from_main_to_history(DB_TABLE.ANOMALY, DB_TABLE.ANOMALY_HISTORY, 248)
        # DB.move_data_from_main_to_history(DB_TABLE.ANOMALY_CLEAN_DATA, DB_TABLE.ANOMALY_CLEAN_DATA_HISTORY, 220)
        # DB.insert_clean_data_table(263, DB_TABLE.PIA_MASTER_DATE, DB_TABLE.ANOMALY_CLEAN_DATA)
        DB.segregate_subnet(343)
        DB.close_db_conn()
    except DB_Exception as ee:
        print(ee)
    except Exception as e:
        print(e)
