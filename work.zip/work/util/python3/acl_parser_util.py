import re, traceback
import multiprocessing

class Parse_Acl_Exception(Exception):
    def __init__(self, message):
        self.message = message
        super(Parse_Acl_Exception, self).__init__(self.message)

class ParseAcl:

    DEFAULT_TEMPLATE = {"permit udp any eq domain any", "permit udp any eq isakmp any", "permit udp any eq non500-isakmp any", 
                        "permit udp any any eq 500", "permit udp any eq 500 any", "permit udp any any eq 4500", 
                        "permit udp any eq 4500 any", "permit udp any any eq 10000", "permit tcp any any eq 10000", 
                        "Permit udp any eq 10000 any", "permit tcp any any established", "permit ip 171.70.168.128 0.0.0.63 any", 
                        "permit ip 171.68.226.64 0.0.0.63 any", "permit ip 64.102.6.128 0.0.0.63 any", 
                        "permit ip 173.38.14.64 0.0.0.63 any", "permit ip 173.38.43.0 0.0.0.63 any", 
                        "permit ip 173.36.131.0 0.0.0.63 any", "permit ip 171.71.180.192 0.0.0.63 any", 
                        "permit ip 64.102.12.32 0.0.0.31 any", "permit ip 64.102.14.224 0.0.0.31 any", 
                        "permit ip 144.254.221.64 0.0.0.31 any", "permit ip 64.104.200.64 0.0.0.15 any", 
                        "permit ip 64.102.121.248 0.0.0.7 any", "permit ip 64.104.140.32 0.0.0.15 any", 
                        "permit ip host 128.107.235.164 any"}

    IP_PATTERN = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
    # PORT_PATTERN = r'\d{1,5}'

    TCP_RISK_PORT = {1433, 3389, 25, 53, 21, 2049, 23, "smtp", "domain", "ftp", "telnet"}
    UDP_RISK_PORT = {1434, 53}
    
    def __init__(self, raw_acl_line):
        self.raw_acl_line = ""
        self.actual_acl = ""

        self.risk_port_is_found = False
        self.tcp_risk_port = []
        self.udp_risk_port = []
        self.any_any = ''

        self.operation = ""
        self.protocol = ""
        
        self.source_is_any = False
        self.source_host = ""
        self.source_subnet = ""
        self.source_ports = set()
        
        self.destination_is_any = False
        self.destination_host = ""
        self.destination_subnet = ""
        self.destination_ports = set()
        try:
            self.raw_acl_line = raw_acl_line
            
            start = self.raw_acl_line.index("permit")
            end = self.raw_acl_line.index("(") if "(" in self.raw_acl_line else len(self.raw_acl_line)
            self.actual_acl = self.raw_acl_line[start:end].strip()

            while ("\t" in raw_acl_line):
                raw_acl_line = raw_acl_line.replace("\t", " ")

            while ("  " in raw_acl_line):
                raw_acl_line = raw_acl_line.replace("  ", " ")

            next_idx = 1
            acl_parts = raw_acl_line.split(" ")
            self.operation = acl_parts[next_idx]
            next_idx = next_idx + 1
            self.protocol = acl_parts[next_idx]

            next_idx = next_idx + 1
            curr_word = acl_parts[next_idx]
            if (curr_word == "any"):
                self.source_is_any = True 
                self.source_host = "any"
            elif (curr_word == "host"):
                next_idx = next_idx + 1
                self.source_host = acl_parts[next_idx]
            else:
                if("/" in curr_word):
                    self.source_subnet = curr_word
                else:
                    if(self.patter_matches(ParseAcl.IP_PATTERN, acl_parts[next_idx+1])):
                        next_idx = next_idx + 1
                        self.source_subnet = curr_word + " " + acl_parts[next_idx]
            
            # check what is after source host whether it is port or destination
            next_idx = next_idx + 1
            if (next_idx < len(acl_parts)):
                curr_word = acl_parts[next_idx]
                if("range" == curr_word):
                    next_idx = next_idx + 1
                    port_start = int(acl_parts[next_idx])
                    next_idx = next_idx + 1
                    port_end = int(acl_parts[next_idx])

                    while(port_start <= port_end):
                        self.add_port(port_start, "forSource")
                        port_start = port_start + 1

                    next_idx = next_idx + 1
                elif("eq" == curr_word):
                    while(next_idx < len(acl_parts) - 1):
                        next_idx = next_idx + 1
                        curr_word = acl_parts[next_idx]
                        port_len = len(curr_word)
                        if (curr_word == "any" or curr_word == "host"):
                            break
                        elif (self.patter_matches(ParseAcl.IP_PATTERN, curr_word)):
                            break
                        elif(curr_word.isdigit() and port_len >=1 and port_len <=5):
                            self.add_port(int(curr_word), "forSource")
                        else:
                                self.source_ports.add(curr_word)
                    # next_idx = next_idx + 1            
                        
            # print(curr_word, next_idx, len(acl_parts))
            # destination ip
            #if (next_idx < len(acl_parts)):
            curr_word = acl_parts[next_idx]
            if ("(" not in curr_word):                
                if ("any" == curr_word):
                    self.destination_is_any = True
                    self.destination_host = "any"
                elif ("host" == curr_word):
                    next_idx = next_idx + 1
                    self.destination_host = acl_parts[next_idx]
                else:
                    if("/" in curr_word): # if is cidr
                        self.destination_subnet = curr_word
                    else:
                        next_idx = next_idx + 1                        
                        if (self.patter_matches(ParseAcl.IP_PATTERN, acl_parts[next_idx])):
                            self.destination_subnet =curr_word + " " + acl_parts[next_idx]
                            
                # destination port
                if(next_idx < len(acl_parts) - 1):
                    next_idx = next_idx + 1                
                    curr_word = acl_parts[next_idx]
                    if("range" == curr_word):
                        next_idx = next_idx + 1
                        port_start = int(acl_parts[next_idx])
                        next_idx = next_idx + 1
                        port_end = int(acl_parts[next_idx])
                        while(port_start <= port_end):
                            self.add_port(port_start, "forDestination")
                            port_start = port_start + 1
                            
                    elif(curr_word == "eq"):
                        while(next_idx < len(acl_parts) - 1):
                            next_idx = next_idx + 1
                            curr_word = acl_parts[next_idx]
                            port_len = len(curr_word)
                            if ("(" in curr_word):
                                break
                            if(curr_word.isdigit() and port_len >=1 and port_len <=5):
                                self.add_port(int(curr_word), "forDestination")                            
                            else:
                                self.destination_ports.add(curr_word)
                        # next_acl_word_pos = next_acl_word_pos + 1

            self.find_risk_port()
                    
        except:
            ex = str(traceback.format_exc())
            ex = str(self) + "\n" + ex
            raise Parse_Acl_Exception(ex)
                
    def add_port(self, port, scope):
		#int pp = port
        if(port>0):
            if (scope == "forSource"):
                if(port not in self.source_ports):
                    self.source_ports.add(port)
                    return True
            else:
                  if(port not in self.destination_ports):
                    self.destination_ports.add(port)
                    return True
        return False
    
    def patter_matches(self, pattern_txt, text):
        pattern = re.compile(pattern_txt)
        if(re.match(pattern, text)):
            return True
        return False
    
    def find_risk_port(self):
        if (self.actual_acl in ParseAcl.DEFAULT_TEMPLATE):            
            return


        if (len(self.destination_ports) == 0):
            if (self.protocol == "ip"):
                self.any_any = "any"
                self.risk_port_is_found = True
            elif ((self.protocol == "tcp" or self.protocol == "udp") and self.source_is_any and self.destination_is_any):
                self.any_any = "any"
                self.risk_port_is_found = True
        #if (self.protocol == "ip" and len(self.destination_ports) == 0):
            #self.any_any = "any"
            #self.risk_port_is_found = True
        #elif ((self.protocol == "tcp" or self.protocol == "udp") and ):
        elif (len(self.destination_ports)):
            if (self.protocol == "tcp"):
                self.add_tcp_risk_port_if()
            elif (self.protocol == "udp"):
                self.add_udp_risk_port_if()
            elif (self.protocol == "ip"):
                self.add_tcp_risk_port_if()
                self.add_udp_risk_port_if()

    def add_tcp_risk_port_if(self):
        risk_ports = ParseAcl.TCP_RISK_PORT.intersection(self.destination_ports)
        if (risk_ports):
            for i in risk_ports:
                self.tcp_risk_port.append(str(i))
            #self.tcp_risk_port.extend(risk_ports)
            self.risk_port_is_found = True

    def add_udp_risk_port_if(self):
        risk_ports = ParseAcl.UDP_RISK_PORT.intersection(self.destination_ports)
        if (risk_ports):
            for i in risk_ports:
                self.udp_risk_port.append(str(i))
            #self.udp_risk_port.extend(risk_ports)
            self.risk_port_is_found = True

    def __str__(self):        
        status = "raw_acl_line = " + self.raw_acl_line
        status = status + "\nactual_acl = " + self.actual_acl
        status = status + "\noperation = " + self.operation
        status = status + "\nprotocol = " + self.protocol
        status = status + "\nsource_is_any = " + str(self.source_is_any)
        status = status + "\nsource_host = " + self.source_host
        status = status + "\nsource_subnet = " + self.source_subnet        
        status = status + "\nsource_ports = " + str(self.source_ports)
        status = status + "\ndestination_is_any = " + str(self.destination_is_any)
        status = status + "\ndestination_host = " + self.destination_host
        status = status + "\ndestination_subnet = " + self.destination_subnet
        status = status + "\ndestination_ports = " + str(self.destination_ports)
        status = status + "\nfound_risk_port = " + str(self.risk_port_is_found)
        status = status + "\ntcp_risk_ports = " + str(self.tcp_risk_port)
        status = status + "\nudp_risk_ports = " + str(self.udp_risk_port)
        status = status + "\nany_any = " + str(self.any_any)

        return status

def create_acl_object(raw_acl_data):
    return ParseAcl(raw_acl_data)

if __name__ == "__main__":

    acl_data = ["1234 permit udp any eq isakmp any"]

    """
    s = acl_data[0].index("permit")
    print(s)
    e = acl_data[0].index("(") if "(" in acl_data[0] else len(-1)
    print(e)
    print(acl_data[0][s:e])
    """

    for line in acl_data:
        line = line.strip()
        if line == '':
            continue
        if "permit" not in line:
            continue

        try:
            # print(line)
            acl =  ParseAcl(line)
            print(acl)
            if(acl.risk_port_is_found):
                print(acl.actual_acl, acl.risk_port_is_found)
        except Exception as e:
            # e = traceback.format_exc()
            print(e)